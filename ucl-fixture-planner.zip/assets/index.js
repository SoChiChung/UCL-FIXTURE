(function(){"use strict";var Vo=document.createElement("style");Vo.textContent=`:root{--bg-deep: #03050d;--bg: #060b1a;--bg-2: #0a1226;--panel: #0d1730;--royal: #1e3a8a;--cobalt: #2b52d6;--sky: #16234d;--ice: #7dd3fc;--ice-deep: #38bdf8;--gold: #d4af37;--gold-soft: #e9cb7e;--text: #e8eef8;--text-2: #a8b3c7;--text-3: #6c7791;--surface: rgba(15, 25, 52, .55);--surface-solid: #0e1830;--surface-raised: rgba(21, 34, 66, .72);--line: rgba(140, 160, 200, .12);--line-2: rgba(165, 216, 255, .24);--success: #4ade80;--warning: #f0b45c;--danger: #f87171;--home-fill: linear-gradient(135deg, #2b52d6 0%, #1e3a8a 100%);--away-line: var(--ice);--font-display: "Arial Narrow", "Avenir Next Condensed", "DIN Condensed", "Roboto Condensed", "PingFang SC", "Microsoft YaHei", sans-serif;--font-heading: "Arial", "Helvetica Neue", "PingFang SC", "Microsoft YaHei", sans-serif;--font-body: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", "Noto Sans SC", system-ui, sans-serif;--s-1: 4px;--s-2: 8px;--s-3: 12px;--s-4: 16px;--s-5: 20px;--s-6: 24px;--s-8: 32px;--s-10: 40px;--s-16: 64px;--r-sm: 8px;--r-md: 12px;--r-lg: 16px;--r-full: 999px;--sh-sm: 0 1px 0 rgba(255, 255, 255, .03) inset, 0 2px 8px rgba(0, 0, 0, .35);--sh-md: 0 6px 22px rgba(0, 0, 0, .45);--sh-lg: 0 14px 44px rgba(0, 0, 0, .55);--glow-ice: 0 0 0 1px rgba(125, 211, 252, .25), 0 0 24px rgba(56, 189, 248, .18)}*{box-sizing:border-box;margin:0;padding:0}html{-webkit-text-size-adjust:100%;touch-action:manipulation}body{font-family:var(--font-body);color:var(--text);background:radial-gradient(1100px 700px at 50% -12%,rgba(43,82,214,.34),transparent 62%),radial-gradient(820px 560px at 88% 16%,rgba(30,58,138,.42),transparent 64%),radial-gradient(760px 620px at 6% 56%,rgba(125,211,252,.07),transparent 60%),linear-gradient(180deg,#070d1e 0%,var(--bg-deep) 100%);background-attachment:fixed;min-height:100vh;line-height:1.55;-webkit-font-smoothing:antialiased;-webkit-tap-highlight-color:transparent;text-rendering:optimizeLegibility}button{font-family:inherit;cursor:pointer;border:none;background:none;color:inherit}input{font-family:inherit}::-webkit-scrollbar{width:10px;height:10px}::-webkit-scrollbar-thumb{background:rgba(140,160,200,.18);border-radius:999px;border:2px solid transparent;background-clip:content-box}::-webkit-scrollbar-thumb:hover{background:rgba(165,216,255,.32);background-clip:content-box}::-webkit-scrollbar-track{background:transparent}.bg-aura{position:fixed;top:0;right:0;bottom:0;left:0;z-index:0;pointer-events:none;overflow:hidden}.bg-aura__orb{position:absolute;border-radius:50%;filter:blur(64px)}.bg-aura__orb--1{top:-140px;left:50%;transform:translate(-50%);width:760px;height:520px;background:radial-gradient(closest-side,rgba(43,82,214,.45),transparent)}.bg-aura__orb--2{top:26%;right:-180px;width:540px;height:540px;background:radial-gradient(closest-side,rgba(30,58,138,.55),transparent)}.bg-aura__orb--3{bottom:-160px;left:-140px;width:520px;height:520px;background:radial-gradient(closest-side,rgba(56,189,248,.1),transparent)}.bg-aura__ring{position:absolute;border-radius:50%;border:1px solid rgba(165,216,255,.1)}.bg-aura__ring--1{top:-170px;right:-110px;width:540px;height:540px}.bg-aura__ring--2{top:-110px;right:-50px;width:400px;height:400px;border-color:rgba(165,216,255,.07)}.bg-aura__ring--3{top:-64px;right:-4px;width:280px;height:280px;border-color:rgba(233,203,126,.14)}.bg-aura__stars{position:absolute;top:0;right:0;bottom:0;left:0;background-image:radial-gradient(1px 1px at 22% 32%,rgba(232,238,248,.55),transparent 45%),radial-gradient(1px 1px at 68% 14%,rgba(165,216,255,.42),transparent 45%),radial-gradient(1.5px 1.5px at 82% 38%,rgba(232,238,248,.4),transparent 45%),radial-gradient(1px 1px at 34% 58%,rgba(165,216,255,.3),transparent 45%),radial-gradient(1px 1px at 55% 74%,rgba(232,238,248,.3),transparent 45%),radial-gradient(1.5px 1.5px at 12% 78%,rgba(165,216,255,.28),transparent 45%);background-size:640px 640px}.app{position:relative;z-index:1;max-width:1280px;margin:0 auto;padding:0 var(--s-6) var(--s-10)}.workspace{display:flex;align-items:flex-start;gap:var(--s-6)}.workspace__main{flex:1;min-width:0}.workspace__side{width:300px;flex-shrink:0;position:sticky;top:var(--s-4)}.header{position:relative;display:flex;align-items:center;justify-content:space-between;gap:var(--s-4);padding:var(--s-6) 0 var(--s-5);flex-wrap:wrap;border-bottom:1px solid var(--line)}.header:before{content:"";position:absolute;top:0;left:0;right:0;height:2px;background:linear-gradient(90deg,transparent,var(--gold) 18%,var(--ice) 50%,var(--gold) 82%,transparent);opacity:.7}.brand{display:flex;align-items:center;gap:var(--s-4)}.brand__logo{width:52px;height:52px;flex-shrink:0;display:grid;place-items:center;border-radius:var(--r-md);background:linear-gradient(160deg,rgba(43,82,214,.35),rgba(13,23,48,.6));border:1px solid var(--line-2);box-shadow:var(--glow-ice)}.brand__title{font-family:var(--font-heading);font-size:24px;font-weight:700;letter-spacing:.01em;color:var(--text);line-height:1.1}.brand__sub{margin-top:3px;font-family:var(--font-display);font-size:12px;letter-spacing:.32em;text-transform:uppercase;color:var(--gold-soft);font-weight:400}.header__actions{display:flex;gap:var(--s-3);align-items:center}.toggle{display:inline-flex;align-items:center;gap:var(--s-2);padding:var(--s-2) var(--s-4);border-radius:var(--r-full);font-weight:600;font-size:14px;border:1px solid var(--line-2);background:var(--surface);color:var(--text-2);backdrop-filter:blur(8px);transition:all .18s ease}.toggle:hover{border-color:var(--ice);color:var(--text)}.toggle--on{background:linear-gradient(135deg,rgba(43,82,214,.5),rgba(30,58,138,.5));border-color:var(--ice);color:var(--text);box-shadow:var(--glow-ice)}.toggle__dot{width:9px;height:9px;border-radius:50%;background:var(--text-3);transition:all .18s ease}.toggle--on .toggle__dot{background:var(--gold-soft);box-shadow:0 0 8px rgba(233,203,126,.7)}.btn-ghost{padding:var(--s-2) var(--s-4);border-radius:var(--r-full);font-weight:600;font-size:14px;color:var(--text-2);transition:all .18s ease}.btn-ghost:hover:not(:disabled){color:var(--danger);background:rgba(248,113,113,.08)}.btn-ghost:disabled{opacity:.35;cursor:not-allowed}.empty{text-align:center;padding:var(--s-16) var(--s-6)}.empty__icon{font-size:52px;margin-bottom:var(--s-4);opacity:.9;filter:drop-shadow(0 0 18px rgba(125,211,252,.35))}.empty__title{font-family:var(--font-heading);font-size:28px;font-weight:700;letter-spacing:.02em;margin-bottom:var(--s-2)}.empty__sub{font-size:15px;color:var(--text-2);margin-bottom:var(--s-6)}.search{position:relative;margin-bottom:var(--s-4)}.search__input{width:100%;padding:var(--s-3) var(--s-4);font-size:15px;font-weight:500;color:var(--text);border:1px solid var(--line);border-radius:var(--r-md);background:var(--surface);box-shadow:var(--sh-sm);backdrop-filter:blur(8px);transition:border-color .16s ease,box-shadow .16s ease}.search__input::placeholder{color:var(--text-3);font-weight:400}.search__input:focus{outline:none;border-color:var(--ice);box-shadow:var(--glow-ice)}.search__dropdown{position:absolute;top:calc(100% + var(--s-2));left:0;right:0;background:var(--surface-solid);border:1px solid var(--line-2);border-radius:var(--r-lg);box-shadow:var(--sh-lg);z-index:30;max-height:320px;overflow-y:auto;padding:var(--s-2)}.search__item{display:flex;align-items:center;gap:var(--s-3);width:100%;padding:var(--s-3) var(--s-4);border-radius:var(--r-md);text-align:left;font-size:15px;transition:background .1s ease}.search__item:hover,.search__item--active{background:rgba(43,82,214,.22)}.search__item--added{opacity:.4;cursor:default}.search__code{font-family:var(--font-heading);font-weight:600;color:var(--ice);min-width:44px;font-size:14px;letter-spacing:.04em}.search__name{font-weight:500;flex:1;color:var(--text)}.search__hint{font-size:12px;color:var(--text-3)}.search__empty{padding:var(--s-4);text-align:center;color:var(--text-3);font-size:14px}.selected{margin-bottom:var(--s-5)}.selected__label{font-size:12px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--text-3);margin-bottom:var(--s-2)}.selected__tags{display:flex;flex-wrap:wrap;gap:var(--s-2)}.selected__empty{font-size:14px;color:var(--text-3)}.tag{display:inline-flex;align-items:center;gap:var(--s-2);padding:var(--s-2) var(--s-3);border-radius:var(--r-full);background:var(--surface);border:1px solid var(--line-2);font-weight:600;font-size:14px;color:var(--text);transition:all .16s ease}.tag:hover{border-color:var(--ice)}.tag__dot{width:8px;height:8px;border-radius:50%;background:var(--ice);box-shadow:0 0 6px rgba(125,211,252,.6)}.tag__remove{display:grid;place-items:center;width:18px;height:18px;border-radius:50%;color:var(--text-3);font-size:14px;line-height:1;transition:all .1s ease}.tag__remove:hover{background:var(--danger);color:#fff}.quick{display:flex;flex-wrap:wrap;gap:var(--s-2);margin-top:var(--s-3)}.quick__label{font-size:12px;color:var(--text-3);align-self:center;margin-right:var(--s-1)}.chip{padding:var(--s-1) var(--s-3);border-radius:var(--r-full);background:var(--surface);border:1px solid var(--line);font-weight:600;font-size:13px;color:var(--text-2);transition:all .14s ease}.chip:hover{background:rgba(43,82,214,.22);border-color:var(--gold);color:var(--gold-soft)}.selector{background:var(--surface);border:1px solid var(--line);border-radius:var(--r-lg);box-shadow:var(--sh-md);backdrop-filter:blur(14px);overflow:hidden}.selector__head{display:flex;align-items:center;justify-content:space-between;padding:var(--s-3) var(--s-4);border-bottom:1px solid var(--line);background:linear-gradient(180deg,rgba(43,82,214,.16),transparent)}.selector__title{font-family:var(--font-heading);font-size:14px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;color:var(--text)}.selector__count{font-size:12px;font-weight:700;color:var(--gold-soft);background:rgba(212,175,55,.12);border:1px solid rgba(212,175,55,.28);border-radius:var(--r-full);padding:2px 10px}.selector__search{margin:var(--s-3);width:calc(100% - var(--s-6))}.selector__list{max-height:calc(100vh - 220px);overflow-y:auto;padding:0 var(--s-3) var(--s-4)}.selector__group+.selector__group{margin-top:var(--s-3)}.selector__group-title{font-size:11px;font-weight:700;color:var(--text-3);text-transform:uppercase;letter-spacing:.12em;margin-bottom:var(--s-2);padding-left:var(--s-1)}.selector__item{display:flex;align-items:center;gap:var(--s-3);padding:var(--s-2) var(--s-3);border-radius:var(--r-sm);cursor:pointer;transition:background .1s ease}.selector__item:hover{background:rgba(43,82,214,.16)}.selector__item--checked{background:rgba(43,82,214,.22);box-shadow:inset 0 0 0 1px rgba(125,211,252,.18)}.selector__item input[type=checkbox]{width:16px;height:16px;accent-color:var(--ice-deep);cursor:pointer;flex-shrink:0}.selector__item input:disabled{cursor:not-allowed;opacity:.35}.selector__code{font-family:var(--font-heading);font-weight:600;color:var(--ice);min-width:44px;font-size:13px;letter-spacing:.05em}.selector__name{font-weight:500;font-size:14px;flex:1;color:var(--text-2)}.range{display:flex;align-items:center;flex-wrap:wrap;gap:var(--s-2);margin-bottom:var(--s-4);padding:var(--s-2) var(--s-3);background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md);font-size:13px;backdrop-filter:blur(8px)}.range__label{font-family:var(--font-heading);font-weight:600;letter-spacing:.04em;color:var(--text-2);margin-right:var(--s-1)}.range__select{font-family:inherit;font-size:13px;font-weight:600;color:var(--text);padding:var(--s-2) var(--s-3);border:1px solid var(--line);border-radius:var(--r-sm);background:var(--surface-solid);cursor:pointer;transition:border-color .16s ease}.range__select option{background:var(--surface-solid);color:var(--text)}.range__select:hover{border-color:var(--line-2)}.range__select:focus{outline:none;border-color:var(--ice);box-shadow:var(--glow-ice)}.range__arrow{color:var(--ice);font-weight:700}.range__hint{font-size:12px;color:var(--text-3);font-weight:500;margin-left:var(--s-2)}.recommend{margin-bottom:var(--s-4)}.recommend__card{background:linear-gradient(135deg,rgba(212,175,55,.1),var(--surface));border:1px solid rgba(212,175,55,.28);border-radius:var(--r-md);padding:var(--s-3) var(--s-4);box-shadow:var(--sh-sm);backdrop-filter:blur(8px)}.recommend__hint{display:flex;align-items:flex-start;gap:var(--s-2);font-size:13px;font-weight:500;color:var(--text-2);margin-bottom:var(--s-3)}.recommend__bulb{font-size:16px;line-height:1.2;flex-shrink:0}.recommend__foot{display:flex;align-items:center;justify-content:space-between;gap:var(--s-3);flex-wrap:wrap}.recommend__count{font-size:13px;font-weight:700;color:var(--gold-soft)}.recommend__cta{padding:var(--s-2) var(--s-4);border-radius:var(--r-full);background:linear-gradient(135deg,var(--cobalt),var(--royal));color:#fff;font-size:14px;font-weight:700;box-shadow:0 4px 18px rgba(43,82,214,.35);transition:transform .12s ease,box-shadow .12s ease}.recommend__cta:hover{transform:translateY(-1px);box-shadow:0 6px 24px rgba(43,82,214,.5)}.recommend__result{margin-top:var(--s-3);background:var(--surface);border:1px solid var(--line);border-radius:var(--r-md);padding:var(--s-4);box-shadow:var(--sh-md);backdrop-filter:blur(12px)}.recommend__subtitle{font-size:13px;font-weight:700;color:var(--text-2);margin-bottom:var(--s-2)}.recommend__candidate{display:flex;align-items:center;gap:var(--s-3);padding:var(--s-3);background:rgba(43,82,214,.18);border:1px solid rgba(125,211,252,.16);border-radius:var(--r-sm)}.recommend__no{display:inline-flex;align-items:center;justify-content:center;min-width:24px;height:24px;border-radius:50%;background:linear-gradient(135deg,var(--cobalt),var(--royal));color:#fff;font-size:13px;font-weight:700;flex-shrink:0}.recommend__team{display:flex;align-items:baseline;gap:var(--s-2);flex:1;min-width:0}.recommend__code{font-family:var(--font-heading);font-size:18px;font-weight:700;color:var(--ice);letter-spacing:.03em}.recommend__name{font-size:14px;font-weight:600;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.recommend__holes{font-size:13px;font-weight:600;color:var(--gold-soft);white-space:nowrap}.recommend__actions{display:flex;flex-wrap:wrap;gap:var(--s-2);margin-top:var(--s-3)}.recommend__btn{padding:var(--s-2) var(--s-4);border-radius:var(--r-full);border:1px solid var(--ice);background:transparent;color:var(--ice);font-size:13px;font-weight:600;transition:all .14s ease}.recommend__btn:hover{background:var(--ice);color:var(--bg-deep)}.recommend__btn--ghost{border-color:var(--line-2);color:var(--text-2)}.recommend__btn--ghost:hover{background:rgba(43,82,214,.22);border-color:var(--ice);color:var(--text)}.recommend__schedule{list-style:none;margin:var(--s-3) 0 0;padding:var(--s-2) var(--s-3);background:rgba(13,23,48,.5);border-radius:var(--r-sm);display:flex;flex-direction:column;gap:var(--s-1)}.recommend__line{display:flex;gap:var(--s-3);font-size:13px;font-weight:500;color:var(--text-2)}.recommend__line-md{font-family:var(--font-heading);font-weight:700;color:var(--ice);min-width:42px;letter-spacing:.04em}.recommend__tied{margin-top:var(--s-3);font-size:12px;font-weight:500;color:var(--text-3)}.recommend__empty{font-size:14px;color:var(--text-3);padding:var(--s-2) 0}.matrix{width:100%;overflow:auto;border:1px solid var(--line);border-radius:var(--r-md);background:var(--surface);backdrop-filter:blur(12px);box-shadow:var(--sh-md)}.matrix__table{border-collapse:separate;border-spacing:0;width:100%;min-width:100%}.matrix__table th,.matrix__table td{vertical-align:middle;padding:var(--s-2) var(--s-3);text-align:center;border-right:1px solid var(--line)}.matrix__table tbody td,.matrix__table tbody th{border-bottom:1px solid var(--line)}.matrix__table tbody tr:last-child td,.matrix__table tbody tr:last-child th{border-bottom:none}.matrix__th{font-family:var(--font-heading);font-size:13px;font-weight:600;color:var(--text-2);white-space:nowrap}.matrix__th--md{font-family:var(--font-display);font-size:17px;letter-spacing:.12em;color:var(--text);background:linear-gradient(180deg,rgba(43,82,214,.4),rgba(30,58,138,.34));text-transform:uppercase}.matrix__table .matrix__th--md{border-right:1px solid rgba(165,216,255,.14)}.matrix__th--date{background:rgba(13,23,48,.6);color:var(--text-2);font-size:12px;min-width:72px;border-bottom:1px solid var(--line-2)}.matrix__th--corner{position:sticky;left:0;z-index:3;background:var(--surface-solid);min-width:60px;border-bottom:1px solid var(--line-2)}.matrix__th-sub{display:block;font-size:10px;font-weight:500;color:var(--text-3);font-family:var(--font-body)}.matrix__td-team{position:sticky;left:0;z-index:1;background:var(--surface-solid);font-family:var(--font-heading);font-size:13px;font-weight:700;color:var(--ice);min-width:60px;letter-spacing:.05em}.cell{display:inline-flex;flex-direction:column;align-items:center;justify-content:center;gap:2px;min-width:72px;min-height:52px;padding:var(--s-2) var(--s-3);border-radius:var(--r-sm);font-variant-numeric:tabular-nums;cursor:default;position:relative;transition:transform .1s ease,box-shadow .1s ease}.cell:hover{transform:translateY(-1px);box-shadow:0 8px 22px rgba(0,0,0,.5),0 0 0 1px var(--line-2);z-index:2}.cell--home{background:var(--home-fill);color:var(--text);box-shadow:inset 0 0 0 1px rgba(165,216,255,.22)}.cell--away{background:rgba(13,23,48,.5);color:var(--ice);border:1px solid rgba(125,211,252,.4)}.cell--empty{background:transparent;border:1px dashed rgba(140,160,200,.16)}.cell__main{font-size:14px;font-weight:700;line-height:1.1;white-space:nowrap;font-family:var(--font-heading);letter-spacing:.04em}.cell__ha{font-size:11px;font-weight:600;opacity:.7;margin-left:1px;font-family:var(--font-body)}.cell__time{font-size:11px;font-weight:600;line-height:1;color:var(--text-3);font-variant-numeric:tabular-nums}.cell--home .cell__time{color:rgba(232,238,248,.8)}.cell--away .cell__time{color:var(--text-2)}.cell__badge{position:absolute;top:-8px;left:-6px;display:inline-flex;align-items:center;justify-content:center;min-width:18px;height:18px;padding:0 3px;border-radius:var(--r-full);background:linear-gradient(135deg,var(--gold-soft),var(--gold));color:#1a1406;font-size:11px;font-weight:800;box-shadow:0 0 0 2px var(--bg),0 0 10px rgba(212,175,55,.5)}.cell__ext{display:flex;flex-wrap:wrap;gap:3px;justify-content:center}.cell__chip{font-size:9px;font-weight:700;line-height:1;padding:2px 5px;border-radius:var(--r-full);background:rgba(13,23,48,.7);border:1px solid var(--line);white-space:nowrap}.cell__chip--warm{color:var(--gold-soft);border-color:rgba(212,175,55,.4)}.cell__chip--primary{color:var(--ice);border-color:rgba(125,211,252,.4)}.cell__chip--muted{color:var(--text-3)}.cell--conflict:after{content:"";position:absolute;top:4px;right:4px;width:7px;height:7px;border-radius:50%;background:var(--warning);box-shadow:0 0 0 2px var(--bg),0 0 8px rgba(240,180,92,.6)}.tooltip{position:fixed;z-index:100;background:rgba(9,16,34,.96);color:var(--text);padding:var(--s-3) var(--s-4);border-radius:var(--r-md);font-size:13px;line-height:1.5;border:1px solid var(--line-2);box-shadow:var(--sh-lg);backdrop-filter:blur(10px);pointer-events:none;max-width:240px}.tooltip__row{display:flex;justify-content:space-between;gap:var(--s-4)}.tooltip__label{color:var(--text-3)}.tooltip__title{font-family:var(--font-heading);font-weight:700;font-size:14px;margin-bottom:var(--s-2);color:var(--text)}.tooltip__home{color:var(--gold-soft);font-weight:700}.tooltip__away{color:var(--ice);font-weight:700}.legend{display:flex;flex-wrap:wrap;gap:var(--s-4);margin-top:var(--s-4);font-size:13px;color:var(--text-2)}.legend__item{display:inline-flex;align-items:center;gap:var(--s-2);font-weight:500}.legend__swatch{width:16px;height:16px;border-radius:4px;display:inline-block}.legend__swatch--home{background:var(--home-fill)}.legend__swatch--away{background:rgba(13,23,48,.5);border:1px solid rgba(125,211,252,.4)}.legend__swatch--conflict{background:var(--warning);border-radius:50%;width:10px;height:10px}.legend__swatch--route{border:2px solid var(--gold);background:transparent}.overlay{position:fixed;right:var(--s-5);bottom:var(--s-5);width:360px;max-width:calc(100vw - 32px);max-height:70vh;display:flex;flex-direction:column;background:rgba(10,18,38,.92);border:1px solid var(--line-2);border-radius:var(--r-lg);box-shadow:var(--sh-lg);backdrop-filter:blur(18px);z-index:50;overflow:hidden}.overlay__head{display:flex;align-items:center;justify-content:space-between;padding:var(--s-3) var(--s-4);border-bottom:1px solid var(--line);background:linear-gradient(180deg,rgba(212,175,55,.12),transparent)}.overlay__title{font-family:var(--font-heading);font-size:15px;font-weight:700;color:var(--gold-soft);letter-spacing:.03em}.overlay__subtitle{display:block;font-size:11px;font-weight:500;color:var(--text-3);margin-top:1px}.overlay__close{width:26px;height:26px;border-radius:50%;font-size:18px;line-height:1;color:var(--text-3);transition:all .12s ease}.overlay__close:hover{background:var(--danger);color:#fff}.overlay__body{flex:1;overflow-y:auto;padding:var(--s-3) var(--s-4)}.overlay__md{padding:var(--s-2) 0 var(--s-3);border-bottom:1px dashed var(--line-2)}.overlay__md:last-child{border-bottom:none}.overlay__md-title{font-family:var(--font-display);font-size:15px;font-weight:400;letter-spacing:.1em;text-transform:uppercase;color:var(--ice);margin-bottom:var(--s-2)}.overlay__route{margin-bottom:var(--s-2)}.overlay__route-title{display:flex;align-items:baseline;gap:var(--s-2);font-size:12px;font-weight:700;color:var(--text-2);margin:var(--s-2) 0 var(--s-1)}.overlay__route-date{font-size:11px;font-weight:500;color:var(--text-3)}.overlay__route .overlay__slot{padding-left:var(--s-2)}.overlay__slot{display:flex;align-items:baseline;gap:var(--s-2);font-size:13px;padding:2px 0}.overlay__no{font-size:12px;font-weight:700;color:var(--gold-soft);min-width:16px}.overlay__meta{color:var(--text-3);font-weight:500;white-space:nowrap;font-variant-numeric:tabular-nums}.overlay__teams{font-weight:600;color:var(--text)}.overlay__warn{color:var(--warning)}.overlay__chain{margin-top:var(--s-2);font-size:12px;font-weight:600;color:var(--ice);background:rgba(43,82,214,.16);border:1px solid rgba(125,211,252,.14);border-radius:var(--r-sm);padding:var(--s-2) var(--s-3);line-height:1.5}.overlay__empty{padding:var(--s-8) var(--s-4);text-align:center;color:var(--text-3);font-size:14px}.overlay__foot{padding:var(--s-2) var(--s-4);border-top:1px solid var(--line);font-size:11px;color:var(--text-3);text-align:center}.footer{margin-top:var(--s-10);padding:var(--s-5) 0;border-top:1px solid var(--line);font-size:12px;color:var(--text-3);text-align:center;line-height:1.7}@media (max-width: 1023px){.app{padding:0 var(--s-4) var(--s-8)}.brand__title{font-size:20px}}@media (max-width: 959px){.selector__list{max-height:320px}}@media (max-width: 767px){.header{padding:var(--s-4) 0}.header__actions{width:100%;justify-content:space-between}.brand__title{font-size:18px}.brand__sub{letter-spacing:.22em}.empty__title{font-size:24px}.overlay{left:var(--s-4);right:var(--s-4);bottom:var(--s-4);width:auto;max-height:60vh}}.mobile-tabbar{display:none;position:fixed;bottom:0;left:0;right:0;z-index:40;background:rgba(10,18,38,.92);backdrop-filter:blur(18px);-webkit-backdrop-filter:blur(18px);border-top:1px solid var(--line-2);box-shadow:0 -8px 24px rgba(0,0,0,.45);padding-bottom:0;padding-bottom:var(--safe-area-inset-bottom, env(safe-area-inset-bottom, 0px))}.mobile-tabbar__tab{flex:1;position:relative;display:flex;flex-direction:column;align-items:center;gap:2px;padding:10px 0 12px;color:var(--text-3);transition:color .15s ease}.mobile-tabbar__tab--active{color:var(--gold-soft)}.mobile-tabbar__tab--active:before{content:"";position:absolute;top:0;left:50%;transform:translate(-50%);width:34px;height:2px;border-radius:2px;background:linear-gradient(90deg,var(--ice-deep),var(--gold))}.mobile-tabbar__icon{font-size:20px;line-height:1;filter:drop-shadow(0 0 8px rgba(125,211,252,.25))}.mobile-tabbar__label{font-size:11px;font-weight:600;letter-spacing:.08em}.mobile-tabbar__badge{position:absolute;top:6px;left:calc(50% + 8px);font-size:10px;font-weight:700;line-height:16px;color:var(--gold-soft);background:rgba(212,175,55,.14);border:1px solid rgba(212,175,55,.3);border-radius:var(--r-full);padding:0 6px}.mobile-view-fixtures{display:none;width:calc(100% - var(--s-8));margin:var(--s-4) var(--s-4) 0;padding:var(--s-3);font-family:var(--font-heading);font-size:15px;font-weight:600;letter-spacing:.04em;color:var(--bg-deep);background:linear-gradient(135deg,var(--gold-soft),var(--gold));border-radius:var(--r-md);box-shadow:0 4px 18px rgba(212,175,55,.25);transition:filter .15s ease}.mobile-view-fixtures:hover{filter:brightness(1.06)}.landscape-hint{display:none;align-items:center;gap:var(--s-2);padding:var(--s-3) var(--s-4);margin-bottom:var(--s-4);background:rgba(212,175,55,.1);border:1px solid rgba(212,175,55,.28);border-radius:var(--r-md);color:var(--gold-soft);font-size:13px}.landscape-hint__icon{font-size:16px;line-height:1}.landscape-hint__text{flex:1}.landscape-hint__close{font-size:20px;line-height:1;color:var(--gold-soft);opacity:.7;padding:0 var(--s-1);transition:opacity .15s ease}.landscape-hint__close:hover{opacity:1}.empty--mobile{display:none}@media (orientation: portrait){.app{padding-bottom:72px;padding-bottom:calc(72px + var(--safe-area-inset-bottom, env(safe-area-inset-bottom, 0px)))}.mobile-tabbar{display:flex}.workspace[data-tab=select] .workspace__main,.workspace[data-tab=fixtures] .workspace__side{display:none}.workspace__side{width:100%;position:static}.mobile-view-fixtures{display:block}.landscape-hint{display:flex}.empty--desktop{display:none}.empty--mobile{display:inline}}html:not(.supports-flex-gap) .workspace>*+*{margin-left:var(--s-6)}html:not(.supports-flex-gap) .header>*+*{margin-left:var(--s-4)}html:not(.supports-flex-gap) .brand>*+*{margin-left:var(--s-4)}html:not(.supports-flex-gap) .header__actions>*+*{margin-left:var(--s-3)}html:not(.supports-flex-gap) .toggle>*+*{margin-left:var(--s-2)}html:not(.supports-flex-gap) .search__item>*+*{margin-left:var(--s-3)}html:not(.supports-flex-gap) .selected__tags>*+*{margin-left:var(--s-2)}html:not(.supports-flex-gap) .tag>*+*{margin-left:var(--s-2)}html:not(.supports-flex-gap) .quick>*+*{margin-left:var(--s-2)}html:not(.supports-flex-gap) .selector__item>*+*{margin-left:var(--s-3)}html:not(.supports-flex-gap) .range>*+*{margin-left:var(--s-2)}html:not(.supports-flex-gap) .recommend__hint>*+*{margin-left:var(--s-2)}html:not(.supports-flex-gap) .recommend__foot>*+*{margin-left:var(--s-3)}html:not(.supports-flex-gap) .recommend__candidate>*+*{margin-left:var(--s-3)}html:not(.supports-flex-gap) .recommend__team>*+*{margin-left:var(--s-2)}html:not(.supports-flex-gap) .recommend__actions>*+*{margin-left:var(--s-2)}html:not(.supports-flex-gap) .recommend__line>*+*{margin-left:var(--s-3)}html:not(.supports-flex-gap) .tooltip__row>*+*{margin-left:var(--s-4)}html:not(.supports-flex-gap) .legend>*+*{margin-left:var(--s-4)}html:not(.supports-flex-gap) .legend__item>*+*{margin-left:var(--s-2)}html:not(.supports-flex-gap) .overlay__route-title>*+*{margin-left:var(--s-2)}html:not(.supports-flex-gap) .overlay__slot>*+*{margin-left:var(--s-2)}html:not(.supports-flex-gap) .landscape-hint>*+*{margin-left:var(--s-2)}html:not(.supports-flex-gap) .cell__ext>*+*{margin-left:3px}html:not(.supports-flex-gap) .recommend__schedule>*+*{margin-top:var(--s-1)}html:not(.supports-flex-gap) .cell>*+*{margin-top:2px}html:not(.supports-flex-gap) .mobile-tabbar__tab>*+*{margin-top:2px}
/*$vite$:1*/`,document.head.appendChild(Vo);var Oo={exports:{}},qt={},Fo={exports:{}},_={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var lt=Symbol.for("react.element"),hm=Symbol.for("react.portal"),pm=Symbol.for("react.fragment"),fm=Symbol.for("react.strict_mode"),ym=Symbol.for("react.profiler"),gm=Symbol.for("react.provider"),vm=Symbol.for("react.context"),Nm=Symbol.for("react.forward_ref"),wm=Symbol.for("react.suspense"),Im=Symbol.for("react.memo"),Sm=Symbol.for("react.lazy"),zo=Symbol.iterator;function Am(n){return n===null||typeof n!="object"?null:(n=zo&&n[zo]||n["@@iterator"],typeof n=="function"?n:null)}var bo={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},jo=Object.assign,Ko={};function Be(n,e,t){this.props=n,this.context=e,this.refs=Ko,this.updater=t||bo}Be.prototype.isReactComponent={},Be.prototype.setState=function(n,e){if(typeof n!="object"&&typeof n!="function"&&n!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,n,e,"setState")},Be.prototype.forceUpdate=function(n){this.updater.enqueueForceUpdate(this,n,"forceUpdate")};function Uo(){}Uo.prototype=Be.prototype;function g0(n,e,t){this.props=n,this.context=e,this.refs=Ko,this.updater=t||bo}var v0=g0.prototype=new Uo;v0.constructor=g0,jo(v0,Be.prototype),v0.isPureReactComponent=!0;var Ho=Array.isArray,Wo=Object.prototype.hasOwnProperty,N0={current:null},Go={key:!0,ref:!0,__self:!0,__source:!0};function $o(n,e,t){var a,d={},o=null,i=null;if(e!=null)for(a in e.ref!==void 0&&(i=e.ref),e.key!==void 0&&(o=""+e.key),e)Wo.call(e,a)&&!Go.hasOwnProperty(a)&&(d[a]=e[a]);var r=arguments.length-2;if(r===1)d.children=t;else if(1<r){for(var l=Array(r),u=0;u<r;u++)l[u]=arguments[u+2];d.children=l}if(n&&n.defaultProps)for(a in r=n.defaultProps,r)d[a]===void 0&&(d[a]=r[a]);return{$$typeof:lt,type:n,key:o,ref:i,props:d,_owner:N0.current}}function Pm(n,e){return{$$typeof:lt,type:n.type,key:e,ref:n.ref,props:n.props,_owner:n._owner}}function w0(n){return typeof n=="object"&&n!==null&&n.$$typeof===lt}function Tm(n){var e={"=":"=0",":":"=2"};return"$"+n.replace(/[=:]/g,function(t){return e[t]})}var Yo=/\/+/g;function I0(n,e){return typeof n=="object"&&n!==null&&n.key!=null?Tm(""+n.key):e.toString(36)}function na(n,e,t,a,d){var o=typeof n;(o==="undefined"||o==="boolean")&&(n=null);var i=!1;if(n===null)i=!0;else switch(o){case"string":case"number":i=!0;break;case"object":switch(n.$$typeof){case lt:case hm:i=!0}}if(i)return i=n,d=d(i),n=a===""?"."+I0(i,0):a,Ho(d)?(t="",n!=null&&(t=n.replace(Yo,"$&/")+"/"),na(d,e,t,"",function(u){return u})):d!=null&&(w0(d)&&(d=Pm(d,t+(!d.key||i&&i.key===d.key?"":(""+d.key).replace(Yo,"$&/")+"/")+n)),e.push(d)),1;if(i=0,a=a===""?".":a+":",Ho(n))for(var r=0;r<n.length;r++){o=n[r];var l=a+I0(o,r);i+=na(o,e,t,l,d)}else if(l=Am(n),typeof l=="function")for(n=l.call(n),r=0;!(o=n.next()).done;)o=o.value,l=a+I0(o,r++),i+=na(o,e,t,l,d);else if(o==="object")throw e=String(n),Error("Objects are not valid as a React child (found: "+(e==="[object Object]"?"object with keys {"+Object.keys(n).join(", ")+"}":e)+"). If you meant to render a collection of children, use an array instead.");return i}function ea(n,e,t){if(n==null)return n;var a=[],d=0;return na(n,a,"","",function(o){return e.call(t,o,d++)}),a}function Mm(n){if(n._status===-1){var e=n._result;e=e(),e.then(function(t){(n._status===0||n._status===-1)&&(n._status=1,n._result=t)},function(t){(n._status===0||n._status===-1)&&(n._status=2,n._result=t)}),n._status===-1&&(n._status=0,n._result=e)}if(n._status===1)return n._result.default;throw n._result}var rn={current:null},ta={transition:null},Cm={ReactCurrentDispatcher:rn,ReactCurrentBatchConfig:ta,ReactCurrentOwner:N0};function Qo(){throw Error("act(...) is not supported in production builds of React.")}_.Children={map:ea,forEach:function(n,e,t){ea(n,function(){e.apply(this,arguments)},t)},count:function(n){var e=0;return ea(n,function(){e++}),e},toArray:function(n){return ea(n,function(e){return e})||[]},only:function(n){if(!w0(n))throw Error("React.Children.only expected to receive a single React element child.");return n}},_.Component=Be,_.Fragment=pm,_.Profiler=ym,_.PureComponent=g0,_.StrictMode=fm,_.Suspense=wm,_.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=Cm,_.act=Qo,_.cloneElement=function(n,e,t){if(n==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+n+".");var a=jo({},n.props),d=n.key,o=n.ref,i=n._owner;if(e!=null){if(e.ref!==void 0&&(o=e.ref,i=N0.current),e.key!==void 0&&(d=""+e.key),n.type&&n.type.defaultProps)var r=n.type.defaultProps;for(l in e)Wo.call(e,l)&&!Go.hasOwnProperty(l)&&(a[l]=e[l]===void 0&&r!==void 0?r[l]:e[l])}var l=arguments.length-2;if(l===1)a.children=t;else if(1<l){r=Array(l);for(var u=0;u<l;u++)r[u]=arguments[u+2];a.children=r}return{$$typeof:lt,type:n.type,key:d,ref:o,props:a,_owner:i}},_.createContext=function(n){return n={$$typeof:vm,_currentValue:n,_currentValue2:n,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},n.Provider={$$typeof:gm,_context:n},n.Consumer=n},_.createElement=$o,_.createFactory=function(n){var e=$o.bind(null,n);return e.type=n,e},_.createRef=function(){return{current:null}},_.forwardRef=function(n){return{$$typeof:Nm,render:n}},_.isValidElement=w0,_.lazy=function(n){return{$$typeof:Sm,_payload:{_status:-1,_result:n},_init:Mm}},_.memo=function(n,e){return{$$typeof:Im,type:n,compare:e===void 0?null:e}},_.startTransition=function(n){var e=ta.transition;ta.transition={};try{n()}finally{ta.transition=e}},_.unstable_act=Qo,_.useCallback=function(n,e){return rn.current.useCallback(n,e)},_.useContext=function(n){return rn.current.useContext(n)},_.useDebugValue=function(){},_.useDeferredValue=function(n){return rn.current.useDeferredValue(n)},_.useEffect=function(n,e){return rn.current.useEffect(n,e)},_.useId=function(){return rn.current.useId()},_.useImperativeHandle=function(n,e,t){return rn.current.useImperativeHandle(n,e,t)},_.useInsertionEffect=function(n,e){return rn.current.useInsertionEffect(n,e)},_.useLayoutEffect=function(n,e){return rn.current.useLayoutEffect(n,e)},_.useMemo=function(n,e){return rn.current.useMemo(n,e)},_.useReducer=function(n,e,t){return rn.current.useReducer(n,e,t)},_.useRef=function(n){return rn.current.useRef(n)},_.useState=function(n){return rn.current.useState(n)},_.useSyncExternalStore=function(n,e,t){return rn.current.useSyncExternalStore(n,e,t)},_.useTransition=function(){return rn.current.useTransition()},_.version="18.3.1",Fo.exports=_;var U=Fo.exports;/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var km=U,xm=Symbol.for("react.element"),_m=Symbol.for("react.fragment"),Dm=Object.prototype.hasOwnProperty,Lm=km.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,Bm={key:!0,ref:!0,__self:!0,__source:!0};function Jo(n,e,t){var a,d={},o=null,i=null;t!==void 0&&(o=""+t),e.key!==void 0&&(o=""+e.key),e.ref!==void 0&&(i=e.ref);for(a in e)Dm.call(e,a)&&!Bm.hasOwnProperty(a)&&(d[a]=e[a]);if(n&&n.defaultProps)for(a in e=n.defaultProps,e)d[a]===void 0&&(d[a]=e[a]);return{$$typeof:xm,type:n,key:o,ref:i,props:d,_owner:Lm.current}}qt.Fragment=_m,qt.jsx=Jo,qt.jsxs=Jo,Oo.exports=qt;var s=Oo.exports,Xo={exports:{}},yn={},Zo={exports:{}},qo={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */(function(n){function e(P,k){var x=P.length;P.push(k);n:for(;0<x;){var G=x-1>>>1,Z=P[G];if(0<d(Z,k))P[G]=k,P[x]=Z,x=G;else break n}}function t(P){return P.length===0?null:P[0]}function a(P){if(P.length===0)return null;var k=P[0],x=P.pop();if(x!==k){P[0]=x;n:for(var G=0,Z=P.length,f0=Z>>>1;G<f0;){var De=2*(G+1)-1,Ro=P[De],Le=De+1,y0=P[Le];if(0>d(Ro,x))Le<Z&&0>d(y0,Ro)?(P[G]=y0,P[Le]=x,G=Le):(P[G]=Ro,P[De]=x,G=De);else if(Le<Z&&0>d(y0,x))P[G]=y0,P[Le]=x,G=Le;else break n}}return k}function d(P,k){var x=P.sortIndex-k.sortIndex;return x!==0?x:P.id-k.id}if(typeof performance=="object"&&typeof performance.now=="function"){var o=performance;n.unstable_now=function(){return o.now()}}else{var i=Date,r=i.now();n.unstable_now=function(){return i.now()-r}}var l=[],u=[],y=1,f=null,p=3,g=!1,N=!1,w=!1,D=typeof setTimeout=="function"?setTimeout:null,h=typeof clearTimeout=="function"?clearTimeout:null,m=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function c(P){for(var k=t(u);k!==null;){if(k.callback===null)a(u);else if(k.startTime<=P)a(u),k.sortIndex=k.expirationTime,e(l,k);else break;k=t(u)}}function v(P){if(w=!1,c(P),!N)if(t(l)!==null)N=!0,Bo(S);else{var k=t(u);k!==null&&Eo(v,k.startTime-P)}}function S(P,k){N=!1,w&&(w=!1,h(C),C=-1),g=!0;var x=p;try{for(c(k),f=t(l);f!==null&&(!(f.expirationTime>k)||P&&!Rn());){var G=f.callback;if(typeof G=="function"){f.callback=null,p=f.priorityLevel;var Z=G(f.expirationTime<=k);k=n.unstable_now(),typeof Z=="function"?f.callback=Z:f===t(l)&&a(l),c(k)}else a(l);f=t(l)}if(f!==null)var f0=!0;else{var De=t(u);De!==null&&Eo(v,De.startTime-k),f0=!1}return f0}finally{f=null,p=x,g=!1}}var T=!1,M=null,C=-1,W=5,L=-1;function Rn(){return!(n.unstable_now()-L<W)}function Xt(){if(M!==null){var P=n.unstable_now();L=P;var k=!0;try{k=M(!0,P)}finally{k?Zt():(T=!1,M=null)}}else T=!1}var Zt;if(typeof m=="function")Zt=function(){m(Xt)};else if(typeof MessageChannel<"u"){var cm=new MessageChannel,i2=cm.port2;cm.port1.onmessage=Xt,Zt=function(){i2.postMessage(null)}}else Zt=function(){D(Xt,0)};function Bo(P){M=P,T||(T=!0,Zt())}function Eo(P,k){C=D(function(){P(n.unstable_now())},k)}n.unstable_IdlePriority=5,n.unstable_ImmediatePriority=1,n.unstable_LowPriority=4,n.unstable_NormalPriority=3,n.unstable_Profiling=null,n.unstable_UserBlockingPriority=2,n.unstable_cancelCallback=function(P){P.callback=null},n.unstable_continueExecution=function(){N||g||(N=!0,Bo(S))},n.unstable_forceFrameRate=function(P){0>P||125<P?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):W=0<P?Math.floor(1e3/P):5},n.unstable_getCurrentPriorityLevel=function(){return p},n.unstable_getFirstCallbackNode=function(){return t(l)},n.unstable_next=function(P){switch(p){case 1:case 2:case 3:var k=3;break;default:k=p}var x=p;p=k;try{return P()}finally{p=x}},n.unstable_pauseExecution=function(){},n.unstable_requestPaint=function(){},n.unstable_runWithPriority=function(P,k){switch(P){case 1:case 2:case 3:case 4:case 5:break;default:P=3}var x=p;p=P;try{return k()}finally{p=x}},n.unstable_scheduleCallback=function(P,k,x){var G=n.unstable_now();switch(typeof x=="object"&&x!==null?(x=x.delay,x=typeof x=="number"&&0<x?G+x:G):x=G,P){case 1:var Z=-1;break;case 2:Z=250;break;case 5:Z=1073741823;break;case 4:Z=1e4;break;default:Z=5e3}return Z=x+Z,P={id:y++,callback:k,priorityLevel:P,startTime:x,expirationTime:Z,sortIndex:-1},x>G?(P.sortIndex=x,e(u,P),t(l)===null&&P===t(u)&&(w?(h(C),C=-1):w=!0,Eo(v,x-G))):(P.sortIndex=Z,e(l,P),N||g||(N=!0,Bo(S))),P},n.unstable_shouldYield=Rn,n.unstable_wrapCallback=function(P){var k=p;return function(){var x=p;p=k;try{return P.apply(this,arguments)}finally{p=x}}}})(qo),Zo.exports=qo;var Em=Zo.exports;/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var Rm=U,gn=Em;function I(n){for(var e="https://reactjs.org/docs/error-decoder.html?invariant="+n,t=1;t<arguments.length;t++)e+="&args[]="+encodeURIComponent(arguments[t]);return"Minified React error #"+n+"; visit "+e+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var ni=new Set,mt={};function ge(n,e){Ee(n,e),Ee(n+"Capture",e)}function Ee(n,e){for(mt[n]=e,n=0;n<e.length;n++)ni.add(e[n])}var jn=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),S0=Object.prototype.hasOwnProperty,Vm=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,ei={},ti={};function Om(n){return S0.call(ti,n)?!0:S0.call(ei,n)?!1:Vm.test(n)?ti[n]=!0:(ei[n]=!0,!1)}function Fm(n,e,t,a){if(t!==null&&t.type===0)return!1;switch(typeof e){case"function":case"symbol":return!0;case"boolean":return a?!1:t!==null?!t.acceptsBooleans:(n=n.toLowerCase().slice(0,5),n!=="data-"&&n!=="aria-");default:return!1}}function zm(n,e,t,a){if(e===null||typeof e>"u"||Fm(n,e,t,a))return!0;if(a)return!1;if(t!==null)switch(t.type){case 3:return!e;case 4:return e===!1;case 5:return isNaN(e);case 6:return isNaN(e)||1>e}return!1}function ln(n,e,t,a,d,o,i){this.acceptsBooleans=e===2||e===3||e===4,this.attributeName=a,this.attributeNamespace=d,this.mustUseProperty=t,this.propertyName=n,this.type=e,this.sanitizeURL=o,this.removeEmptyString=i}var q={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(n){q[n]=new ln(n,0,!1,n,null,!1,!1)}),[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(n){var e=n[0];q[e]=new ln(e,1,!1,n[1],null,!1,!1)}),["contentEditable","draggable","spellCheck","value"].forEach(function(n){q[n]=new ln(n,2,!1,n.toLowerCase(),null,!1,!1)}),["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(n){q[n]=new ln(n,2,!1,n,null,!1,!1)}),"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(n){q[n]=new ln(n,3,!1,n.toLowerCase(),null,!1,!1)}),["checked","multiple","muted","selected"].forEach(function(n){q[n]=new ln(n,3,!0,n,null,!1,!1)}),["capture","download"].forEach(function(n){q[n]=new ln(n,4,!1,n,null,!1,!1)}),["cols","rows","size","span"].forEach(function(n){q[n]=new ln(n,6,!1,n,null,!1,!1)}),["rowSpan","start"].forEach(function(n){q[n]=new ln(n,5,!1,n.toLowerCase(),null,!1,!1)});var A0=/[\-:]([a-z])/g;function P0(n){return n[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(n){var e=n.replace(A0,P0);q[e]=new ln(e,1,!1,n,null,!1,!1)}),"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(n){var e=n.replace(A0,P0);q[e]=new ln(e,1,!1,n,"http://www.w3.org/1999/xlink",!1,!1)}),["xml:base","xml:lang","xml:space"].forEach(function(n){var e=n.replace(A0,P0);q[e]=new ln(e,1,!1,n,"http://www.w3.org/XML/1998/namespace",!1,!1)}),["tabIndex","crossOrigin"].forEach(function(n){q[n]=new ln(n,1,!1,n.toLowerCase(),null,!1,!1)}),q.xlinkHref=new ln("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1),["src","href","action","formAction"].forEach(function(n){q[n]=new ln(n,1,!1,n.toLowerCase(),null,!0,!0)});function T0(n,e,t,a){var d=q.hasOwnProperty(e)?q[e]:null;(d!==null?d.type!==0:a||!(2<e.length)||e[0]!=="o"&&e[0]!=="O"||e[1]!=="n"&&e[1]!=="N")&&(zm(e,t,d,a)&&(t=null),a||d===null?Om(e)&&(t===null?n.removeAttribute(e):n.setAttribute(e,""+t)):d.mustUseProperty?n[d.propertyName]=t===null?d.type===3?!1:"":t:(e=d.attributeName,a=d.attributeNamespace,t===null?n.removeAttribute(e):(d=d.type,t=d===3||d===4&&t===!0?"":""+t,a?n.setAttributeNS(a,e,t):n.setAttribute(e,t))))}var Kn=Rm.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,aa=Symbol.for("react.element"),Re=Symbol.for("react.portal"),Ve=Symbol.for("react.fragment"),M0=Symbol.for("react.strict_mode"),C0=Symbol.for("react.profiler"),ai=Symbol.for("react.provider"),di=Symbol.for("react.context"),k0=Symbol.for("react.forward_ref"),x0=Symbol.for("react.suspense"),_0=Symbol.for("react.suspense_list"),D0=Symbol.for("react.memo"),Xn=Symbol.for("react.lazy"),oi=Symbol.for("react.offscreen"),ii=Symbol.iterator;function ut(n){return n===null||typeof n!="object"?null:(n=ii&&n[ii]||n["@@iterator"],typeof n=="function"?n:null)}var z=Object.assign,L0;function st(n){if(L0===void 0)try{throw Error()}catch(t){var e=t.stack.trim().match(/\n( *(at )?)/);L0=e&&e[1]||""}return`
`+L0+n}var B0=!1;function E0(n,e){if(!n||B0)return"";B0=!0;var t=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(e)if(e=function(){throw Error()},Object.defineProperty(e.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(e,[])}catch(u){var a=u}Reflect.construct(n,[],e)}else{try{e.call()}catch(u){a=u}n.call(e.prototype)}else{try{throw Error()}catch(u){a=u}n()}}catch(u){if(u&&a&&typeof u.stack=="string"){for(var d=u.stack.split(`
`),o=a.stack.split(`
`),i=d.length-1,r=o.length-1;1<=i&&0<=r&&d[i]!==o[r];)r--;for(;1<=i&&0<=r;i--,r--)if(d[i]!==o[r]){if(i!==1||r!==1)do if(i--,r--,0>r||d[i]!==o[r]){var l=`
`+d[i].replace(" at new "," at ");return n.displayName&&l.includes("<anonymous>")&&(l=l.replace("<anonymous>",n.displayName)),l}while(1<=i&&0<=r);break}}}finally{B0=!1,Error.prepareStackTrace=t}return(n=n?n.displayName||n.name:"")?st(n):""}function bm(n){switch(n.tag){case 5:return st(n.type);case 16:return st("Lazy");case 13:return st("Suspense");case 19:return st("SuspenseList");case 0:case 2:case 15:return n=E0(n.type,!1),n;case 11:return n=E0(n.type.render,!1),n;case 1:return n=E0(n.type,!0),n;default:return""}}function R0(n){if(n==null)return null;if(typeof n=="function")return n.displayName||n.name||null;if(typeof n=="string")return n;switch(n){case Ve:return"Fragment";case Re:return"Portal";case C0:return"Profiler";case M0:return"StrictMode";case x0:return"Suspense";case _0:return"SuspenseList"}if(typeof n=="object")switch(n.$$typeof){case di:return(n.displayName||"Context")+".Consumer";case ai:return(n._context.displayName||"Context")+".Provider";case k0:var e=n.render;return n=n.displayName,n||(n=e.displayName||e.name||"",n=n!==""?"ForwardRef("+n+")":"ForwardRef"),n;case D0:return e=n.displayName||null,e!==null?e:R0(n.type)||"Memo";case Xn:e=n._payload,n=n._init;try{return R0(n(e))}catch(t){}}return null}function jm(n){var e=n.type;switch(n.tag){case 24:return"Cache";case 9:return(e.displayName||"Context")+".Consumer";case 10:return(e._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return n=e.render,n=n.displayName||n.name||"",e.displayName||(n!==""?"ForwardRef("+n+")":"ForwardRef");case 7:return"Fragment";case 5:return e;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return R0(e);case 8:return e===M0?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof e=="function")return e.displayName||e.name||null;if(typeof e=="string")return e}return null}function Zn(n){switch(typeof n){case"boolean":case"number":case"string":case"undefined":return n;case"object":return n;default:return""}}function ri(n){var e=n.type;return(n=n.nodeName)&&n.toLowerCase()==="input"&&(e==="checkbox"||e==="radio")}function Km(n){var e=ri(n)?"checked":"value",t=Object.getOwnPropertyDescriptor(n.constructor.prototype,e),a=""+n[e];if(!n.hasOwnProperty(e)&&typeof t<"u"&&typeof t.get=="function"&&typeof t.set=="function"){var d=t.get,o=t.set;return Object.defineProperty(n,e,{configurable:!0,get:function(){return d.call(this)},set:function(i){a=""+i,o.call(this,i)}}),Object.defineProperty(n,e,{enumerable:t.enumerable}),{getValue:function(){return a},setValue:function(i){a=""+i},stopTracking:function(){n._valueTracker=null,delete n[e]}}}}function da(n){n._valueTracker||(n._valueTracker=Km(n))}function li(n){if(!n)return!1;var e=n._valueTracker;if(!e)return!0;var t=e.getValue(),a="";return n&&(a=ri(n)?n.checked?"true":"false":n.value),n=a,n!==t?(e.setValue(n),!0):!1}function oa(n){if(n=n||(typeof document<"u"?document:void 0),typeof n>"u")return null;try{return n.activeElement||n.body}catch(e){return n.body}}function V0(n,e){var t=e.checked;return z({},e,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:t!=null?t:n._wrapperState.initialChecked})}function mi(n,e){var t=e.defaultValue==null?"":e.defaultValue,a=e.checked!=null?e.checked:e.defaultChecked;t=Zn(e.value!=null?e.value:t),n._wrapperState={initialChecked:a,initialValue:t,controlled:e.type==="checkbox"||e.type==="radio"?e.checked!=null:e.value!=null}}function ui(n,e){e=e.checked,e!=null&&T0(n,"checked",e,!1)}function O0(n,e){ui(n,e);var t=Zn(e.value),a=e.type;if(t!=null)a==="number"?(t===0&&n.value===""||n.value!=t)&&(n.value=""+t):n.value!==""+t&&(n.value=""+t);else if(a==="submit"||a==="reset"){n.removeAttribute("value");return}e.hasOwnProperty("value")?F0(n,e.type,t):e.hasOwnProperty("defaultValue")&&F0(n,e.type,Zn(e.defaultValue)),e.checked==null&&e.defaultChecked!=null&&(n.defaultChecked=!!e.defaultChecked)}function si(n,e,t){if(e.hasOwnProperty("value")||e.hasOwnProperty("defaultValue")){var a=e.type;if(!(a!=="submit"&&a!=="reset"||e.value!==void 0&&e.value!==null))return;e=""+n._wrapperState.initialValue,t||e===n.value||(n.value=e),n.defaultValue=e}t=n.name,t!==""&&(n.name=""),n.defaultChecked=!!n._wrapperState.initialChecked,t!==""&&(n.name=t)}function F0(n,e,t){(e!=="number"||oa(n.ownerDocument)!==n)&&(t==null?n.defaultValue=""+n._wrapperState.initialValue:n.defaultValue!==""+t&&(n.defaultValue=""+t))}var ct=Array.isArray;function Oe(n,e,t,a){if(n=n.options,e){e={};for(var d=0;d<t.length;d++)e["$"+t[d]]=!0;for(t=0;t<n.length;t++)d=e.hasOwnProperty("$"+n[t].value),n[t].selected!==d&&(n[t].selected=d),d&&a&&(n[t].defaultSelected=!0)}else{for(t=""+Zn(t),e=null,d=0;d<n.length;d++){if(n[d].value===t){n[d].selected=!0,a&&(n[d].defaultSelected=!0);return}e!==null||n[d].disabled||(e=n[d])}e!==null&&(e.selected=!0)}}function z0(n,e){if(e.dangerouslySetInnerHTML!=null)throw Error(I(91));return z({},e,{value:void 0,defaultValue:void 0,children:""+n._wrapperState.initialValue})}function ci(n,e){var t=e.value;if(t==null){if(t=e.children,e=e.defaultValue,t!=null){if(e!=null)throw Error(I(92));if(ct(t)){if(1<t.length)throw Error(I(93));t=t[0]}e=t}e==null&&(e=""),t=e}n._wrapperState={initialValue:Zn(t)}}function hi(n,e){var t=Zn(e.value),a=Zn(e.defaultValue);t!=null&&(t=""+t,t!==n.value&&(n.value=t),e.defaultValue==null&&n.defaultValue!==t&&(n.defaultValue=t)),a!=null&&(n.defaultValue=""+a)}function pi(n){var e=n.textContent;e===n._wrapperState.initialValue&&e!==""&&e!==null&&(n.value=e)}function fi(n){switch(n){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function b0(n,e){return n==null||n==="http://www.w3.org/1999/xhtml"?fi(e):n==="http://www.w3.org/2000/svg"&&e==="foreignObject"?"http://www.w3.org/1999/xhtml":n}var ia,yi=function(n){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(e,t,a,d){MSApp.execUnsafeLocalFunction(function(){return n(e,t,a,d)})}:n}(function(n,e){if(n.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in n)n.innerHTML=e;else{for(ia=ia||document.createElement("div"),ia.innerHTML="<svg>"+e.valueOf().toString()+"</svg>",e=ia.firstChild;n.firstChild;)n.removeChild(n.firstChild);for(;e.firstChild;)n.appendChild(e.firstChild)}});function ht(n,e){if(e){var t=n.firstChild;if(t&&t===n.lastChild&&t.nodeType===3){t.nodeValue=e;return}}n.textContent=e}var pt={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},Um=["Webkit","ms","Moz","O"];Object.keys(pt).forEach(function(n){Um.forEach(function(e){e=e+n.charAt(0).toUpperCase()+n.substring(1),pt[e]=pt[n]})});function gi(n,e,t){return e==null||typeof e=="boolean"||e===""?"":t||typeof e!="number"||e===0||pt.hasOwnProperty(n)&&pt[n]?(""+e).trim():e+"px"}function vi(n,e){n=n.style;for(var t in e)if(e.hasOwnProperty(t)){var a=t.indexOf("--")===0,d=gi(t,e[t],a);t==="float"&&(t="cssFloat"),a?n.setProperty(t,d):n[t]=d}}var Hm=z({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function j0(n,e){if(e){if(Hm[n]&&(e.children!=null||e.dangerouslySetInnerHTML!=null))throw Error(I(137,n));if(e.dangerouslySetInnerHTML!=null){if(e.children!=null)throw Error(I(60));if(typeof e.dangerouslySetInnerHTML!="object"||!("__html"in e.dangerouslySetInnerHTML))throw Error(I(61))}if(e.style!=null&&typeof e.style!="object")throw Error(I(62))}}function K0(n,e){if(n.indexOf("-")===-1)return typeof e.is=="string";switch(n){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var U0=null;function H0(n){return n=n.target||n.srcElement||window,n.correspondingUseElement&&(n=n.correspondingUseElement),n.nodeType===3?n.parentNode:n}var W0=null,Fe=null,ze=null;function Ni(n){if(n=Vt(n)){if(typeof W0!="function")throw Error(I(280));var e=n.stateNode;e&&(e=xa(e),W0(n.stateNode,n.type,e))}}function wi(n){Fe?ze?ze.push(n):ze=[n]:Fe=n}function Ii(){if(Fe){var n=Fe,e=ze;if(ze=Fe=null,Ni(n),e)for(n=0;n<e.length;n++)Ni(e[n])}}function Si(n,e){return n(e)}function Ai(){}var G0=!1;function Pi(n,e,t){if(G0)return n(e,t);G0=!0;try{return Si(n,e,t)}finally{G0=!1,(Fe!==null||ze!==null)&&(Ai(),Ii())}}function ft(n,e){var t=n.stateNode;if(t===null)return null;var a=xa(t);if(a===null)return null;t=a[e];n:switch(e){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(a=!a.disabled)||(n=n.type,a=!(n==="button"||n==="input"||n==="select"||n==="textarea")),n=!a;break n;default:n=!1}if(n)return null;if(t&&typeof t!="function")throw Error(I(231,e,typeof t));return t}var $0=!1;if(jn)try{var yt={};Object.defineProperty(yt,"passive",{get:function(){$0=!0}}),window.addEventListener("test",yt,yt),window.removeEventListener("test",yt,yt)}catch(n){$0=!1}function Wm(n,e,t,a,d,o,i,r,l){var u=Array.prototype.slice.call(arguments,3);try{e.apply(t,u)}catch(y){this.onError(y)}}var gt=!1,ra=null,la=!1,Y0=null,Gm={onError:function(n){gt=!0,ra=n}};function $m(n,e,t,a,d,o,i,r,l){gt=!1,ra=null,Wm.apply(Gm,arguments)}function Ym(n,e,t,a,d,o,i,r,l){if($m.apply(this,arguments),gt){if(gt){var u=ra;gt=!1,ra=null}else throw Error(I(198));la||(la=!0,Y0=u)}}function ve(n){var e=n,t=n;if(n.alternate)for(;e.return;)e=e.return;else{n=e;do e=n,e.flags&4098&&(t=e.return),n=e.return;while(n)}return e.tag===3?t:null}function Ti(n){if(n.tag===13){var e=n.memoizedState;if(e===null&&(n=n.alternate,n!==null&&(e=n.memoizedState)),e!==null)return e.dehydrated}return null}function Mi(n){if(ve(n)!==n)throw Error(I(188))}function Qm(n){var e=n.alternate;if(!e){if(e=ve(n),e===null)throw Error(I(188));return e!==n?null:n}for(var t=n,a=e;;){var d=t.return;if(d===null)break;var o=d.alternate;if(o===null){if(a=d.return,a!==null){t=a;continue}break}if(d.child===o.child){for(o=d.child;o;){if(o===t)return Mi(d),n;if(o===a)return Mi(d),e;o=o.sibling}throw Error(I(188))}if(t.return!==a.return)t=d,a=o;else{for(var i=!1,r=d.child;r;){if(r===t){i=!0,t=d,a=o;break}if(r===a){i=!0,a=d,t=o;break}r=r.sibling}if(!i){for(r=o.child;r;){if(r===t){i=!0,t=o,a=d;break}if(r===a){i=!0,a=o,t=d;break}r=r.sibling}if(!i)throw Error(I(189))}}if(t.alternate!==a)throw Error(I(190))}if(t.tag!==3)throw Error(I(188));return t.stateNode.current===t?n:e}function Ci(n){return n=Qm(n),n!==null?ki(n):null}function ki(n){if(n.tag===5||n.tag===6)return n;for(n=n.child;n!==null;){var e=ki(n);if(e!==null)return e;n=n.sibling}return null}var xi=gn.unstable_scheduleCallback,_i=gn.unstable_cancelCallback,Jm=gn.unstable_shouldYield,Xm=gn.unstable_requestPaint,H=gn.unstable_now,Zm=gn.unstable_getCurrentPriorityLevel,Q0=gn.unstable_ImmediatePriority,Di=gn.unstable_UserBlockingPriority,ma=gn.unstable_NormalPriority,qm=gn.unstable_LowPriority,Li=gn.unstable_IdlePriority,ua=null,Vn=null;function nu(n){if(Vn&&typeof Vn.onCommitFiberRoot=="function")try{Vn.onCommitFiberRoot(ua,n,void 0,(n.current.flags&128)===128)}catch(e){}}var kn=Math.clz32?Math.clz32:au,eu=Math.log,tu=Math.LN2;function au(n){return n>>>=0,n===0?32:31-(eu(n)/tu|0)|0}var sa=64,ca=4194304;function vt(n){switch(n&-n){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return n&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return n&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return n}}function ha(n,e){var t=n.pendingLanes;if(t===0)return 0;var a=0,d=n.suspendedLanes,o=n.pingedLanes,i=t&268435455;if(i!==0){var r=i&~d;r!==0?a=vt(r):(o&=i,o!==0&&(a=vt(o)))}else i=t&~d,i!==0?a=vt(i):o!==0&&(a=vt(o));if(a===0)return 0;if(e!==0&&e!==a&&!(e&d)&&(d=a&-a,o=e&-e,d>=o||d===16&&(o&4194240)!==0))return e;if(a&4&&(a|=t&16),e=n.entangledLanes,e!==0)for(n=n.entanglements,e&=a;0<e;)t=31-kn(e),d=1<<t,a|=n[t],e&=~d;return a}function du(n,e){switch(n){case 1:case 2:case 4:return e+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function ou(n,e){for(var t=n.suspendedLanes,a=n.pingedLanes,d=n.expirationTimes,o=n.pendingLanes;0<o;){var i=31-kn(o),r=1<<i,l=d[i];l===-1?(!(r&t)||r&a)&&(d[i]=du(r,e)):l<=e&&(n.expiredLanes|=r),o&=~r}}function J0(n){return n=n.pendingLanes&-1073741825,n!==0?n:n&1073741824?1073741824:0}function Bi(){var n=sa;return sa<<=1,!(sa&4194240)&&(sa=64),n}function X0(n){for(var e=[],t=0;31>t;t++)e.push(n);return e}function Nt(n,e,t){n.pendingLanes|=e,e!==536870912&&(n.suspendedLanes=0,n.pingedLanes=0),n=n.eventTimes,e=31-kn(e),n[e]=t}function iu(n,e){var t=n.pendingLanes&~e;n.pendingLanes=e,n.suspendedLanes=0,n.pingedLanes=0,n.expiredLanes&=e,n.mutableReadLanes&=e,n.entangledLanes&=e,e=n.entanglements;var a=n.eventTimes;for(n=n.expirationTimes;0<t;){var d=31-kn(t),o=1<<d;e[d]=0,a[d]=-1,n[d]=-1,t&=~o}}function Z0(n,e){var t=n.entangledLanes|=e;for(n=n.entanglements;t;){var a=31-kn(t),d=1<<a;d&e|n[a]&e&&(n[a]|=e),t&=~d}}var E=0;function Ei(n){return n&=-n,1<n?4<n?n&268435455?16:536870912:4:1}var Ri,q0,Vi,Oi,Fi,nd=!1,pa=[],qn=null,ne=null,ee=null,wt=new Map,It=new Map,te=[],ru="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function zi(n,e){switch(n){case"focusin":case"focusout":qn=null;break;case"dragenter":case"dragleave":ne=null;break;case"mouseover":case"mouseout":ee=null;break;case"pointerover":case"pointerout":wt.delete(e.pointerId);break;case"gotpointercapture":case"lostpointercapture":It.delete(e.pointerId)}}function St(n,e,t,a,d,o){return n===null||n.nativeEvent!==o?(n={blockedOn:e,domEventName:t,eventSystemFlags:a,nativeEvent:o,targetContainers:[d]},e!==null&&(e=Vt(e),e!==null&&q0(e)),n):(n.eventSystemFlags|=a,e=n.targetContainers,d!==null&&e.indexOf(d)===-1&&e.push(d),n)}function lu(n,e,t,a,d){switch(e){case"focusin":return qn=St(qn,n,e,t,a,d),!0;case"dragenter":return ne=St(ne,n,e,t,a,d),!0;case"mouseover":return ee=St(ee,n,e,t,a,d),!0;case"pointerover":var o=d.pointerId;return wt.set(o,St(wt.get(o)||null,n,e,t,a,d)),!0;case"gotpointercapture":return o=d.pointerId,It.set(o,St(It.get(o)||null,n,e,t,a,d)),!0}return!1}function bi(n){var e=Ne(n.target);if(e!==null){var t=ve(e);if(t!==null){if(e=t.tag,e===13){if(e=Ti(t),e!==null){n.blockedOn=e,Fi(n.priority,function(){Vi(t)});return}}else if(e===3&&t.stateNode.current.memoizedState.isDehydrated){n.blockedOn=t.tag===3?t.stateNode.containerInfo:null;return}}}n.blockedOn=null}function fa(n){if(n.blockedOn!==null)return!1;for(var e=n.targetContainers;0<e.length;){var t=td(n.domEventName,n.eventSystemFlags,e[0],n.nativeEvent);if(t===null){t=n.nativeEvent;var a=new t.constructor(t.type,t);U0=a,t.target.dispatchEvent(a),U0=null}else return e=Vt(t),e!==null&&q0(e),n.blockedOn=t,!1;e.shift()}return!0}function ji(n,e,t){fa(n)&&t.delete(e)}function mu(){nd=!1,qn!==null&&fa(qn)&&(qn=null),ne!==null&&fa(ne)&&(ne=null),ee!==null&&fa(ee)&&(ee=null),wt.forEach(ji),It.forEach(ji)}function At(n,e){n.blockedOn===e&&(n.blockedOn=null,nd||(nd=!0,gn.unstable_scheduleCallback(gn.unstable_NormalPriority,mu)))}function Pt(n){function e(d){return At(d,n)}if(0<pa.length){At(pa[0],n);for(var t=1;t<pa.length;t++){var a=pa[t];a.blockedOn===n&&(a.blockedOn=null)}}for(qn!==null&&At(qn,n),ne!==null&&At(ne,n),ee!==null&&At(ee,n),wt.forEach(e),It.forEach(e),t=0;t<te.length;t++)a=te[t],a.blockedOn===n&&(a.blockedOn=null);for(;0<te.length&&(t=te[0],t.blockedOn===null);)bi(t),t.blockedOn===null&&te.shift()}var be=Kn.ReactCurrentBatchConfig,ya=!0;function uu(n,e,t,a){var d=E,o=be.transition;be.transition=null;try{E=1,ed(n,e,t,a)}finally{E=d,be.transition=o}}function su(n,e,t,a){var d=E,o=be.transition;be.transition=null;try{E=4,ed(n,e,t,a)}finally{E=d,be.transition=o}}function ed(n,e,t,a){if(ya){var d=td(n,e,t,a);if(d===null)Nd(n,e,a,ga,t),zi(n,a);else if(lu(d,n,e,t,a))a.stopPropagation();else if(zi(n,a),e&4&&-1<ru.indexOf(n)){for(;d!==null;){var o=Vt(d);if(o!==null&&Ri(o),o=td(n,e,t,a),o===null&&Nd(n,e,a,ga,t),o===d)break;d=o}d!==null&&a.stopPropagation()}else Nd(n,e,a,null,t)}}var ga=null;function td(n,e,t,a){if(ga=null,n=H0(a),n=Ne(n),n!==null)if(e=ve(n),e===null)n=null;else if(t=e.tag,t===13){if(n=Ti(e),n!==null)return n;n=null}else if(t===3){if(e.stateNode.current.memoizedState.isDehydrated)return e.tag===3?e.stateNode.containerInfo:null;n=null}else e!==n&&(n=null);return ga=n,null}function Ki(n){switch(n){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(Zm()){case Q0:return 1;case Di:return 4;case ma:case qm:return 16;case Li:return 536870912;default:return 16}default:return 16}}var ae=null,ad=null,va=null;function Ui(){if(va)return va;var n,e=ad,t=e.length,a,d="value"in ae?ae.value:ae.textContent,o=d.length;for(n=0;n<t&&e[n]===d[n];n++);var i=t-n;for(a=1;a<=i&&e[t-a]===d[o-a];a++);return va=d.slice(n,1<a?1-a:void 0)}function Na(n){var e=n.keyCode;return"charCode"in n?(n=n.charCode,n===0&&e===13&&(n=13)):n=e,n===10&&(n=13),32<=n||n===13?n:0}function wa(){return!0}function Hi(){return!1}function vn(n){function e(t,a,d,o,i){this._reactName=t,this._targetInst=d,this.type=a,this.nativeEvent=o,this.target=i,this.currentTarget=null;for(var r in n)n.hasOwnProperty(r)&&(t=n[r],this[r]=t?t(o):o[r]);return this.isDefaultPrevented=(o.defaultPrevented!=null?o.defaultPrevented:o.returnValue===!1)?wa:Hi,this.isPropagationStopped=Hi,this}return z(e.prototype,{preventDefault:function(){this.defaultPrevented=!0;var t=this.nativeEvent;t&&(t.preventDefault?t.preventDefault():typeof t.returnValue!="unknown"&&(t.returnValue=!1),this.isDefaultPrevented=wa)},stopPropagation:function(){var t=this.nativeEvent;t&&(t.stopPropagation?t.stopPropagation():typeof t.cancelBubble!="unknown"&&(t.cancelBubble=!0),this.isPropagationStopped=wa)},persist:function(){},isPersistent:wa}),e}var je={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(n){return n.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},dd=vn(je),Tt=z({},je,{view:0,detail:0}),cu=vn(Tt),od,id,Mt,Ia=z({},Tt,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:ld,button:0,buttons:0,relatedTarget:function(n){return n.relatedTarget===void 0?n.fromElement===n.srcElement?n.toElement:n.fromElement:n.relatedTarget},movementX:function(n){return"movementX"in n?n.movementX:(n!==Mt&&(Mt&&n.type==="mousemove"?(od=n.screenX-Mt.screenX,id=n.screenY-Mt.screenY):id=od=0,Mt=n),od)},movementY:function(n){return"movementY"in n?n.movementY:id}}),Wi=vn(Ia),hu=z({},Ia,{dataTransfer:0}),pu=vn(hu),fu=z({},Tt,{relatedTarget:0}),rd=vn(fu),yu=z({},je,{animationName:0,elapsedTime:0,pseudoElement:0}),gu=vn(yu),vu=z({},je,{clipboardData:function(n){return"clipboardData"in n?n.clipboardData:window.clipboardData}}),Nu=vn(vu),wu=z({},je,{data:0}),Gi=vn(wu),Iu={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},Su={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},Au={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function Pu(n){var e=this.nativeEvent;return e.getModifierState?e.getModifierState(n):(n=Au[n])?!!e[n]:!1}function ld(){return Pu}var Tu=z({},Tt,{key:function(n){if(n.key){var e=Iu[n.key]||n.key;if(e!=="Unidentified")return e}return n.type==="keypress"?(n=Na(n),n===13?"Enter":String.fromCharCode(n)):n.type==="keydown"||n.type==="keyup"?Su[n.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:ld,charCode:function(n){return n.type==="keypress"?Na(n):0},keyCode:function(n){return n.type==="keydown"||n.type==="keyup"?n.keyCode:0},which:function(n){return n.type==="keypress"?Na(n):n.type==="keydown"||n.type==="keyup"?n.keyCode:0}}),Mu=vn(Tu),Cu=z({},Ia,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),$i=vn(Cu),ku=z({},Tt,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:ld}),xu=vn(ku),_u=z({},je,{propertyName:0,elapsedTime:0,pseudoElement:0}),Du=vn(_u),Lu=z({},Ia,{deltaX:function(n){return"deltaX"in n?n.deltaX:"wheelDeltaX"in n?-n.wheelDeltaX:0},deltaY:function(n){return"deltaY"in n?n.deltaY:"wheelDeltaY"in n?-n.wheelDeltaY:"wheelDelta"in n?-n.wheelDelta:0},deltaZ:0,deltaMode:0}),Bu=vn(Lu),Eu=[9,13,27,32],md=jn&&"CompositionEvent"in window,Ct=null;jn&&"documentMode"in document&&(Ct=document.documentMode);var Ru=jn&&"TextEvent"in window&&!Ct,Yi=jn&&(!md||Ct&&8<Ct&&11>=Ct),Qi=" ",Ji=!1;function Xi(n,e){switch(n){case"keyup":return Eu.indexOf(e.keyCode)!==-1;case"keydown":return e.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Zi(n){return n=n.detail,typeof n=="object"&&"data"in n?n.data:null}var Ke=!1;function Vu(n,e){switch(n){case"compositionend":return Zi(e);case"keypress":return e.which!==32?null:(Ji=!0,Qi);case"textInput":return n=e.data,n===Qi&&Ji?null:n;default:return null}}function Ou(n,e){if(Ke)return n==="compositionend"||!md&&Xi(n,e)?(n=Ui(),va=ad=ae=null,Ke=!1,n):null;switch(n){case"paste":return null;case"keypress":if(!(e.ctrlKey||e.altKey||e.metaKey)||e.ctrlKey&&e.altKey){if(e.char&&1<e.char.length)return e.char;if(e.which)return String.fromCharCode(e.which)}return null;case"compositionend":return Yi&&e.locale!=="ko"?null:e.data;default:return null}}var Fu={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function qi(n){var e=n&&n.nodeName&&n.nodeName.toLowerCase();return e==="input"?!!Fu[n.type]:e==="textarea"}function nr(n,e,t,a){wi(a),e=Ma(e,"onChange"),0<e.length&&(t=new dd("onChange","change",null,t,a),n.push({event:t,listeners:e}))}var kt=null,xt=null;function zu(n){vr(n,0)}function Sa(n){var e=$e(n);if(li(e))return n}function bu(n,e){if(n==="change")return e}var er=!1;if(jn){var ud;if(jn){var sd="oninput"in document;if(!sd){var tr=document.createElement("div");tr.setAttribute("oninput","return;"),sd=typeof tr.oninput=="function"}ud=sd}else ud=!1;er=ud&&(!document.documentMode||9<document.documentMode)}function ar(){kt&&(kt.detachEvent("onpropertychange",dr),xt=kt=null)}function dr(n){if(n.propertyName==="value"&&Sa(xt)){var e=[];nr(e,xt,n,H0(n)),Pi(zu,e)}}function ju(n,e,t){n==="focusin"?(ar(),kt=e,xt=t,kt.attachEvent("onpropertychange",dr)):n==="focusout"&&ar()}function Ku(n){if(n==="selectionchange"||n==="keyup"||n==="keydown")return Sa(xt)}function Uu(n,e){if(n==="click")return Sa(e)}function Hu(n,e){if(n==="input"||n==="change")return Sa(e)}function Wu(n,e){return n===e&&(n!==0||1/n===1/e)||n!==n&&e!==e}var xn=typeof Object.is=="function"?Object.is:Wu;function _t(n,e){if(xn(n,e))return!0;if(typeof n!="object"||n===null||typeof e!="object"||e===null)return!1;var t=Object.keys(n),a=Object.keys(e);if(t.length!==a.length)return!1;for(a=0;a<t.length;a++){var d=t[a];if(!S0.call(e,d)||!xn(n[d],e[d]))return!1}return!0}function or(n){for(;n&&n.firstChild;)n=n.firstChild;return n}function ir(n,e){var t=or(n);n=0;for(var a;t;){if(t.nodeType===3){if(a=n+t.textContent.length,n<=e&&a>=e)return{node:t,offset:e-n};n=a}n:{for(;t;){if(t.nextSibling){t=t.nextSibling;break n}t=t.parentNode}t=void 0}t=or(t)}}function rr(n,e){return n&&e?n===e?!0:n&&n.nodeType===3?!1:e&&e.nodeType===3?rr(n,e.parentNode):"contains"in n?n.contains(e):n.compareDocumentPosition?!!(n.compareDocumentPosition(e)&16):!1:!1}function lr(){for(var n=window,e=oa();e instanceof n.HTMLIFrameElement;){try{var t=typeof e.contentWindow.location.href=="string"}catch(a){t=!1}if(t)n=e.contentWindow;else break;e=oa(n.document)}return e}function cd(n){var e=n&&n.nodeName&&n.nodeName.toLowerCase();return e&&(e==="input"&&(n.type==="text"||n.type==="search"||n.type==="tel"||n.type==="url"||n.type==="password")||e==="textarea"||n.contentEditable==="true")}function Gu(n){var e=lr(),t=n.focusedElem,a=n.selectionRange;if(e!==t&&t&&t.ownerDocument&&rr(t.ownerDocument.documentElement,t)){if(a!==null&&cd(t)){if(e=a.start,n=a.end,n===void 0&&(n=e),"selectionStart"in t)t.selectionStart=e,t.selectionEnd=Math.min(n,t.value.length);else if(n=(e=t.ownerDocument||document)&&e.defaultView||window,n.getSelection){n=n.getSelection();var d=t.textContent.length,o=Math.min(a.start,d);a=a.end===void 0?o:Math.min(a.end,d),!n.extend&&o>a&&(d=a,a=o,o=d),d=ir(t,o);var i=ir(t,a);d&&i&&(n.rangeCount!==1||n.anchorNode!==d.node||n.anchorOffset!==d.offset||n.focusNode!==i.node||n.focusOffset!==i.offset)&&(e=e.createRange(),e.setStart(d.node,d.offset),n.removeAllRanges(),o>a?(n.addRange(e),n.extend(i.node,i.offset)):(e.setEnd(i.node,i.offset),n.addRange(e)))}}for(e=[],n=t;n=n.parentNode;)n.nodeType===1&&e.push({element:n,left:n.scrollLeft,top:n.scrollTop});for(typeof t.focus=="function"&&t.focus(),t=0;t<e.length;t++)n=e[t],n.element.scrollLeft=n.left,n.element.scrollTop=n.top}}var $u=jn&&"documentMode"in document&&11>=document.documentMode,Ue=null,hd=null,Dt=null,pd=!1;function mr(n,e,t){var a=t.window===t?t.document:t.nodeType===9?t:t.ownerDocument;pd||Ue==null||Ue!==oa(a)||(a=Ue,"selectionStart"in a&&cd(a)?a={start:a.selectionStart,end:a.selectionEnd}:(a=(a.ownerDocument&&a.ownerDocument.defaultView||window).getSelection(),a={anchorNode:a.anchorNode,anchorOffset:a.anchorOffset,focusNode:a.focusNode,focusOffset:a.focusOffset}),Dt&&_t(Dt,a)||(Dt=a,a=Ma(hd,"onSelect"),0<a.length&&(e=new dd("onSelect","select",null,e,t),n.push({event:e,listeners:a}),e.target=Ue)))}function Aa(n,e){var t={};return t[n.toLowerCase()]=e.toLowerCase(),t["Webkit"+n]="webkit"+e,t["Moz"+n]="moz"+e,t}var He={animationend:Aa("Animation","AnimationEnd"),animationiteration:Aa("Animation","AnimationIteration"),animationstart:Aa("Animation","AnimationStart"),transitionend:Aa("Transition","TransitionEnd")},fd={},ur={};jn&&(ur=document.createElement("div").style,"AnimationEvent"in window||(delete He.animationend.animation,delete He.animationiteration.animation,delete He.animationstart.animation),"TransitionEvent"in window||delete He.transitionend.transition);function Pa(n){if(fd[n])return fd[n];if(!He[n])return n;var e=He[n],t;for(t in e)if(e.hasOwnProperty(t)&&t in ur)return fd[n]=e[t];return n}var sr=Pa("animationend"),cr=Pa("animationiteration"),hr=Pa("animationstart"),pr=Pa("transitionend"),fr=new Map,yr="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function de(n,e){fr.set(n,e),ge(e,[n])}for(var yd=0;yd<yr.length;yd++){var gd=yr[yd],Yu=gd.toLowerCase(),Qu=gd[0].toUpperCase()+gd.slice(1);de(Yu,"on"+Qu)}de(sr,"onAnimationEnd"),de(cr,"onAnimationIteration"),de(hr,"onAnimationStart"),de("dblclick","onDoubleClick"),de("focusin","onFocus"),de("focusout","onBlur"),de(pr,"onTransitionEnd"),Ee("onMouseEnter",["mouseout","mouseover"]),Ee("onMouseLeave",["mouseout","mouseover"]),Ee("onPointerEnter",["pointerout","pointerover"]),Ee("onPointerLeave",["pointerout","pointerover"]),ge("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),ge("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),ge("onBeforeInput",["compositionend","keypress","textInput","paste"]),ge("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),ge("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),ge("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Lt="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Ju=new Set("cancel close invalid load scroll toggle".split(" ").concat(Lt));function gr(n,e,t){var a=n.type||"unknown-event";n.currentTarget=t,Ym(a,e,void 0,n),n.currentTarget=null}function vr(n,e){e=(e&4)!==0;for(var t=0;t<n.length;t++){var a=n[t],d=a.event;a=a.listeners;n:{var o=void 0;if(e)for(var i=a.length-1;0<=i;i--){var r=a[i],l=r.instance,u=r.currentTarget;if(r=r.listener,l!==o&&d.isPropagationStopped())break n;gr(d,r,u),o=l}else for(i=0;i<a.length;i++){if(r=a[i],l=r.instance,u=r.currentTarget,r=r.listener,l!==o&&d.isPropagationStopped())break n;gr(d,r,u),o=l}}}if(la)throw n=Y0,la=!1,Y0=null,n}function V(n,e){var t=e[Td];t===void 0&&(t=e[Td]=new Set);var a=n+"__bubble";t.has(a)||(Nr(e,n,2,!1),t.add(a))}function vd(n,e,t){var a=0;e&&(a|=4),Nr(t,n,a,e)}var Ta="_reactListening"+Math.random().toString(36).slice(2);function Bt(n){if(!n[Ta]){n[Ta]=!0,ni.forEach(function(t){t!=="selectionchange"&&(Ju.has(t)||vd(t,!1,n),vd(t,!0,n))});var e=n.nodeType===9?n:n.ownerDocument;e===null||e[Ta]||(e[Ta]=!0,vd("selectionchange",!1,e))}}function Nr(n,e,t,a){switch(Ki(e)){case 1:var d=uu;break;case 4:d=su;break;default:d=ed}t=d.bind(null,e,t,n),d=void 0,!$0||e!=="touchstart"&&e!=="touchmove"&&e!=="wheel"||(d=!0),a?d!==void 0?n.addEventListener(e,t,{capture:!0,passive:d}):n.addEventListener(e,t,!0):d!==void 0?n.addEventListener(e,t,{passive:d}):n.addEventListener(e,t,!1)}function Nd(n,e,t,a,d){var o=a;if(!(e&1)&&!(e&2)&&a!==null)n:for(;;){if(a===null)return;var i=a.tag;if(i===3||i===4){var r=a.stateNode.containerInfo;if(r===d||r.nodeType===8&&r.parentNode===d)break;if(i===4)for(i=a.return;i!==null;){var l=i.tag;if((l===3||l===4)&&(l=i.stateNode.containerInfo,l===d||l.nodeType===8&&l.parentNode===d))return;i=i.return}for(;r!==null;){if(i=Ne(r),i===null)return;if(l=i.tag,l===5||l===6){a=o=i;continue n}r=r.parentNode}}a=a.return}Pi(function(){var u=o,y=H0(t),f=[];n:{var p=fr.get(n);if(p!==void 0){var g=dd,N=n;switch(n){case"keypress":if(Na(t)===0)break n;case"keydown":case"keyup":g=Mu;break;case"focusin":N="focus",g=rd;break;case"focusout":N="blur",g=rd;break;case"beforeblur":case"afterblur":g=rd;break;case"click":if(t.button===2)break n;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":g=Wi;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":g=pu;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":g=xu;break;case sr:case cr:case hr:g=gu;break;case pr:g=Du;break;case"scroll":g=cu;break;case"wheel":g=Bu;break;case"copy":case"cut":case"paste":g=Nu;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":g=$i}var w=(e&4)!==0,D=!w&&n==="scroll",h=w?p!==null?p+"Capture":null:p;w=[];for(var m=u,c;m!==null;){c=m;var v=c.stateNode;if(c.tag===5&&v!==null&&(c=v,h!==null&&(v=ft(m,h),v!=null&&w.push(Et(m,v,c)))),D)break;m=m.return}0<w.length&&(p=new g(p,N,null,t,y),f.push({event:p,listeners:w}))}}if(!(e&7)){n:{if(p=n==="mouseover"||n==="pointerover",g=n==="mouseout"||n==="pointerout",p&&t!==U0&&(N=t.relatedTarget||t.fromElement)&&(Ne(N)||N[Un]))break n;if((g||p)&&(p=y.window===y?y:(p=y.ownerDocument)?p.defaultView||p.parentWindow:window,g?(N=t.relatedTarget||t.toElement,g=u,N=N?Ne(N):null,N!==null&&(D=ve(N),N!==D||N.tag!==5&&N.tag!==6)&&(N=null)):(g=null,N=u),g!==N)){if(w=Wi,v="onMouseLeave",h="onMouseEnter",m="mouse",(n==="pointerout"||n==="pointerover")&&(w=$i,v="onPointerLeave",h="onPointerEnter",m="pointer"),D=g==null?p:$e(g),c=N==null?p:$e(N),p=new w(v,m+"leave",g,t,y),p.target=D,p.relatedTarget=c,v=null,Ne(y)===u&&(w=new w(h,m+"enter",N,t,y),w.target=c,w.relatedTarget=D,v=w),D=v,g&&N)e:{for(w=g,h=N,m=0,c=w;c;c=We(c))m++;for(c=0,v=h;v;v=We(v))c++;for(;0<m-c;)w=We(w),m--;for(;0<c-m;)h=We(h),c--;for(;m--;){if(w===h||h!==null&&w===h.alternate)break e;w=We(w),h=We(h)}w=null}else w=null;g!==null&&wr(f,p,g,w,!1),N!==null&&D!==null&&wr(f,D,N,w,!0)}}n:{if(p=u?$e(u):window,g=p.nodeName&&p.nodeName.toLowerCase(),g==="select"||g==="input"&&p.type==="file")var S=bu;else if(qi(p))if(er)S=Hu;else{S=Ku;var T=ju}else(g=p.nodeName)&&g.toLowerCase()==="input"&&(p.type==="checkbox"||p.type==="radio")&&(S=Uu);if(S&&(S=S(n,u))){nr(f,S,t,y);break n}T&&T(n,p,u),n==="focusout"&&(T=p._wrapperState)&&T.controlled&&p.type==="number"&&F0(p,"number",p.value)}switch(T=u?$e(u):window,n){case"focusin":(qi(T)||T.contentEditable==="true")&&(Ue=T,hd=u,Dt=null);break;case"focusout":Dt=hd=Ue=null;break;case"mousedown":pd=!0;break;case"contextmenu":case"mouseup":case"dragend":pd=!1,mr(f,t,y);break;case"selectionchange":if($u)break;case"keydown":case"keyup":mr(f,t,y)}var M;if(md)n:{switch(n){case"compositionstart":var C="onCompositionStart";break n;case"compositionend":C="onCompositionEnd";break n;case"compositionupdate":C="onCompositionUpdate";break n}C=void 0}else Ke?Xi(n,t)&&(C="onCompositionEnd"):n==="keydown"&&t.keyCode===229&&(C="onCompositionStart");C&&(Yi&&t.locale!=="ko"&&(Ke||C!=="onCompositionStart"?C==="onCompositionEnd"&&Ke&&(M=Ui()):(ae=y,ad="value"in ae?ae.value:ae.textContent,Ke=!0)),T=Ma(u,C),0<T.length&&(C=new Gi(C,n,null,t,y),f.push({event:C,listeners:T}),M?C.data=M:(M=Zi(t),M!==null&&(C.data=M)))),(M=Ru?Vu(n,t):Ou(n,t))&&(u=Ma(u,"onBeforeInput"),0<u.length&&(y=new Gi("onBeforeInput","beforeinput",null,t,y),f.push({event:y,listeners:u}),y.data=M))}vr(f,e)})}function Et(n,e,t){return{instance:n,listener:e,currentTarget:t}}function Ma(n,e){for(var t=e+"Capture",a=[];n!==null;){var d=n,o=d.stateNode;d.tag===5&&o!==null&&(d=o,o=ft(n,t),o!=null&&a.unshift(Et(n,o,d)),o=ft(n,e),o!=null&&a.push(Et(n,o,d))),n=n.return}return a}function We(n){if(n===null)return null;do n=n.return;while(n&&n.tag!==5);return n||null}function wr(n,e,t,a,d){for(var o=e._reactName,i=[];t!==null&&t!==a;){var r=t,l=r.alternate,u=r.stateNode;if(l!==null&&l===a)break;r.tag===5&&u!==null&&(r=u,d?(l=ft(t,o),l!=null&&i.unshift(Et(t,l,r))):d||(l=ft(t,o),l!=null&&i.push(Et(t,l,r)))),t=t.return}i.length!==0&&n.push({event:e,listeners:i})}var Xu=/\r\n?/g,Zu=/\u0000|\uFFFD/g;function Ir(n){return(typeof n=="string"?n:""+n).replace(Xu,`
`).replace(Zu,"")}function Ca(n,e,t){if(e=Ir(e),Ir(n)!==e&&t)throw Error(I(425))}function ka(){}var wd=null,Id=null;function Sd(n,e){return n==="textarea"||n==="noscript"||typeof e.children=="string"||typeof e.children=="number"||typeof e.dangerouslySetInnerHTML=="object"&&e.dangerouslySetInnerHTML!==null&&e.dangerouslySetInnerHTML.__html!=null}var Ad=typeof setTimeout=="function"?setTimeout:void 0,qu=typeof clearTimeout=="function"?clearTimeout:void 0,Sr=typeof Promise=="function"?Promise:void 0,ns=typeof queueMicrotask=="function"?queueMicrotask:typeof Sr<"u"?function(n){return Sr.resolve(null).then(n).catch(es)}:Ad;function es(n){setTimeout(function(){throw n})}function Pd(n,e){var t=e,a=0;do{var d=t.nextSibling;if(n.removeChild(t),d&&d.nodeType===8)if(t=d.data,t==="/$"){if(a===0){n.removeChild(d),Pt(e);return}a--}else t!=="$"&&t!=="$?"&&t!=="$!"||a++;t=d}while(t);Pt(e)}function oe(n){for(;n!=null;n=n.nextSibling){var e=n.nodeType;if(e===1||e===3)break;if(e===8){if(e=n.data,e==="$"||e==="$!"||e==="$?")break;if(e==="/$")return null}}return n}function Ar(n){n=n.previousSibling;for(var e=0;n;){if(n.nodeType===8){var t=n.data;if(t==="$"||t==="$!"||t==="$?"){if(e===0)return n;e--}else t==="/$"&&e++}n=n.previousSibling}return null}var Ge=Math.random().toString(36).slice(2),On="__reactFiber$"+Ge,Rt="__reactProps$"+Ge,Un="__reactContainer$"+Ge,Td="__reactEvents$"+Ge,ts="__reactListeners$"+Ge,as="__reactHandles$"+Ge;function Ne(n){var e=n[On];if(e)return e;for(var t=n.parentNode;t;){if(e=t[Un]||t[On]){if(t=e.alternate,e.child!==null||t!==null&&t.child!==null)for(n=Ar(n);n!==null;){if(t=n[On])return t;n=Ar(n)}return e}n=t,t=n.parentNode}return null}function Vt(n){return n=n[On]||n[Un],!n||n.tag!==5&&n.tag!==6&&n.tag!==13&&n.tag!==3?null:n}function $e(n){if(n.tag===5||n.tag===6)return n.stateNode;throw Error(I(33))}function xa(n){return n[Rt]||null}var Md=[],Ye=-1;function ie(n){return{current:n}}function O(n){0>Ye||(n.current=Md[Ye],Md[Ye]=null,Ye--)}function R(n,e){Ye++,Md[Ye]=n.current,n.current=e}var re={},tn=ie(re),sn=ie(!1),we=re;function Qe(n,e){var t=n.type.contextTypes;if(!t)return re;var a=n.stateNode;if(a&&a.__reactInternalMemoizedUnmaskedChildContext===e)return a.__reactInternalMemoizedMaskedChildContext;var d={},o;for(o in t)d[o]=e[o];return a&&(n=n.stateNode,n.__reactInternalMemoizedUnmaskedChildContext=e,n.__reactInternalMemoizedMaskedChildContext=d),d}function cn(n){return n=n.childContextTypes,n!=null}function _a(){O(sn),O(tn)}function Pr(n,e,t){if(tn.current!==re)throw Error(I(168));R(tn,e),R(sn,t)}function Tr(n,e,t){var a=n.stateNode;if(e=e.childContextTypes,typeof a.getChildContext!="function")return t;a=a.getChildContext();for(var d in a)if(!(d in e))throw Error(I(108,jm(n)||"Unknown",d));return z({},t,a)}function Da(n){return n=(n=n.stateNode)&&n.__reactInternalMemoizedMergedChildContext||re,we=tn.current,R(tn,n),R(sn,sn.current),!0}function Mr(n,e,t){var a=n.stateNode;if(!a)throw Error(I(169));t?(n=Tr(n,e,we),a.__reactInternalMemoizedMergedChildContext=n,O(sn),O(tn),R(tn,n)):O(sn),R(sn,t)}var Hn=null,La=!1,Cd=!1;function Cr(n){Hn===null?Hn=[n]:Hn.push(n)}function ds(n){La=!0,Cr(n)}function le(){if(!Cd&&Hn!==null){Cd=!0;var n=0,e=E;try{var t=Hn;for(E=1;n<t.length;n++){var a=t[n];do a=a(!0);while(a!==null)}Hn=null,La=!1}catch(d){throw Hn!==null&&(Hn=Hn.slice(n+1)),xi(Q0,le),d}finally{E=e,Cd=!1}}return null}var Je=[],Xe=0,Ba=null,Ea=0,Sn=[],An=0,Ie=null,Wn=1,Gn="";function Se(n,e){Je[Xe++]=Ea,Je[Xe++]=Ba,Ba=n,Ea=e}function kr(n,e,t){Sn[An++]=Wn,Sn[An++]=Gn,Sn[An++]=Ie,Ie=n;var a=Wn;n=Gn;var d=32-kn(a)-1;a&=~(1<<d),t+=1;var o=32-kn(e)+d;if(30<o){var i=d-d%5;o=(a&(1<<i)-1).toString(32),a>>=i,d-=i,Wn=1<<32-kn(e)+d|t<<d|a,Gn=o+n}else Wn=1<<o|t<<d|a,Gn=n}function kd(n){n.return!==null&&(Se(n,1),kr(n,1,0))}function xd(n){for(;n===Ba;)Ba=Je[--Xe],Je[Xe]=null,Ea=Je[--Xe],Je[Xe]=null;for(;n===Ie;)Ie=Sn[--An],Sn[An]=null,Gn=Sn[--An],Sn[An]=null,Wn=Sn[--An],Sn[An]=null}var Nn=null,wn=null,F=!1,_n=null;function xr(n,e){var t=Cn(5,null,null,0);t.elementType="DELETED",t.stateNode=e,t.return=n,e=n.deletions,e===null?(n.deletions=[t],n.flags|=16):e.push(t)}function _r(n,e){switch(n.tag){case 5:var t=n.type;return e=e.nodeType!==1||t.toLowerCase()!==e.nodeName.toLowerCase()?null:e,e!==null?(n.stateNode=e,Nn=n,wn=oe(e.firstChild),!0):!1;case 6:return e=n.pendingProps===""||e.nodeType!==3?null:e,e!==null?(n.stateNode=e,Nn=n,wn=null,!0):!1;case 13:return e=e.nodeType!==8?null:e,e!==null?(t=Ie!==null?{id:Wn,overflow:Gn}:null,n.memoizedState={dehydrated:e,treeContext:t,retryLane:1073741824},t=Cn(18,null,null,0),t.stateNode=e,t.return=n,n.child=t,Nn=n,wn=null,!0):!1;default:return!1}}function _d(n){return(n.mode&1)!==0&&(n.flags&128)===0}function Dd(n){if(F){var e=wn;if(e){var t=e;if(!_r(n,e)){if(_d(n))throw Error(I(418));e=oe(t.nextSibling);var a=Nn;e&&_r(n,e)?xr(a,t):(n.flags=n.flags&-4097|2,F=!1,Nn=n)}}else{if(_d(n))throw Error(I(418));n.flags=n.flags&-4097|2,F=!1,Nn=n}}}function Dr(n){for(n=n.return;n!==null&&n.tag!==5&&n.tag!==3&&n.tag!==13;)n=n.return;Nn=n}function Ra(n){if(n!==Nn)return!1;if(!F)return Dr(n),F=!0,!1;var e;if((e=n.tag!==3)&&!(e=n.tag!==5)&&(e=n.type,e=e!=="head"&&e!=="body"&&!Sd(n.type,n.memoizedProps)),e&&(e=wn)){if(_d(n))throw Lr(),Error(I(418));for(;e;)xr(n,e),e=oe(e.nextSibling)}if(Dr(n),n.tag===13){if(n=n.memoizedState,n=n!==null?n.dehydrated:null,!n)throw Error(I(317));n:{for(n=n.nextSibling,e=0;n;){if(n.nodeType===8){var t=n.data;if(t==="/$"){if(e===0){wn=oe(n.nextSibling);break n}e--}else t!=="$"&&t!=="$!"&&t!=="$?"||e++}n=n.nextSibling}wn=null}}else wn=Nn?oe(n.stateNode.nextSibling):null;return!0}function Lr(){for(var n=wn;n;)n=oe(n.nextSibling)}function Ze(){wn=Nn=null,F=!1}function Ld(n){_n===null?_n=[n]:_n.push(n)}var os=Kn.ReactCurrentBatchConfig;function Ot(n,e,t){if(n=t.ref,n!==null&&typeof n!="function"&&typeof n!="object"){if(t._owner){if(t=t._owner,t){if(t.tag!==1)throw Error(I(309));var a=t.stateNode}if(!a)throw Error(I(147,n));var d=a,o=""+n;return e!==null&&e.ref!==null&&typeof e.ref=="function"&&e.ref._stringRef===o?e.ref:(e=function(i){var r=d.refs;i===null?delete r[o]:r[o]=i},e._stringRef=o,e)}if(typeof n!="string")throw Error(I(284));if(!t._owner)throw Error(I(290,n))}return n}function Va(n,e){throw n=Object.prototype.toString.call(e),Error(I(31,n==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":n))}function Br(n){var e=n._init;return e(n._payload)}function Er(n){function e(h,m){if(n){var c=h.deletions;c===null?(h.deletions=[m],h.flags|=16):c.push(m)}}function t(h,m){if(!n)return null;for(;m!==null;)e(h,m),m=m.sibling;return null}function a(h,m){for(h=new Map;m!==null;)m.key!==null?h.set(m.key,m):h.set(m.index,m),m=m.sibling;return h}function d(h,m){return h=ye(h,m),h.index=0,h.sibling=null,h}function o(h,m,c){return h.index=c,n?(c=h.alternate,c!==null?(c=c.index,c<m?(h.flags|=2,m):c):(h.flags|=2,m)):(h.flags|=1048576,m)}function i(h){return n&&h.alternate===null&&(h.flags|=2),h}function r(h,m,c,v){return m===null||m.tag!==6?(m=Po(c,h.mode,v),m.return=h,m):(m=d(m,c),m.return=h,m)}function l(h,m,c,v){var S=c.type;return S===Ve?y(h,m,c.props.children,v,c.key):m!==null&&(m.elementType===S||typeof S=="object"&&S!==null&&S.$$typeof===Xn&&Br(S)===m.type)?(v=d(m,c.props),v.ref=Ot(h,m,c),v.return=h,v):(v=i0(c.type,c.key,c.props,null,h.mode,v),v.ref=Ot(h,m,c),v.return=h,v)}function u(h,m,c,v){return m===null||m.tag!==4||m.stateNode.containerInfo!==c.containerInfo||m.stateNode.implementation!==c.implementation?(m=To(c,h.mode,v),m.return=h,m):(m=d(m,c.children||[]),m.return=h,m)}function y(h,m,c,v,S){return m===null||m.tag!==7?(m=_e(c,h.mode,v,S),m.return=h,m):(m=d(m,c),m.return=h,m)}function f(h,m,c){if(typeof m=="string"&&m!==""||typeof m=="number")return m=Po(""+m,h.mode,c),m.return=h,m;if(typeof m=="object"&&m!==null){switch(m.$$typeof){case aa:return c=i0(m.type,m.key,m.props,null,h.mode,c),c.ref=Ot(h,null,m),c.return=h,c;case Re:return m=To(m,h.mode,c),m.return=h,m;case Xn:var v=m._init;return f(h,v(m._payload),c)}if(ct(m)||ut(m))return m=_e(m,h.mode,c,null),m.return=h,m;Va(h,m)}return null}function p(h,m,c,v){var S=m!==null?m.key:null;if(typeof c=="string"&&c!==""||typeof c=="number")return S!==null?null:r(h,m,""+c,v);if(typeof c=="object"&&c!==null){switch(c.$$typeof){case aa:return c.key===S?l(h,m,c,v):null;case Re:return c.key===S?u(h,m,c,v):null;case Xn:return S=c._init,p(h,m,S(c._payload),v)}if(ct(c)||ut(c))return S!==null?null:y(h,m,c,v,null);Va(h,c)}return null}function g(h,m,c,v,S){if(typeof v=="string"&&v!==""||typeof v=="number")return h=h.get(c)||null,r(m,h,""+v,S);if(typeof v=="object"&&v!==null){switch(v.$$typeof){case aa:return h=h.get(v.key===null?c:v.key)||null,l(m,h,v,S);case Re:return h=h.get(v.key===null?c:v.key)||null,u(m,h,v,S);case Xn:var T=v._init;return g(h,m,c,T(v._payload),S)}if(ct(v)||ut(v))return h=h.get(c)||null,y(m,h,v,S,null);Va(m,v)}return null}function N(h,m,c,v){for(var S=null,T=null,M=m,C=m=0,W=null;M!==null&&C<c.length;C++){M.index>C?(W=M,M=null):W=M.sibling;var L=p(h,M,c[C],v);if(L===null){M===null&&(M=W);break}n&&M&&L.alternate===null&&e(h,M),m=o(L,m,C),T===null?S=L:T.sibling=L,T=L,M=W}if(C===c.length)return t(h,M),F&&Se(h,C),S;if(M===null){for(;C<c.length;C++)M=f(h,c[C],v),M!==null&&(m=o(M,m,C),T===null?S=M:T.sibling=M,T=M);return F&&Se(h,C),S}for(M=a(h,M);C<c.length;C++)W=g(M,h,C,c[C],v),W!==null&&(n&&W.alternate!==null&&M.delete(W.key===null?C:W.key),m=o(W,m,C),T===null?S=W:T.sibling=W,T=W);return n&&M.forEach(function(Rn){return e(h,Rn)}),F&&Se(h,C),S}function w(h,m,c,v){var S=ut(c);if(typeof S!="function")throw Error(I(150));if(c=S.call(c),c==null)throw Error(I(151));for(var T=S=null,M=m,C=m=0,W=null,L=c.next();M!==null&&!L.done;C++,L=c.next()){M.index>C?(W=M,M=null):W=M.sibling;var Rn=p(h,M,L.value,v);if(Rn===null){M===null&&(M=W);break}n&&M&&Rn.alternate===null&&e(h,M),m=o(Rn,m,C),T===null?S=Rn:T.sibling=Rn,T=Rn,M=W}if(L.done)return t(h,M),F&&Se(h,C),S;if(M===null){for(;!L.done;C++,L=c.next())L=f(h,L.value,v),L!==null&&(m=o(L,m,C),T===null?S=L:T.sibling=L,T=L);return F&&Se(h,C),S}for(M=a(h,M);!L.done;C++,L=c.next())L=g(M,h,C,L.value,v),L!==null&&(n&&L.alternate!==null&&M.delete(L.key===null?C:L.key),m=o(L,m,C),T===null?S=L:T.sibling=L,T=L);return n&&M.forEach(function(Xt){return e(h,Xt)}),F&&Se(h,C),S}function D(h,m,c,v){if(typeof c=="object"&&c!==null&&c.type===Ve&&c.key===null&&(c=c.props.children),typeof c=="object"&&c!==null){switch(c.$$typeof){case aa:n:{for(var S=c.key,T=m;T!==null;){if(T.key===S){if(S=c.type,S===Ve){if(T.tag===7){t(h,T.sibling),m=d(T,c.props.children),m.return=h,h=m;break n}}else if(T.elementType===S||typeof S=="object"&&S!==null&&S.$$typeof===Xn&&Br(S)===T.type){t(h,T.sibling),m=d(T,c.props),m.ref=Ot(h,T,c),m.return=h,h=m;break n}t(h,T);break}else e(h,T);T=T.sibling}c.type===Ve?(m=_e(c.props.children,h.mode,v,c.key),m.return=h,h=m):(v=i0(c.type,c.key,c.props,null,h.mode,v),v.ref=Ot(h,m,c),v.return=h,h=v)}return i(h);case Re:n:{for(T=c.key;m!==null;){if(m.key===T)if(m.tag===4&&m.stateNode.containerInfo===c.containerInfo&&m.stateNode.implementation===c.implementation){t(h,m.sibling),m=d(m,c.children||[]),m.return=h,h=m;break n}else{t(h,m);break}else e(h,m);m=m.sibling}m=To(c,h.mode,v),m.return=h,h=m}return i(h);case Xn:return T=c._init,D(h,m,T(c._payload),v)}if(ct(c))return N(h,m,c,v);if(ut(c))return w(h,m,c,v);Va(h,c)}return typeof c=="string"&&c!==""||typeof c=="number"?(c=""+c,m!==null&&m.tag===6?(t(h,m.sibling),m=d(m,c),m.return=h,h=m):(t(h,m),m=Po(c,h.mode,v),m.return=h,h=m),i(h)):t(h,m)}return D}var qe=Er(!0),Rr=Er(!1),Oa=ie(null),Fa=null,nt=null,Bd=null;function Ed(){Bd=nt=Fa=null}function Rd(n){var e=Oa.current;O(Oa),n._currentValue=e}function Vd(n,e,t){for(;n!==null;){var a=n.alternate;if((n.childLanes&e)!==e?(n.childLanes|=e,a!==null&&(a.childLanes|=e)):a!==null&&(a.childLanes&e)!==e&&(a.childLanes|=e),n===t)break;n=n.return}}function et(n,e){Fa=n,Bd=nt=null,n=n.dependencies,n!==null&&n.firstContext!==null&&(n.lanes&e&&(hn=!0),n.firstContext=null)}function Pn(n){var e=n._currentValue;if(Bd!==n)if(n={context:n,memoizedValue:e,next:null},nt===null){if(Fa===null)throw Error(I(308));nt=n,Fa.dependencies={lanes:0,firstContext:n}}else nt=nt.next=n;return e}var Ae=null;function Od(n){Ae===null?Ae=[n]:Ae.push(n)}function Vr(n,e,t,a){var d=e.interleaved;return d===null?(t.next=t,Od(e)):(t.next=d.next,d.next=t),e.interleaved=t,$n(n,a)}function $n(n,e){n.lanes|=e;var t=n.alternate;for(t!==null&&(t.lanes|=e),t=n,n=n.return;n!==null;)n.childLanes|=e,t=n.alternate,t!==null&&(t.childLanes|=e),t=n,n=n.return;return t.tag===3?t.stateNode:null}var me=!1;function Fd(n){n.updateQueue={baseState:n.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function Or(n,e){n=n.updateQueue,e.updateQueue===n&&(e.updateQueue={baseState:n.baseState,firstBaseUpdate:n.firstBaseUpdate,lastBaseUpdate:n.lastBaseUpdate,shared:n.shared,effects:n.effects})}function Yn(n,e){return{eventTime:n,lane:e,tag:0,payload:null,callback:null,next:null}}function ue(n,e,t){var a=n.updateQueue;if(a===null)return null;if(a=a.shared,B&2){var d=a.pending;return d===null?e.next=e:(e.next=d.next,d.next=e),a.pending=e,$n(n,t)}return d=a.interleaved,d===null?(e.next=e,Od(a)):(e.next=d.next,d.next=e),a.interleaved=e,$n(n,t)}function za(n,e,t){if(e=e.updateQueue,e!==null&&(e=e.shared,(t&4194240)!==0)){var a=e.lanes;a&=n.pendingLanes,t|=a,e.lanes=t,Z0(n,t)}}function Fr(n,e){var t=n.updateQueue,a=n.alternate;if(a!==null&&(a=a.updateQueue,t===a)){var d=null,o=null;if(t=t.firstBaseUpdate,t!==null){do{var i={eventTime:t.eventTime,lane:t.lane,tag:t.tag,payload:t.payload,callback:t.callback,next:null};o===null?d=o=i:o=o.next=i,t=t.next}while(t!==null);o===null?d=o=e:o=o.next=e}else d=o=e;t={baseState:a.baseState,firstBaseUpdate:d,lastBaseUpdate:o,shared:a.shared,effects:a.effects},n.updateQueue=t;return}n=t.lastBaseUpdate,n===null?t.firstBaseUpdate=e:n.next=e,t.lastBaseUpdate=e}function ba(n,e,t,a){var d=n.updateQueue;me=!1;var o=d.firstBaseUpdate,i=d.lastBaseUpdate,r=d.shared.pending;if(r!==null){d.shared.pending=null;var l=r,u=l.next;l.next=null,i===null?o=u:i.next=u,i=l;var y=n.alternate;y!==null&&(y=y.updateQueue,r=y.lastBaseUpdate,r!==i&&(r===null?y.firstBaseUpdate=u:r.next=u,y.lastBaseUpdate=l))}if(o!==null){var f=d.baseState;i=0,y=u=l=null,r=o;do{var p=r.lane,g=r.eventTime;if((a&p)===p){y!==null&&(y=y.next={eventTime:g,lane:0,tag:r.tag,payload:r.payload,callback:r.callback,next:null});n:{var N=n,w=r;switch(p=e,g=t,w.tag){case 1:if(N=w.payload,typeof N=="function"){f=N.call(g,f,p);break n}f=N;break n;case 3:N.flags=N.flags&-65537|128;case 0:if(N=w.payload,p=typeof N=="function"?N.call(g,f,p):N,p==null)break n;f=z({},f,p);break n;case 2:me=!0}}r.callback!==null&&r.lane!==0&&(n.flags|=64,p=d.effects,p===null?d.effects=[r]:p.push(r))}else g={eventTime:g,lane:p,tag:r.tag,payload:r.payload,callback:r.callback,next:null},y===null?(u=y=g,l=f):y=y.next=g,i|=p;if(r=r.next,r===null){if(r=d.shared.pending,r===null)break;p=r,r=p.next,p.next=null,d.lastBaseUpdate=p,d.shared.pending=null}}while(!0);if(y===null&&(l=f),d.baseState=l,d.firstBaseUpdate=u,d.lastBaseUpdate=y,e=d.shared.interleaved,e!==null){d=e;do i|=d.lane,d=d.next;while(d!==e)}else o===null&&(d.shared.lanes=0);Me|=i,n.lanes=i,n.memoizedState=f}}function zr(n,e,t){if(n=e.effects,e.effects=null,n!==null)for(e=0;e<n.length;e++){var a=n[e],d=a.callback;if(d!==null){if(a.callback=null,a=t,typeof d!="function")throw Error(I(191,d));d.call(a)}}}var Ft={},Fn=ie(Ft),zt=ie(Ft),bt=ie(Ft);function Pe(n){if(n===Ft)throw Error(I(174));return n}function zd(n,e){switch(R(bt,e),R(zt,n),R(Fn,Ft),n=e.nodeType,n){case 9:case 11:e=(e=e.documentElement)?e.namespaceURI:b0(null,"");break;default:n=n===8?e.parentNode:e,e=n.namespaceURI||null,n=n.tagName,e=b0(e,n)}O(Fn),R(Fn,e)}function tt(){O(Fn),O(zt),O(bt)}function br(n){Pe(bt.current);var e=Pe(Fn.current),t=b0(e,n.type);e!==t&&(R(zt,n),R(Fn,t))}function bd(n){zt.current===n&&(O(Fn),O(zt))}var b=ie(0);function ja(n){for(var e=n;e!==null;){if(e.tag===13){var t=e.memoizedState;if(t!==null&&(t=t.dehydrated,t===null||t.data==="$?"||t.data==="$!"))return e}else if(e.tag===19&&e.memoizedProps.revealOrder!==void 0){if(e.flags&128)return e}else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===n)break;for(;e.sibling===null;){if(e.return===null||e.return===n)return null;e=e.return}e.sibling.return=e.return,e=e.sibling}return null}var jd=[];function Kd(){for(var n=0;n<jd.length;n++)jd[n]._workInProgressVersionPrimary=null;jd.length=0}var Ka=Kn.ReactCurrentDispatcher,Ud=Kn.ReactCurrentBatchConfig,Te=0,j=null,Y=null,J=null,Ua=!1,jt=!1,Kt=0,is=0;function an(){throw Error(I(321))}function Hd(n,e){if(e===null)return!1;for(var t=0;t<e.length&&t<n.length;t++)if(!xn(n[t],e[t]))return!1;return!0}function Wd(n,e,t,a,d,o){if(Te=o,j=e,e.memoizedState=null,e.updateQueue=null,e.lanes=0,Ka.current=n===null||n.memoizedState===null?us:ss,n=t(a,d),jt){o=0;do{if(jt=!1,Kt=0,25<=o)throw Error(I(301));o+=1,J=Y=null,e.updateQueue=null,Ka.current=cs,n=t(a,d)}while(jt)}if(Ka.current=Ga,e=Y!==null&&Y.next!==null,Te=0,J=Y=j=null,Ua=!1,e)throw Error(I(300));return n}function Gd(){var n=Kt!==0;return Kt=0,n}function zn(){var n={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return J===null?j.memoizedState=J=n:J=J.next=n,J}function Tn(){if(Y===null){var n=j.alternate;n=n!==null?n.memoizedState:null}else n=Y.next;var e=J===null?j.memoizedState:J.next;if(e!==null)J=e,Y=n;else{if(n===null)throw Error(I(310));Y=n,n={memoizedState:Y.memoizedState,baseState:Y.baseState,baseQueue:Y.baseQueue,queue:Y.queue,next:null},J===null?j.memoizedState=J=n:J=J.next=n}return J}function Ut(n,e){return typeof e=="function"?e(n):e}function $d(n){var e=Tn(),t=e.queue;if(t===null)throw Error(I(311));t.lastRenderedReducer=n;var a=Y,d=a.baseQueue,o=t.pending;if(o!==null){if(d!==null){var i=d.next;d.next=o.next,o.next=i}a.baseQueue=d=o,t.pending=null}if(d!==null){o=d.next,a=a.baseState;var r=i=null,l=null,u=o;do{var y=u.lane;if((Te&y)===y)l!==null&&(l=l.next={lane:0,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),a=u.hasEagerState?u.eagerState:n(a,u.action);else{var f={lane:y,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null};l===null?(r=l=f,i=a):l=l.next=f,j.lanes|=y,Me|=y}u=u.next}while(u!==null&&u!==o);l===null?i=a:l.next=r,xn(a,e.memoizedState)||(hn=!0),e.memoizedState=a,e.baseState=i,e.baseQueue=l,t.lastRenderedState=a}if(n=t.interleaved,n!==null){d=n;do o=d.lane,j.lanes|=o,Me|=o,d=d.next;while(d!==n)}else d===null&&(t.lanes=0);return[e.memoizedState,t.dispatch]}function Yd(n){var e=Tn(),t=e.queue;if(t===null)throw Error(I(311));t.lastRenderedReducer=n;var a=t.dispatch,d=t.pending,o=e.memoizedState;if(d!==null){t.pending=null;var i=d=d.next;do o=n(o,i.action),i=i.next;while(i!==d);xn(o,e.memoizedState)||(hn=!0),e.memoizedState=o,e.baseQueue===null&&(e.baseState=o),t.lastRenderedState=o}return[o,a]}function jr(){}function Kr(n,e){var t=j,a=Tn(),d=e(),o=!xn(a.memoizedState,d);if(o&&(a.memoizedState=d,hn=!0),a=a.queue,Qd(Wr.bind(null,t,a,n),[n]),a.getSnapshot!==e||o||J!==null&&J.memoizedState.tag&1){if(t.flags|=2048,Ht(9,Hr.bind(null,t,a,d,e),void 0,null),X===null)throw Error(I(349));Te&30||Ur(t,e,d)}return d}function Ur(n,e,t){n.flags|=16384,n={getSnapshot:e,value:t},e=j.updateQueue,e===null?(e={lastEffect:null,stores:null},j.updateQueue=e,e.stores=[n]):(t=e.stores,t===null?e.stores=[n]:t.push(n))}function Hr(n,e,t,a){e.value=t,e.getSnapshot=a,Gr(e)&&$r(n)}function Wr(n,e,t){return t(function(){Gr(e)&&$r(n)})}function Gr(n){var e=n.getSnapshot;n=n.value;try{var t=e();return!xn(n,t)}catch(a){return!0}}function $r(n){var e=$n(n,1);e!==null&&En(e,n,1,-1)}function Yr(n){var e=zn();return typeof n=="function"&&(n=n()),e.memoizedState=e.baseState=n,n={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:Ut,lastRenderedState:n},e.queue=n,n=n.dispatch=ms.bind(null,j,n),[e.memoizedState,n]}function Ht(n,e,t,a){return n={tag:n,create:e,destroy:t,deps:a,next:null},e=j.updateQueue,e===null?(e={lastEffect:null,stores:null},j.updateQueue=e,e.lastEffect=n.next=n):(t=e.lastEffect,t===null?e.lastEffect=n.next=n:(a=t.next,t.next=n,n.next=a,e.lastEffect=n)),n}function Qr(){return Tn().memoizedState}function Ha(n,e,t,a){var d=zn();j.flags|=n,d.memoizedState=Ht(1|e,t,void 0,a===void 0?null:a)}function Wa(n,e,t,a){var d=Tn();a=a===void 0?null:a;var o=void 0;if(Y!==null){var i=Y.memoizedState;if(o=i.destroy,a!==null&&Hd(a,i.deps)){d.memoizedState=Ht(e,t,o,a);return}}j.flags|=n,d.memoizedState=Ht(1|e,t,o,a)}function Jr(n,e){return Ha(8390656,8,n,e)}function Qd(n,e){return Wa(2048,8,n,e)}function Xr(n,e){return Wa(4,2,n,e)}function Zr(n,e){return Wa(4,4,n,e)}function qr(n,e){if(typeof e=="function")return n=n(),e(n),function(){e(null)};if(e!=null)return n=n(),e.current=n,function(){e.current=null}}function nl(n,e,t){return t=t!=null?t.concat([n]):null,Wa(4,4,qr.bind(null,e,n),t)}function Jd(){}function el(n,e){var t=Tn();e=e===void 0?null:e;var a=t.memoizedState;return a!==null&&e!==null&&Hd(e,a[1])?a[0]:(t.memoizedState=[n,e],n)}function tl(n,e){var t=Tn();e=e===void 0?null:e;var a=t.memoizedState;return a!==null&&e!==null&&Hd(e,a[1])?a[0]:(n=n(),t.memoizedState=[n,e],n)}function al(n,e,t){return Te&21?(xn(t,e)||(t=Bi(),j.lanes|=t,Me|=t,n.baseState=!0),e):(n.baseState&&(n.baseState=!1,hn=!0),n.memoizedState=t)}function rs(n,e){var t=E;E=t!==0&&4>t?t:4,n(!0);var a=Ud.transition;Ud.transition={};try{n(!1),e()}finally{E=t,Ud.transition=a}}function dl(){return Tn().memoizedState}function ls(n,e,t){var a=pe(n);if(t={lane:a,action:t,hasEagerState:!1,eagerState:null,next:null},ol(n))il(e,t);else if(t=Vr(n,e,t,a),t!==null){var d=un();En(t,n,a,d),rl(t,e,a)}}function ms(n,e,t){var a=pe(n),d={lane:a,action:t,hasEagerState:!1,eagerState:null,next:null};if(ol(n))il(e,d);else{var o=n.alternate;if(n.lanes===0&&(o===null||o.lanes===0)&&(o=e.lastRenderedReducer,o!==null))try{var i=e.lastRenderedState,r=o(i,t);if(d.hasEagerState=!0,d.eagerState=r,xn(r,i)){var l=e.interleaved;l===null?(d.next=d,Od(e)):(d.next=l.next,l.next=d),e.interleaved=d;return}}catch(u){}finally{}t=Vr(n,e,d,a),t!==null&&(d=un(),En(t,n,a,d),rl(t,e,a))}}function ol(n){var e=n.alternate;return n===j||e!==null&&e===j}function il(n,e){jt=Ua=!0;var t=n.pending;t===null?e.next=e:(e.next=t.next,t.next=e),n.pending=e}function rl(n,e,t){if(t&4194240){var a=e.lanes;a&=n.pendingLanes,t|=a,e.lanes=t,Z0(n,t)}}var Ga={readContext:Pn,useCallback:an,useContext:an,useEffect:an,useImperativeHandle:an,useInsertionEffect:an,useLayoutEffect:an,useMemo:an,useReducer:an,useRef:an,useState:an,useDebugValue:an,useDeferredValue:an,useTransition:an,useMutableSource:an,useSyncExternalStore:an,useId:an,unstable_isNewReconciler:!1},us={readContext:Pn,useCallback:function(n,e){return zn().memoizedState=[n,e===void 0?null:e],n},useContext:Pn,useEffect:Jr,useImperativeHandle:function(n,e,t){return t=t!=null?t.concat([n]):null,Ha(4194308,4,qr.bind(null,e,n),t)},useLayoutEffect:function(n,e){return Ha(4194308,4,n,e)},useInsertionEffect:function(n,e){return Ha(4,2,n,e)},useMemo:function(n,e){var t=zn();return e=e===void 0?null:e,n=n(),t.memoizedState=[n,e],n},useReducer:function(n,e,t){var a=zn();return e=t!==void 0?t(e):e,a.memoizedState=a.baseState=e,n={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:n,lastRenderedState:e},a.queue=n,n=n.dispatch=ls.bind(null,j,n),[a.memoizedState,n]},useRef:function(n){var e=zn();return n={current:n},e.memoizedState=n},useState:Yr,useDebugValue:Jd,useDeferredValue:function(n){return zn().memoizedState=n},useTransition:function(){var n=Yr(!1),e=n[0];return n=rs.bind(null,n[1]),zn().memoizedState=n,[e,n]},useMutableSource:function(){},useSyncExternalStore:function(n,e,t){var a=j,d=zn();if(F){if(t===void 0)throw Error(I(407));t=t()}else{if(t=e(),X===null)throw Error(I(349));Te&30||Ur(a,e,t)}d.memoizedState=t;var o={value:t,getSnapshot:e};return d.queue=o,Jr(Wr.bind(null,a,o,n),[n]),a.flags|=2048,Ht(9,Hr.bind(null,a,o,t,e),void 0,null),t},useId:function(){var n=zn(),e=X.identifierPrefix;if(F){var t=Gn,a=Wn;t=(a&~(1<<32-kn(a)-1)).toString(32)+t,e=":"+e+"R"+t,t=Kt++,0<t&&(e+="H"+t.toString(32)),e+=":"}else t=is++,e=":"+e+"r"+t.toString(32)+":";return n.memoizedState=e},unstable_isNewReconciler:!1},ss={readContext:Pn,useCallback:el,useContext:Pn,useEffect:Qd,useImperativeHandle:nl,useInsertionEffect:Xr,useLayoutEffect:Zr,useMemo:tl,useReducer:$d,useRef:Qr,useState:function(){return $d(Ut)},useDebugValue:Jd,useDeferredValue:function(n){var e=Tn();return al(e,Y.memoizedState,n)},useTransition:function(){var n=$d(Ut)[0],e=Tn().memoizedState;return[n,e]},useMutableSource:jr,useSyncExternalStore:Kr,useId:dl,unstable_isNewReconciler:!1},cs={readContext:Pn,useCallback:el,useContext:Pn,useEffect:Qd,useImperativeHandle:nl,useInsertionEffect:Xr,useLayoutEffect:Zr,useMemo:tl,useReducer:Yd,useRef:Qr,useState:function(){return Yd(Ut)},useDebugValue:Jd,useDeferredValue:function(n){var e=Tn();return Y===null?e.memoizedState=n:al(e,Y.memoizedState,n)},useTransition:function(){var n=Yd(Ut)[0],e=Tn().memoizedState;return[n,e]},useMutableSource:jr,useSyncExternalStore:Kr,useId:dl,unstable_isNewReconciler:!1};function Dn(n,e){if(n&&n.defaultProps){e=z({},e),n=n.defaultProps;for(var t in n)e[t]===void 0&&(e[t]=n[t]);return e}return e}function Xd(n,e,t,a){e=n.memoizedState,t=t(a,e),t=t==null?e:z({},e,t),n.memoizedState=t,n.lanes===0&&(n.updateQueue.baseState=t)}var $a={isMounted:function(n){return(n=n._reactInternals)?ve(n)===n:!1},enqueueSetState:function(n,e,t){n=n._reactInternals;var a=un(),d=pe(n),o=Yn(a,d);o.payload=e,t!=null&&(o.callback=t),e=ue(n,o,d),e!==null&&(En(e,n,d,a),za(e,n,d))},enqueueReplaceState:function(n,e,t){n=n._reactInternals;var a=un(),d=pe(n),o=Yn(a,d);o.tag=1,o.payload=e,t!=null&&(o.callback=t),e=ue(n,o,d),e!==null&&(En(e,n,d,a),za(e,n,d))},enqueueForceUpdate:function(n,e){n=n._reactInternals;var t=un(),a=pe(n),d=Yn(t,a);d.tag=2,e!=null&&(d.callback=e),e=ue(n,d,a),e!==null&&(En(e,n,a,t),za(e,n,a))}};function ll(n,e,t,a,d,o,i){return n=n.stateNode,typeof n.shouldComponentUpdate=="function"?n.shouldComponentUpdate(a,o,i):e.prototype&&e.prototype.isPureReactComponent?!_t(t,a)||!_t(d,o):!0}function ml(n,e,t){var a=!1,d=re,o=e.contextType;return typeof o=="object"&&o!==null?o=Pn(o):(d=cn(e)?we:tn.current,a=e.contextTypes,o=(a=a!=null)?Qe(n,d):re),e=new e(t,o),n.memoizedState=e.state!==null&&e.state!==void 0?e.state:null,e.updater=$a,n.stateNode=e,e._reactInternals=n,a&&(n=n.stateNode,n.__reactInternalMemoizedUnmaskedChildContext=d,n.__reactInternalMemoizedMaskedChildContext=o),e}function ul(n,e,t,a){n=e.state,typeof e.componentWillReceiveProps=="function"&&e.componentWillReceiveProps(t,a),typeof e.UNSAFE_componentWillReceiveProps=="function"&&e.UNSAFE_componentWillReceiveProps(t,a),e.state!==n&&$a.enqueueReplaceState(e,e.state,null)}function Zd(n,e,t,a){var d=n.stateNode;d.props=t,d.state=n.memoizedState,d.refs={},Fd(n);var o=e.contextType;typeof o=="object"&&o!==null?d.context=Pn(o):(o=cn(e)?we:tn.current,d.context=Qe(n,o)),d.state=n.memoizedState,o=e.getDerivedStateFromProps,typeof o=="function"&&(Xd(n,e,o,t),d.state=n.memoizedState),typeof e.getDerivedStateFromProps=="function"||typeof d.getSnapshotBeforeUpdate=="function"||typeof d.UNSAFE_componentWillMount!="function"&&typeof d.componentWillMount!="function"||(e=d.state,typeof d.componentWillMount=="function"&&d.componentWillMount(),typeof d.UNSAFE_componentWillMount=="function"&&d.UNSAFE_componentWillMount(),e!==d.state&&$a.enqueueReplaceState(d,d.state,null),ba(n,t,d,a),d.state=n.memoizedState),typeof d.componentDidMount=="function"&&(n.flags|=4194308)}function at(n,e){try{var t="",a=e;do t+=bm(a),a=a.return;while(a);var d=t}catch(o){d=`
Error generating stack: `+o.message+`
`+o.stack}return{value:n,source:e,stack:d,digest:null}}function qd(n,e,t){return{value:n,source:null,stack:t!=null?t:null,digest:e!=null?e:null}}function no(n,e){try{console.error(e.value)}catch(t){setTimeout(function(){throw t})}}var hs=typeof WeakMap=="function"?WeakMap:Map;function sl(n,e,t){t=Yn(-1,t),t.tag=3,t.payload={element:null};var a=e.value;return t.callback=function(){n0||(n0=!0,yo=a),no(n,e)},t}function cl(n,e,t){t=Yn(-1,t),t.tag=3;var a=n.type.getDerivedStateFromError;if(typeof a=="function"){var d=e.value;t.payload=function(){return a(d)},t.callback=function(){no(n,e)}}var o=n.stateNode;return o!==null&&typeof o.componentDidCatch=="function"&&(t.callback=function(){no(n,e),typeof a!="function"&&(ce===null?ce=new Set([this]):ce.add(this));var i=e.stack;this.componentDidCatch(e.value,{componentStack:i!==null?i:""})}),t}function hl(n,e,t){var a=n.pingCache;if(a===null){a=n.pingCache=new hs;var d=new Set;a.set(e,d)}else d=a.get(e),d===void 0&&(d=new Set,a.set(e,d));d.has(t)||(d.add(t),n=Cs.bind(null,n,e,t),e.then(n,n))}function pl(n){do{var e;if((e=n.tag===13)&&(e=n.memoizedState,e=e!==null?e.dehydrated!==null:!0),e)return n;n=n.return}while(n!==null);return null}function fl(n,e,t,a,d){return n.mode&1?(n.flags|=65536,n.lanes=d,n):(n===e?n.flags|=65536:(n.flags|=128,t.flags|=131072,t.flags&=-52805,t.tag===1&&(t.alternate===null?t.tag=17:(e=Yn(-1,1),e.tag=2,ue(t,e,1))),t.lanes|=1),n)}var ps=Kn.ReactCurrentOwner,hn=!1;function mn(n,e,t,a){e.child=n===null?Rr(e,null,t,a):qe(e,n.child,t,a)}function yl(n,e,t,a,d){t=t.render;var o=e.ref;return et(e,d),a=Wd(n,e,t,a,o,d),t=Gd(),n!==null&&!hn?(e.updateQueue=n.updateQueue,e.flags&=-2053,n.lanes&=~d,Qn(n,e,d)):(F&&t&&kd(e),e.flags|=1,mn(n,e,a,d),e.child)}function gl(n,e,t,a,d){if(n===null){var o=t.type;return typeof o=="function"&&!Ao(o)&&o.defaultProps===void 0&&t.compare===null&&t.defaultProps===void 0?(e.tag=15,e.type=o,vl(n,e,o,a,d)):(n=i0(t.type,null,a,e,e.mode,d),n.ref=e.ref,n.return=e,e.child=n)}if(o=n.child,!(n.lanes&d)){var i=o.memoizedProps;if(t=t.compare,t=t!==null?t:_t,t(i,a)&&n.ref===e.ref)return Qn(n,e,d)}return e.flags|=1,n=ye(o,a),n.ref=e.ref,n.return=e,e.child=n}function vl(n,e,t,a,d){if(n!==null){var o=n.memoizedProps;if(_t(o,a)&&n.ref===e.ref)if(hn=!1,e.pendingProps=a=o,(n.lanes&d)!==0)n.flags&131072&&(hn=!0);else return e.lanes=n.lanes,Qn(n,e,d)}return eo(n,e,t,a,d)}function Nl(n,e,t){var a=e.pendingProps,d=a.children,o=n!==null?n.memoizedState:null;if(a.mode==="hidden")if(!(e.mode&1))e.memoizedState={baseLanes:0,cachePool:null,transitions:null},R(ot,In),In|=t;else{if(!(t&1073741824))return n=o!==null?o.baseLanes|t:t,e.lanes=e.childLanes=1073741824,e.memoizedState={baseLanes:n,cachePool:null,transitions:null},e.updateQueue=null,R(ot,In),In|=n,null;e.memoizedState={baseLanes:0,cachePool:null,transitions:null},a=o!==null?o.baseLanes:t,R(ot,In),In|=a}else o!==null?(a=o.baseLanes|t,e.memoizedState=null):a=t,R(ot,In),In|=a;return mn(n,e,d,t),e.child}function wl(n,e){var t=e.ref;(n===null&&t!==null||n!==null&&n.ref!==t)&&(e.flags|=512,e.flags|=2097152)}function eo(n,e,t,a,d){var o=cn(t)?we:tn.current;return o=Qe(e,o),et(e,d),t=Wd(n,e,t,a,o,d),a=Gd(),n!==null&&!hn?(e.updateQueue=n.updateQueue,e.flags&=-2053,n.lanes&=~d,Qn(n,e,d)):(F&&a&&kd(e),e.flags|=1,mn(n,e,t,d),e.child)}function Il(n,e,t,a,d){if(cn(t)){var o=!0;Da(e)}else o=!1;if(et(e,d),e.stateNode===null)Qa(n,e),ml(e,t,a),Zd(e,t,a,d),a=!0;else if(n===null){var i=e.stateNode,r=e.memoizedProps;i.props=r;var l=i.context,u=t.contextType;typeof u=="object"&&u!==null?u=Pn(u):(u=cn(t)?we:tn.current,u=Qe(e,u));var y=t.getDerivedStateFromProps,f=typeof y=="function"||typeof i.getSnapshotBeforeUpdate=="function";f||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(r!==a||l!==u)&&ul(e,i,a,u),me=!1;var p=e.memoizedState;i.state=p,ba(e,a,i,d),l=e.memoizedState,r!==a||p!==l||sn.current||me?(typeof y=="function"&&(Xd(e,t,y,a),l=e.memoizedState),(r=me||ll(e,t,r,a,p,l,u))?(f||typeof i.UNSAFE_componentWillMount!="function"&&typeof i.componentWillMount!="function"||(typeof i.componentWillMount=="function"&&i.componentWillMount(),typeof i.UNSAFE_componentWillMount=="function"&&i.UNSAFE_componentWillMount()),typeof i.componentDidMount=="function"&&(e.flags|=4194308)):(typeof i.componentDidMount=="function"&&(e.flags|=4194308),e.memoizedProps=a,e.memoizedState=l),i.props=a,i.state=l,i.context=u,a=r):(typeof i.componentDidMount=="function"&&(e.flags|=4194308),a=!1)}else{i=e.stateNode,Or(n,e),r=e.memoizedProps,u=e.type===e.elementType?r:Dn(e.type,r),i.props=u,f=e.pendingProps,p=i.context,l=t.contextType,typeof l=="object"&&l!==null?l=Pn(l):(l=cn(t)?we:tn.current,l=Qe(e,l));var g=t.getDerivedStateFromProps;(y=typeof g=="function"||typeof i.getSnapshotBeforeUpdate=="function")||typeof i.UNSAFE_componentWillReceiveProps!="function"&&typeof i.componentWillReceiveProps!="function"||(r!==f||p!==l)&&ul(e,i,a,l),me=!1,p=e.memoizedState,i.state=p,ba(e,a,i,d);var N=e.memoizedState;r!==f||p!==N||sn.current||me?(typeof g=="function"&&(Xd(e,t,g,a),N=e.memoizedState),(u=me||ll(e,t,u,a,p,N,l)||!1)?(y||typeof i.UNSAFE_componentWillUpdate!="function"&&typeof i.componentWillUpdate!="function"||(typeof i.componentWillUpdate=="function"&&i.componentWillUpdate(a,N,l),typeof i.UNSAFE_componentWillUpdate=="function"&&i.UNSAFE_componentWillUpdate(a,N,l)),typeof i.componentDidUpdate=="function"&&(e.flags|=4),typeof i.getSnapshotBeforeUpdate=="function"&&(e.flags|=1024)):(typeof i.componentDidUpdate!="function"||r===n.memoizedProps&&p===n.memoizedState||(e.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||r===n.memoizedProps&&p===n.memoizedState||(e.flags|=1024),e.memoizedProps=a,e.memoizedState=N),i.props=a,i.state=N,i.context=l,a=u):(typeof i.componentDidUpdate!="function"||r===n.memoizedProps&&p===n.memoizedState||(e.flags|=4),typeof i.getSnapshotBeforeUpdate!="function"||r===n.memoizedProps&&p===n.memoizedState||(e.flags|=1024),a=!1)}return to(n,e,t,a,o,d)}function to(n,e,t,a,d,o){wl(n,e);var i=(e.flags&128)!==0;if(!a&&!i)return d&&Mr(e,t,!1),Qn(n,e,o);a=e.stateNode,ps.current=e;var r=i&&typeof t.getDerivedStateFromError!="function"?null:a.render();return e.flags|=1,n!==null&&i?(e.child=qe(e,n.child,null,o),e.child=qe(e,null,r,o)):mn(n,e,r,o),e.memoizedState=a.state,d&&Mr(e,t,!0),e.child}function Sl(n){var e=n.stateNode;e.pendingContext?Pr(n,e.pendingContext,e.pendingContext!==e.context):e.context&&Pr(n,e.context,!1),zd(n,e.containerInfo)}function Al(n,e,t,a,d){return Ze(),Ld(d),e.flags|=256,mn(n,e,t,a),e.child}var ao={dehydrated:null,treeContext:null,retryLane:0};function oo(n){return{baseLanes:n,cachePool:null,transitions:null}}function Pl(n,e,t){var a=e.pendingProps,d=b.current,o=!1,i=(e.flags&128)!==0,r;if((r=i)||(r=n!==null&&n.memoizedState===null?!1:(d&2)!==0),r?(o=!0,e.flags&=-129):(n===null||n.memoizedState!==null)&&(d|=1),R(b,d&1),n===null)return Dd(e),n=e.memoizedState,n!==null&&(n=n.dehydrated,n!==null)?(e.mode&1?n.data==="$!"?e.lanes=8:e.lanes=1073741824:e.lanes=1,null):(i=a.children,n=a.fallback,o?(a=e.mode,o=e.child,i={mode:"hidden",children:i},!(a&1)&&o!==null?(o.childLanes=0,o.pendingProps=i):o=r0(i,a,0,null),n=_e(n,a,t,null),o.return=e,n.return=e,o.sibling=n,e.child=o,e.child.memoizedState=oo(t),e.memoizedState=ao,n):io(e,i));if(d=n.memoizedState,d!==null&&(r=d.dehydrated,r!==null))return fs(n,e,i,a,r,d,t);if(o){o=a.fallback,i=e.mode,d=n.child,r=d.sibling;var l={mode:"hidden",children:a.children};return!(i&1)&&e.child!==d?(a=e.child,a.childLanes=0,a.pendingProps=l,e.deletions=null):(a=ye(d,l),a.subtreeFlags=d.subtreeFlags&14680064),r!==null?o=ye(r,o):(o=_e(o,i,t,null),o.flags|=2),o.return=e,a.return=e,a.sibling=o,e.child=a,a=o,o=e.child,i=n.child.memoizedState,i=i===null?oo(t):{baseLanes:i.baseLanes|t,cachePool:null,transitions:i.transitions},o.memoizedState=i,o.childLanes=n.childLanes&~t,e.memoizedState=ao,a}return o=n.child,n=o.sibling,a=ye(o,{mode:"visible",children:a.children}),!(e.mode&1)&&(a.lanes=t),a.return=e,a.sibling=null,n!==null&&(t=e.deletions,t===null?(e.deletions=[n],e.flags|=16):t.push(n)),e.child=a,e.memoizedState=null,a}function io(n,e){return e=r0({mode:"visible",children:e},n.mode,0,null),e.return=n,n.child=e}function Ya(n,e,t,a){return a!==null&&Ld(a),qe(e,n.child,null,t),n=io(e,e.pendingProps.children),n.flags|=2,e.memoizedState=null,n}function fs(n,e,t,a,d,o,i){if(t)return e.flags&256?(e.flags&=-257,a=qd(Error(I(422))),Ya(n,e,i,a)):e.memoizedState!==null?(e.child=n.child,e.flags|=128,null):(o=a.fallback,d=e.mode,a=r0({mode:"visible",children:a.children},d,0,null),o=_e(o,d,i,null),o.flags|=2,a.return=e,o.return=e,a.sibling=o,e.child=a,e.mode&1&&qe(e,n.child,null,i),e.child.memoizedState=oo(i),e.memoizedState=ao,o);if(!(e.mode&1))return Ya(n,e,i,null);if(d.data==="$!"){if(a=d.nextSibling&&d.nextSibling.dataset,a)var r=a.dgst;return a=r,o=Error(I(419)),a=qd(o,a,void 0),Ya(n,e,i,a)}if(r=(i&n.childLanes)!==0,hn||r){if(a=X,a!==null){switch(i&-i){case 4:d=2;break;case 16:d=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:d=32;break;case 536870912:d=268435456;break;default:d=0}d=d&(a.suspendedLanes|i)?0:d,d!==0&&d!==o.retryLane&&(o.retryLane=d,$n(n,d),En(a,n,d,-1))}return So(),a=qd(Error(I(421))),Ya(n,e,i,a)}return d.data==="$?"?(e.flags|=128,e.child=n.child,e=ks.bind(null,n),d._reactRetry=e,null):(n=o.treeContext,wn=oe(d.nextSibling),Nn=e,F=!0,_n=null,n!==null&&(Sn[An++]=Wn,Sn[An++]=Gn,Sn[An++]=Ie,Wn=n.id,Gn=n.overflow,Ie=e),e=io(e,a.children),e.flags|=4096,e)}function Tl(n,e,t){n.lanes|=e;var a=n.alternate;a!==null&&(a.lanes|=e),Vd(n.return,e,t)}function ro(n,e,t,a,d){var o=n.memoizedState;o===null?n.memoizedState={isBackwards:e,rendering:null,renderingStartTime:0,last:a,tail:t,tailMode:d}:(o.isBackwards=e,o.rendering=null,o.renderingStartTime=0,o.last=a,o.tail=t,o.tailMode=d)}function Ml(n,e,t){var a=e.pendingProps,d=a.revealOrder,o=a.tail;if(mn(n,e,a.children,t),a=b.current,a&2)a=a&1|2,e.flags|=128;else{if(n!==null&&n.flags&128)n:for(n=e.child;n!==null;){if(n.tag===13)n.memoizedState!==null&&Tl(n,t,e);else if(n.tag===19)Tl(n,t,e);else if(n.child!==null){n.child.return=n,n=n.child;continue}if(n===e)break n;for(;n.sibling===null;){if(n.return===null||n.return===e)break n;n=n.return}n.sibling.return=n.return,n=n.sibling}a&=1}if(R(b,a),!(e.mode&1))e.memoizedState=null;else switch(d){case"forwards":for(t=e.child,d=null;t!==null;)n=t.alternate,n!==null&&ja(n)===null&&(d=t),t=t.sibling;t=d,t===null?(d=e.child,e.child=null):(d=t.sibling,t.sibling=null),ro(e,!1,d,t,o);break;case"backwards":for(t=null,d=e.child,e.child=null;d!==null;){if(n=d.alternate,n!==null&&ja(n)===null){e.child=d;break}n=d.sibling,d.sibling=t,t=d,d=n}ro(e,!0,t,null,o);break;case"together":ro(e,!1,null,null,void 0);break;default:e.memoizedState=null}return e.child}function Qa(n,e){!(e.mode&1)&&n!==null&&(n.alternate=null,e.alternate=null,e.flags|=2)}function Qn(n,e,t){if(n!==null&&(e.dependencies=n.dependencies),Me|=e.lanes,!(t&e.childLanes))return null;if(n!==null&&e.child!==n.child)throw Error(I(153));if(e.child!==null){for(n=e.child,t=ye(n,n.pendingProps),e.child=t,t.return=e;n.sibling!==null;)n=n.sibling,t=t.sibling=ye(n,n.pendingProps),t.return=e;t.sibling=null}return e.child}function ys(n,e,t){switch(e.tag){case 3:Sl(e),Ze();break;case 5:br(e);break;case 1:cn(e.type)&&Da(e);break;case 4:zd(e,e.stateNode.containerInfo);break;case 10:var a=e.type._context,d=e.memoizedProps.value;R(Oa,a._currentValue),a._currentValue=d;break;case 13:if(a=e.memoizedState,a!==null)return a.dehydrated!==null?(R(b,b.current&1),e.flags|=128,null):t&e.child.childLanes?Pl(n,e,t):(R(b,b.current&1),n=Qn(n,e,t),n!==null?n.sibling:null);R(b,b.current&1);break;case 19:if(a=(t&e.childLanes)!==0,n.flags&128){if(a)return Ml(n,e,t);e.flags|=128}if(d=e.memoizedState,d!==null&&(d.rendering=null,d.tail=null,d.lastEffect=null),R(b,b.current),a)break;return null;case 22:case 23:return e.lanes=0,Nl(n,e,t)}return Qn(n,e,t)}var Cl,lo,kl,xl;Cl=function(n,e){for(var t=e.child;t!==null;){if(t.tag===5||t.tag===6)n.appendChild(t.stateNode);else if(t.tag!==4&&t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return;t=t.return}t.sibling.return=t.return,t=t.sibling}},lo=function(){},kl=function(n,e,t,a){var d=n.memoizedProps;if(d!==a){n=e.stateNode,Pe(Fn.current);var o=null;switch(t){case"input":d=V0(n,d),a=V0(n,a),o=[];break;case"select":d=z({},d,{value:void 0}),a=z({},a,{value:void 0}),o=[];break;case"textarea":d=z0(n,d),a=z0(n,a),o=[];break;default:typeof d.onClick!="function"&&typeof a.onClick=="function"&&(n.onclick=ka)}j0(t,a);var i;t=null;for(u in d)if(!a.hasOwnProperty(u)&&d.hasOwnProperty(u)&&d[u]!=null)if(u==="style"){var r=d[u];for(i in r)r.hasOwnProperty(i)&&(t||(t={}),t[i]="")}else u!=="dangerouslySetInnerHTML"&&u!=="children"&&u!=="suppressContentEditableWarning"&&u!=="suppressHydrationWarning"&&u!=="autoFocus"&&(mt.hasOwnProperty(u)?o||(o=[]):(o=o||[]).push(u,null));for(u in a){var l=a[u];if(r=d!=null?d[u]:void 0,a.hasOwnProperty(u)&&l!==r&&(l!=null||r!=null))if(u==="style")if(r){for(i in r)!r.hasOwnProperty(i)||l&&l.hasOwnProperty(i)||(t||(t={}),t[i]="");for(i in l)l.hasOwnProperty(i)&&r[i]!==l[i]&&(t||(t={}),t[i]=l[i])}else t||(o||(o=[]),o.push(u,t)),t=l;else u==="dangerouslySetInnerHTML"?(l=l?l.__html:void 0,r=r?r.__html:void 0,l!=null&&r!==l&&(o=o||[]).push(u,l)):u==="children"?typeof l!="string"&&typeof l!="number"||(o=o||[]).push(u,""+l):u!=="suppressContentEditableWarning"&&u!=="suppressHydrationWarning"&&(mt.hasOwnProperty(u)?(l!=null&&u==="onScroll"&&V("scroll",n),o||r===l||(o=[])):(o=o||[]).push(u,l))}t&&(o=o||[]).push("style",t);var u=o;(e.updateQueue=u)&&(e.flags|=4)}},xl=function(n,e,t,a){t!==a&&(e.flags|=4)};function Wt(n,e){if(!F)switch(n.tailMode){case"hidden":e=n.tail;for(var t=null;e!==null;)e.alternate!==null&&(t=e),e=e.sibling;t===null?n.tail=null:t.sibling=null;break;case"collapsed":t=n.tail;for(var a=null;t!==null;)t.alternate!==null&&(a=t),t=t.sibling;a===null?e||n.tail===null?n.tail=null:n.tail.sibling=null:a.sibling=null}}function dn(n){var e=n.alternate!==null&&n.alternate.child===n.child,t=0,a=0;if(e)for(var d=n.child;d!==null;)t|=d.lanes|d.childLanes,a|=d.subtreeFlags&14680064,a|=d.flags&14680064,d.return=n,d=d.sibling;else for(d=n.child;d!==null;)t|=d.lanes|d.childLanes,a|=d.subtreeFlags,a|=d.flags,d.return=n,d=d.sibling;return n.subtreeFlags|=a,n.childLanes=t,e}function gs(n,e,t){var a=e.pendingProps;switch(xd(e),e.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return dn(e),null;case 1:return cn(e.type)&&_a(),dn(e),null;case 3:return a=e.stateNode,tt(),O(sn),O(tn),Kd(),a.pendingContext&&(a.context=a.pendingContext,a.pendingContext=null),(n===null||n.child===null)&&(Ra(e)?e.flags|=4:n===null||n.memoizedState.isDehydrated&&!(e.flags&256)||(e.flags|=1024,_n!==null&&(No(_n),_n=null))),lo(n,e),dn(e),null;case 5:bd(e);var d=Pe(bt.current);if(t=e.type,n!==null&&e.stateNode!=null)kl(n,e,t,a,d),n.ref!==e.ref&&(e.flags|=512,e.flags|=2097152);else{if(!a){if(e.stateNode===null)throw Error(I(166));return dn(e),null}if(n=Pe(Fn.current),Ra(e)){a=e.stateNode,t=e.type;var o=e.memoizedProps;switch(a[On]=e,a[Rt]=o,n=(e.mode&1)!==0,t){case"dialog":V("cancel",a),V("close",a);break;case"iframe":case"object":case"embed":V("load",a);break;case"video":case"audio":for(d=0;d<Lt.length;d++)V(Lt[d],a);break;case"source":V("error",a);break;case"img":case"image":case"link":V("error",a),V("load",a);break;case"details":V("toggle",a);break;case"input":mi(a,o),V("invalid",a);break;case"select":a._wrapperState={wasMultiple:!!o.multiple},V("invalid",a);break;case"textarea":ci(a,o),V("invalid",a)}j0(t,o),d=null;for(var i in o)if(o.hasOwnProperty(i)){var r=o[i];i==="children"?typeof r=="string"?a.textContent!==r&&(o.suppressHydrationWarning!==!0&&Ca(a.textContent,r,n),d=["children",r]):typeof r=="number"&&a.textContent!==""+r&&(o.suppressHydrationWarning!==!0&&Ca(a.textContent,r,n),d=["children",""+r]):mt.hasOwnProperty(i)&&r!=null&&i==="onScroll"&&V("scroll",a)}switch(t){case"input":da(a),si(a,o,!0);break;case"textarea":da(a),pi(a);break;case"select":case"option":break;default:typeof o.onClick=="function"&&(a.onclick=ka)}a=d,e.updateQueue=a,a!==null&&(e.flags|=4)}else{i=d.nodeType===9?d:d.ownerDocument,n==="http://www.w3.org/1999/xhtml"&&(n=fi(t)),n==="http://www.w3.org/1999/xhtml"?t==="script"?(n=i.createElement("div"),n.innerHTML="<script><\/script>",n=n.removeChild(n.firstChild)):typeof a.is=="string"?n=i.createElement(t,{is:a.is}):(n=i.createElement(t),t==="select"&&(i=n,a.multiple?i.multiple=!0:a.size&&(i.size=a.size))):n=i.createElementNS(n,t),n[On]=e,n[Rt]=a,Cl(n,e,!1,!1),e.stateNode=n;n:{switch(i=K0(t,a),t){case"dialog":V("cancel",n),V("close",n),d=a;break;case"iframe":case"object":case"embed":V("load",n),d=a;break;case"video":case"audio":for(d=0;d<Lt.length;d++)V(Lt[d],n);d=a;break;case"source":V("error",n),d=a;break;case"img":case"image":case"link":V("error",n),V("load",n),d=a;break;case"details":V("toggle",n),d=a;break;case"input":mi(n,a),d=V0(n,a),V("invalid",n);break;case"option":d=a;break;case"select":n._wrapperState={wasMultiple:!!a.multiple},d=z({},a,{value:void 0}),V("invalid",n);break;case"textarea":ci(n,a),d=z0(n,a),V("invalid",n);break;default:d=a}j0(t,d),r=d;for(o in r)if(r.hasOwnProperty(o)){var l=r[o];o==="style"?vi(n,l):o==="dangerouslySetInnerHTML"?(l=l?l.__html:void 0,l!=null&&yi(n,l)):o==="children"?typeof l=="string"?(t!=="textarea"||l!=="")&&ht(n,l):typeof l=="number"&&ht(n,""+l):o!=="suppressContentEditableWarning"&&o!=="suppressHydrationWarning"&&o!=="autoFocus"&&(mt.hasOwnProperty(o)?l!=null&&o==="onScroll"&&V("scroll",n):l!=null&&T0(n,o,l,i))}switch(t){case"input":da(n),si(n,a,!1);break;case"textarea":da(n),pi(n);break;case"option":a.value!=null&&n.setAttribute("value",""+Zn(a.value));break;case"select":n.multiple=!!a.multiple,o=a.value,o!=null?Oe(n,!!a.multiple,o,!1):a.defaultValue!=null&&Oe(n,!!a.multiple,a.defaultValue,!0);break;default:typeof d.onClick=="function"&&(n.onclick=ka)}switch(t){case"button":case"input":case"select":case"textarea":a=!!a.autoFocus;break n;case"img":a=!0;break n;default:a=!1}}a&&(e.flags|=4)}e.ref!==null&&(e.flags|=512,e.flags|=2097152)}return dn(e),null;case 6:if(n&&e.stateNode!=null)xl(n,e,n.memoizedProps,a);else{if(typeof a!="string"&&e.stateNode===null)throw Error(I(166));if(t=Pe(bt.current),Pe(Fn.current),Ra(e)){if(a=e.stateNode,t=e.memoizedProps,a[On]=e,(o=a.nodeValue!==t)&&(n=Nn,n!==null))switch(n.tag){case 3:Ca(a.nodeValue,t,(n.mode&1)!==0);break;case 5:n.memoizedProps.suppressHydrationWarning!==!0&&Ca(a.nodeValue,t,(n.mode&1)!==0)}o&&(e.flags|=4)}else a=(t.nodeType===9?t:t.ownerDocument).createTextNode(a),a[On]=e,e.stateNode=a}return dn(e),null;case 13:if(O(b),a=e.memoizedState,n===null||n.memoizedState!==null&&n.memoizedState.dehydrated!==null){if(F&&wn!==null&&e.mode&1&&!(e.flags&128))Lr(),Ze(),e.flags|=98560,o=!1;else if(o=Ra(e),a!==null&&a.dehydrated!==null){if(n===null){if(!o)throw Error(I(318));if(o=e.memoizedState,o=o!==null?o.dehydrated:null,!o)throw Error(I(317));o[On]=e}else Ze(),!(e.flags&128)&&(e.memoizedState=null),e.flags|=4;dn(e),o=!1}else _n!==null&&(No(_n),_n=null),o=!0;if(!o)return e.flags&65536?e:null}return e.flags&128?(e.lanes=t,e):(a=a!==null,a!==(n!==null&&n.memoizedState!==null)&&a&&(e.child.flags|=8192,e.mode&1&&(n===null||b.current&1?Q===0&&(Q=3):So())),e.updateQueue!==null&&(e.flags|=4),dn(e),null);case 4:return tt(),lo(n,e),n===null&&Bt(e.stateNode.containerInfo),dn(e),null;case 10:return Rd(e.type._context),dn(e),null;case 17:return cn(e.type)&&_a(),dn(e),null;case 19:if(O(b),o=e.memoizedState,o===null)return dn(e),null;if(a=(e.flags&128)!==0,i=o.rendering,i===null)if(a)Wt(o,!1);else{if(Q!==0||n!==null&&n.flags&128)for(n=e.child;n!==null;){if(i=ja(n),i!==null){for(e.flags|=128,Wt(o,!1),a=i.updateQueue,a!==null&&(e.updateQueue=a,e.flags|=4),e.subtreeFlags=0,a=t,t=e.child;t!==null;)o=t,n=a,o.flags&=14680066,i=o.alternate,i===null?(o.childLanes=0,o.lanes=n,o.child=null,o.subtreeFlags=0,o.memoizedProps=null,o.memoizedState=null,o.updateQueue=null,o.dependencies=null,o.stateNode=null):(o.childLanes=i.childLanes,o.lanes=i.lanes,o.child=i.child,o.subtreeFlags=0,o.deletions=null,o.memoizedProps=i.memoizedProps,o.memoizedState=i.memoizedState,o.updateQueue=i.updateQueue,o.type=i.type,n=i.dependencies,o.dependencies=n===null?null:{lanes:n.lanes,firstContext:n.firstContext}),t=t.sibling;return R(b,b.current&1|2),e.child}n=n.sibling}o.tail!==null&&H()>it&&(e.flags|=128,a=!0,Wt(o,!1),e.lanes=4194304)}else{if(!a)if(n=ja(i),n!==null){if(e.flags|=128,a=!0,t=n.updateQueue,t!==null&&(e.updateQueue=t,e.flags|=4),Wt(o,!0),o.tail===null&&o.tailMode==="hidden"&&!i.alternate&&!F)return dn(e),null}else 2*H()-o.renderingStartTime>it&&t!==1073741824&&(e.flags|=128,a=!0,Wt(o,!1),e.lanes=4194304);o.isBackwards?(i.sibling=e.child,e.child=i):(t=o.last,t!==null?t.sibling=i:e.child=i,o.last=i)}return o.tail!==null?(e=o.tail,o.rendering=e,o.tail=e.sibling,o.renderingStartTime=H(),e.sibling=null,t=b.current,R(b,a?t&1|2:t&1),e):(dn(e),null);case 22:case 23:return Io(),a=e.memoizedState!==null,n!==null&&n.memoizedState!==null!==a&&(e.flags|=8192),a&&e.mode&1?In&1073741824&&(dn(e),e.subtreeFlags&6&&(e.flags|=8192)):dn(e),null;case 24:return null;case 25:return null}throw Error(I(156,e.tag))}function vs(n,e){switch(xd(e),e.tag){case 1:return cn(e.type)&&_a(),n=e.flags,n&65536?(e.flags=n&-65537|128,e):null;case 3:return tt(),O(sn),O(tn),Kd(),n=e.flags,n&65536&&!(n&128)?(e.flags=n&-65537|128,e):null;case 5:return bd(e),null;case 13:if(O(b),n=e.memoizedState,n!==null&&n.dehydrated!==null){if(e.alternate===null)throw Error(I(340));Ze()}return n=e.flags,n&65536?(e.flags=n&-65537|128,e):null;case 19:return O(b),null;case 4:return tt(),null;case 10:return Rd(e.type._context),null;case 22:case 23:return Io(),null;case 24:return null;default:return null}}var Ja=!1,on=!1,Ns=typeof WeakSet=="function"?WeakSet:Set,A=null;function dt(n,e){var t=n.ref;if(t!==null)if(typeof t=="function")try{t(null)}catch(a){K(n,e,a)}else t.current=null}function mo(n,e,t){try{t()}catch(a){K(n,e,a)}}var _l=!1;function ws(n,e){if(wd=ya,n=lr(),cd(n)){if("selectionStart"in n)var t={start:n.selectionStart,end:n.selectionEnd};else n:{t=(t=n.ownerDocument)&&t.defaultView||window;var a=t.getSelection&&t.getSelection();if(a&&a.rangeCount!==0){t=a.anchorNode;var d=a.anchorOffset,o=a.focusNode;a=a.focusOffset;try{t.nodeType,o.nodeType}catch(v){t=null;break n}var i=0,r=-1,l=-1,u=0,y=0,f=n,p=null;e:for(;;){for(var g;f!==t||d!==0&&f.nodeType!==3||(r=i+d),f!==o||a!==0&&f.nodeType!==3||(l=i+a),f.nodeType===3&&(i+=f.nodeValue.length),(g=f.firstChild)!==null;)p=f,f=g;for(;;){if(f===n)break e;if(p===t&&++u===d&&(r=i),p===o&&++y===a&&(l=i),(g=f.nextSibling)!==null)break;f=p,p=f.parentNode}f=g}t=r===-1||l===-1?null:{start:r,end:l}}else t=null}t=t||{start:0,end:0}}else t=null;for(Id={focusedElem:n,selectionRange:t},ya=!1,A=e;A!==null;)if(e=A,n=e.child,(e.subtreeFlags&1028)!==0&&n!==null)n.return=e,A=n;else for(;A!==null;){e=A;try{var N=e.alternate;if(e.flags&1024)switch(e.tag){case 0:case 11:case 15:break;case 1:if(N!==null){var w=N.memoizedProps,D=N.memoizedState,h=e.stateNode,m=h.getSnapshotBeforeUpdate(e.elementType===e.type?w:Dn(e.type,w),D);h.__reactInternalSnapshotBeforeUpdate=m}break;case 3:var c=e.stateNode.containerInfo;c.nodeType===1?c.textContent="":c.nodeType===9&&c.documentElement&&c.removeChild(c.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(I(163))}}catch(v){K(e,e.return,v)}if(n=e.sibling,n!==null){n.return=e.return,A=n;break}A=e.return}return N=_l,_l=!1,N}function Gt(n,e,t){var a=e.updateQueue;if(a=a!==null?a.lastEffect:null,a!==null){var d=a=a.next;do{if((d.tag&n)===n){var o=d.destroy;d.destroy=void 0,o!==void 0&&mo(e,t,o)}d=d.next}while(d!==a)}}function Xa(n,e){if(e=e.updateQueue,e=e!==null?e.lastEffect:null,e!==null){var t=e=e.next;do{if((t.tag&n)===n){var a=t.create;t.destroy=a()}t=t.next}while(t!==e)}}function uo(n){var e=n.ref;if(e!==null){var t=n.stateNode;switch(n.tag){case 5:n=t;break;default:n=t}typeof e=="function"?e(n):e.current=n}}function Dl(n){var e=n.alternate;e!==null&&(n.alternate=null,Dl(e)),n.child=null,n.deletions=null,n.sibling=null,n.tag===5&&(e=n.stateNode,e!==null&&(delete e[On],delete e[Rt],delete e[Td],delete e[ts],delete e[as])),n.stateNode=null,n.return=null,n.dependencies=null,n.memoizedProps=null,n.memoizedState=null,n.pendingProps=null,n.stateNode=null,n.updateQueue=null}function Ll(n){return n.tag===5||n.tag===3||n.tag===4}function Bl(n){n:for(;;){for(;n.sibling===null;){if(n.return===null||Ll(n.return))return null;n=n.return}for(n.sibling.return=n.return,n=n.sibling;n.tag!==5&&n.tag!==6&&n.tag!==18;){if(n.flags&2||n.child===null||n.tag===4)continue n;n.child.return=n,n=n.child}if(!(n.flags&2))return n.stateNode}}function so(n,e,t){var a=n.tag;if(a===5||a===6)n=n.stateNode,e?t.nodeType===8?t.parentNode.insertBefore(n,e):t.insertBefore(n,e):(t.nodeType===8?(e=t.parentNode,e.insertBefore(n,t)):(e=t,e.appendChild(n)),t=t._reactRootContainer,t!=null||e.onclick!==null||(e.onclick=ka));else if(a!==4&&(n=n.child,n!==null))for(so(n,e,t),n=n.sibling;n!==null;)so(n,e,t),n=n.sibling}function co(n,e,t){var a=n.tag;if(a===5||a===6)n=n.stateNode,e?t.insertBefore(n,e):t.appendChild(n);else if(a!==4&&(n=n.child,n!==null))for(co(n,e,t),n=n.sibling;n!==null;)co(n,e,t),n=n.sibling}var nn=null,Ln=!1;function se(n,e,t){for(t=t.child;t!==null;)El(n,e,t),t=t.sibling}function El(n,e,t){if(Vn&&typeof Vn.onCommitFiberUnmount=="function")try{Vn.onCommitFiberUnmount(ua,t)}catch(r){}switch(t.tag){case 5:on||dt(t,e);case 6:var a=nn,d=Ln;nn=null,se(n,e,t),nn=a,Ln=d,nn!==null&&(Ln?(n=nn,t=t.stateNode,n.nodeType===8?n.parentNode.removeChild(t):n.removeChild(t)):nn.removeChild(t.stateNode));break;case 18:nn!==null&&(Ln?(n=nn,t=t.stateNode,n.nodeType===8?Pd(n.parentNode,t):n.nodeType===1&&Pd(n,t),Pt(n)):Pd(nn,t.stateNode));break;case 4:a=nn,d=Ln,nn=t.stateNode.containerInfo,Ln=!0,se(n,e,t),nn=a,Ln=d;break;case 0:case 11:case 14:case 15:if(!on&&(a=t.updateQueue,a!==null&&(a=a.lastEffect,a!==null))){d=a=a.next;do{var o=d,i=o.destroy;o=o.tag,i!==void 0&&(o&2||o&4)&&mo(t,e,i),d=d.next}while(d!==a)}se(n,e,t);break;case 1:if(!on&&(dt(t,e),a=t.stateNode,typeof a.componentWillUnmount=="function"))try{a.props=t.memoizedProps,a.state=t.memoizedState,a.componentWillUnmount()}catch(r){K(t,e,r)}se(n,e,t);break;case 21:se(n,e,t);break;case 22:t.mode&1?(on=(a=on)||t.memoizedState!==null,se(n,e,t),on=a):se(n,e,t);break;default:se(n,e,t)}}function Rl(n){var e=n.updateQueue;if(e!==null){n.updateQueue=null;var t=n.stateNode;t===null&&(t=n.stateNode=new Ns),e.forEach(function(a){var d=xs.bind(null,n,a);t.has(a)||(t.add(a),a.then(d,d))})}}function Bn(n,e){var t=e.deletions;if(t!==null)for(var a=0;a<t.length;a++){var d=t[a];try{var o=n,i=e,r=i;n:for(;r!==null;){switch(r.tag){case 5:nn=r.stateNode,Ln=!1;break n;case 3:nn=r.stateNode.containerInfo,Ln=!0;break n;case 4:nn=r.stateNode.containerInfo,Ln=!0;break n}r=r.return}if(nn===null)throw Error(I(160));El(o,i,d),nn=null,Ln=!1;var l=d.alternate;l!==null&&(l.return=null),d.return=null}catch(u){K(d,e,u)}}if(e.subtreeFlags&12854)for(e=e.child;e!==null;)Vl(e,n),e=e.sibling}function Vl(n,e){var t=n.alternate,a=n.flags;switch(n.tag){case 0:case 11:case 14:case 15:if(Bn(e,n),bn(n),a&4){try{Gt(3,n,n.return),Xa(3,n)}catch(w){K(n,n.return,w)}try{Gt(5,n,n.return)}catch(w){K(n,n.return,w)}}break;case 1:Bn(e,n),bn(n),a&512&&t!==null&&dt(t,t.return);break;case 5:if(Bn(e,n),bn(n),a&512&&t!==null&&dt(t,t.return),n.flags&32){var d=n.stateNode;try{ht(d,"")}catch(w){K(n,n.return,w)}}if(a&4&&(d=n.stateNode,d!=null)){var o=n.memoizedProps,i=t!==null?t.memoizedProps:o,r=n.type,l=n.updateQueue;if(n.updateQueue=null,l!==null)try{r==="input"&&o.type==="radio"&&o.name!=null&&ui(d,o),K0(r,i);var u=K0(r,o);for(i=0;i<l.length;i+=2){var y=l[i],f=l[i+1];y==="style"?vi(d,f):y==="dangerouslySetInnerHTML"?yi(d,f):y==="children"?ht(d,f):T0(d,y,f,u)}switch(r){case"input":O0(d,o);break;case"textarea":hi(d,o);break;case"select":var p=d._wrapperState.wasMultiple;d._wrapperState.wasMultiple=!!o.multiple;var g=o.value;g!=null?Oe(d,!!o.multiple,g,!1):p!==!!o.multiple&&(o.defaultValue!=null?Oe(d,!!o.multiple,o.defaultValue,!0):Oe(d,!!o.multiple,o.multiple?[]:"",!1))}d[Rt]=o}catch(w){K(n,n.return,w)}}break;case 6:if(Bn(e,n),bn(n),a&4){if(n.stateNode===null)throw Error(I(162));d=n.stateNode,o=n.memoizedProps;try{d.nodeValue=o}catch(w){K(n,n.return,w)}}break;case 3:if(Bn(e,n),bn(n),a&4&&t!==null&&t.memoizedState.isDehydrated)try{Pt(e.containerInfo)}catch(w){K(n,n.return,w)}break;case 4:Bn(e,n),bn(n);break;case 13:Bn(e,n),bn(n),d=n.child,d.flags&8192&&(o=d.memoizedState!==null,d.stateNode.isHidden=o,!o||d.alternate!==null&&d.alternate.memoizedState!==null||(fo=H())),a&4&&Rl(n);break;case 22:if(y=t!==null&&t.memoizedState!==null,n.mode&1?(on=(u=on)||y,Bn(e,n),on=u):Bn(e,n),bn(n),a&8192){if(u=n.memoizedState!==null,(n.stateNode.isHidden=u)&&!y&&n.mode&1)for(A=n,y=n.child;y!==null;){for(f=A=y;A!==null;){switch(p=A,g=p.child,p.tag){case 0:case 11:case 14:case 15:Gt(4,p,p.return);break;case 1:dt(p,p.return);var N=p.stateNode;if(typeof N.componentWillUnmount=="function"){a=p,t=p.return;try{e=a,N.props=e.memoizedProps,N.state=e.memoizedState,N.componentWillUnmount()}catch(w){K(a,t,w)}}break;case 5:dt(p,p.return);break;case 22:if(p.memoizedState!==null){zl(f);continue}}g!==null?(g.return=p,A=g):zl(f)}y=y.sibling}n:for(y=null,f=n;;){if(f.tag===5){if(y===null){y=f;try{d=f.stateNode,u?(o=d.style,typeof o.setProperty=="function"?o.setProperty("display","none","important"):o.display="none"):(r=f.stateNode,l=f.memoizedProps.style,i=l!=null&&l.hasOwnProperty("display")?l.display:null,r.style.display=gi("display",i))}catch(w){K(n,n.return,w)}}}else if(f.tag===6){if(y===null)try{f.stateNode.nodeValue=u?"":f.memoizedProps}catch(w){K(n,n.return,w)}}else if((f.tag!==22&&f.tag!==23||f.memoizedState===null||f===n)&&f.child!==null){f.child.return=f,f=f.child;continue}if(f===n)break n;for(;f.sibling===null;){if(f.return===null||f.return===n)break n;y===f&&(y=null),f=f.return}y===f&&(y=null),f.sibling.return=f.return,f=f.sibling}}break;case 19:Bn(e,n),bn(n),a&4&&Rl(n);break;case 21:break;default:Bn(e,n),bn(n)}}function bn(n){var e=n.flags;if(e&2){try{n:{for(var t=n.return;t!==null;){if(Ll(t)){var a=t;break n}t=t.return}throw Error(I(160))}switch(a.tag){case 5:var d=a.stateNode;a.flags&32&&(ht(d,""),a.flags&=-33);var o=Bl(n);co(n,o,d);break;case 3:case 4:var i=a.stateNode.containerInfo,r=Bl(n);so(n,r,i);break;default:throw Error(I(161))}}catch(l){K(n,n.return,l)}n.flags&=-3}e&4096&&(n.flags&=-4097)}function Is(n,e,t){A=n,Ol(n)}function Ol(n,e,t){for(var a=(n.mode&1)!==0;A!==null;){var d=A,o=d.child;if(d.tag===22&&a){var i=d.memoizedState!==null||Ja;if(!i){var r=d.alternate,l=r!==null&&r.memoizedState!==null||on;r=Ja;var u=on;if(Ja=i,(on=l)&&!u)for(A=d;A!==null;)i=A,l=i.child,i.tag===22&&i.memoizedState!==null?bl(d):l!==null?(l.return=i,A=l):bl(d);for(;o!==null;)A=o,Ol(o),o=o.sibling;A=d,Ja=r,on=u}Fl(n)}else d.subtreeFlags&8772&&o!==null?(o.return=d,A=o):Fl(n)}}function Fl(n){for(;A!==null;){var e=A;if(e.flags&8772){var t=e.alternate;try{if(e.flags&8772)switch(e.tag){case 0:case 11:case 15:on||Xa(5,e);break;case 1:var a=e.stateNode;if(e.flags&4&&!on)if(t===null)a.componentDidMount();else{var d=e.elementType===e.type?t.memoizedProps:Dn(e.type,t.memoizedProps);a.componentDidUpdate(d,t.memoizedState,a.__reactInternalSnapshotBeforeUpdate)}var o=e.updateQueue;o!==null&&zr(e,o,a);break;case 3:var i=e.updateQueue;if(i!==null){if(t=null,e.child!==null)switch(e.child.tag){case 5:t=e.child.stateNode;break;case 1:t=e.child.stateNode}zr(e,i,t)}break;case 5:var r=e.stateNode;if(t===null&&e.flags&4){t=r;var l=e.memoizedProps;switch(e.type){case"button":case"input":case"select":case"textarea":l.autoFocus&&t.focus();break;case"img":l.src&&(t.src=l.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(e.memoizedState===null){var u=e.alternate;if(u!==null){var y=u.memoizedState;if(y!==null){var f=y.dehydrated;f!==null&&Pt(f)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(I(163))}on||e.flags&512&&uo(e)}catch(p){K(e,e.return,p)}}if(e===n){A=null;break}if(t=e.sibling,t!==null){t.return=e.return,A=t;break}A=e.return}}function zl(n){for(;A!==null;){var e=A;if(e===n){A=null;break}var t=e.sibling;if(t!==null){t.return=e.return,A=t;break}A=e.return}}function bl(n){for(;A!==null;){var e=A;try{switch(e.tag){case 0:case 11:case 15:var t=e.return;try{Xa(4,e)}catch(l){K(e,t,l)}break;case 1:var a=e.stateNode;if(typeof a.componentDidMount=="function"){var d=e.return;try{a.componentDidMount()}catch(l){K(e,d,l)}}var o=e.return;try{uo(e)}catch(l){K(e,o,l)}break;case 5:var i=e.return;try{uo(e)}catch(l){K(e,i,l)}}}catch(l){K(e,e.return,l)}if(e===n){A=null;break}var r=e.sibling;if(r!==null){r.return=e.return,A=r;break}A=e.return}}var Ss=Math.ceil,Za=Kn.ReactCurrentDispatcher,ho=Kn.ReactCurrentOwner,Mn=Kn.ReactCurrentBatchConfig,B=0,X=null,$=null,en=0,In=0,ot=ie(0),Q=0,$t=null,Me=0,qa=0,po=0,Yt=null,pn=null,fo=0,it=1/0,Jn=null,n0=!1,yo=null,ce=null,e0=!1,he=null,t0=0,Qt=0,go=null,a0=-1,d0=0;function un(){return B&6?H():a0!==-1?a0:a0=H()}function pe(n){return n.mode&1?B&2&&en!==0?en&-en:os.transition!==null?(d0===0&&(d0=Bi()),d0):(n=E,n!==0||(n=window.event,n=n===void 0?16:Ki(n.type)),n):1}function En(n,e,t,a){if(50<Qt)throw Qt=0,go=null,Error(I(185));Nt(n,t,a),(!(B&2)||n!==X)&&(n===X&&(!(B&2)&&(qa|=t),Q===4&&fe(n,en)),fn(n,a),t===1&&B===0&&!(e.mode&1)&&(it=H()+500,La&&le()))}function fn(n,e){var t=n.callbackNode;ou(n,e);var a=ha(n,n===X?en:0);if(a===0)t!==null&&_i(t),n.callbackNode=null,n.callbackPriority=0;else if(e=a&-a,n.callbackPriority!==e){if(t!=null&&_i(t),e===1)n.tag===0?ds(Kl.bind(null,n)):Cr(Kl.bind(null,n)),ns(function(){!(B&6)&&le()}),t=null;else{switch(Ei(a)){case 1:t=Q0;break;case 4:t=Di;break;case 16:t=ma;break;case 536870912:t=Li;break;default:t=ma}t=Jl(t,jl.bind(null,n))}n.callbackPriority=e,n.callbackNode=t}}function jl(n,e){if(a0=-1,d0=0,B&6)throw Error(I(327));var t=n.callbackNode;if(rt()&&n.callbackNode!==t)return null;var a=ha(n,n===X?en:0);if(a===0)return null;if(a&30||a&n.expiredLanes||e)e=o0(n,a);else{e=a;var d=B;B|=2;var o=Hl();(X!==n||en!==e)&&(Jn=null,it=H()+500,ke(n,e));do try{Ts();break}catch(r){Ul(n,r)}while(!0);Ed(),Za.current=o,B=d,$!==null?e=0:(X=null,en=0,e=Q)}if(e!==0){if(e===2&&(d=J0(n),d!==0&&(a=d,e=vo(n,d))),e===1)throw t=$t,ke(n,0),fe(n,a),fn(n,H()),t;if(e===6)fe(n,a);else{if(d=n.current.alternate,!(a&30)&&!As(d)&&(e=o0(n,a),e===2&&(o=J0(n),o!==0&&(a=o,e=vo(n,o))),e===1))throw t=$t,ke(n,0),fe(n,a),fn(n,H()),t;switch(n.finishedWork=d,n.finishedLanes=a,e){case 0:case 1:throw Error(I(345));case 2:xe(n,pn,Jn);break;case 3:if(fe(n,a),(a&130023424)===a&&(e=fo+500-H(),10<e)){if(ha(n,0)!==0)break;if(d=n.suspendedLanes,(d&a)!==a){un(),n.pingedLanes|=n.suspendedLanes&d;break}n.timeoutHandle=Ad(xe.bind(null,n,pn,Jn),e);break}xe(n,pn,Jn);break;case 4:if(fe(n,a),(a&4194240)===a)break;for(e=n.eventTimes,d=-1;0<a;){var i=31-kn(a);o=1<<i,i=e[i],i>d&&(d=i),a&=~o}if(a=d,a=H()-a,a=(120>a?120:480>a?480:1080>a?1080:1920>a?1920:3e3>a?3e3:4320>a?4320:1960*Ss(a/1960))-a,10<a){n.timeoutHandle=Ad(xe.bind(null,n,pn,Jn),a);break}xe(n,pn,Jn);break;case 5:xe(n,pn,Jn);break;default:throw Error(I(329))}}}return fn(n,H()),n.callbackNode===t?jl.bind(null,n):null}function vo(n,e){var t=Yt;return n.current.memoizedState.isDehydrated&&(ke(n,e).flags|=256),n=o0(n,e),n!==2&&(e=pn,pn=t,e!==null&&No(e)),n}function No(n){pn===null?pn=n:pn.push.apply(pn,n)}function As(n){for(var e=n;;){if(e.flags&16384){var t=e.updateQueue;if(t!==null&&(t=t.stores,t!==null))for(var a=0;a<t.length;a++){var d=t[a],o=d.getSnapshot;d=d.value;try{if(!xn(o(),d))return!1}catch(i){return!1}}}if(t=e.child,e.subtreeFlags&16384&&t!==null)t.return=e,e=t;else{if(e===n)break;for(;e.sibling===null;){if(e.return===null||e.return===n)return!0;e=e.return}e.sibling.return=e.return,e=e.sibling}}return!0}function fe(n,e){for(e&=~po,e&=~qa,n.suspendedLanes|=e,n.pingedLanes&=~e,n=n.expirationTimes;0<e;){var t=31-kn(e),a=1<<t;n[t]=-1,e&=~a}}function Kl(n){if(B&6)throw Error(I(327));rt();var e=ha(n,0);if(!(e&1))return fn(n,H()),null;var t=o0(n,e);if(n.tag!==0&&t===2){var a=J0(n);a!==0&&(e=a,t=vo(n,a))}if(t===1)throw t=$t,ke(n,0),fe(n,e),fn(n,H()),t;if(t===6)throw Error(I(345));return n.finishedWork=n.current.alternate,n.finishedLanes=e,xe(n,pn,Jn),fn(n,H()),null}function wo(n,e){var t=B;B|=1;try{return n(e)}finally{B=t,B===0&&(it=H()+500,La&&le())}}function Ce(n){he!==null&&he.tag===0&&!(B&6)&&rt();var e=B;B|=1;var t=Mn.transition,a=E;try{if(Mn.transition=null,E=1,n)return n()}finally{E=a,Mn.transition=t,B=e,!(B&6)&&le()}}function Io(){In=ot.current,O(ot)}function ke(n,e){n.finishedWork=null,n.finishedLanes=0;var t=n.timeoutHandle;if(t!==-1&&(n.timeoutHandle=-1,qu(t)),$!==null)for(t=$.return;t!==null;){var a=t;switch(xd(a),a.tag){case 1:a=a.type.childContextTypes,a!=null&&_a();break;case 3:tt(),O(sn),O(tn),Kd();break;case 5:bd(a);break;case 4:tt();break;case 13:O(b);break;case 19:O(b);break;case 10:Rd(a.type._context);break;case 22:case 23:Io()}t=t.return}if(X=n,$=n=ye(n.current,null),en=In=e,Q=0,$t=null,po=qa=Me=0,pn=Yt=null,Ae!==null){for(e=0;e<Ae.length;e++)if(t=Ae[e],a=t.interleaved,a!==null){t.interleaved=null;var d=a.next,o=t.pending;if(o!==null){var i=o.next;o.next=d,a.next=i}t.pending=a}Ae=null}return n}function Ul(n,e){do{var t=$;try{if(Ed(),Ka.current=Ga,Ua){for(var a=j.memoizedState;a!==null;){var d=a.queue;d!==null&&(d.pending=null),a=a.next}Ua=!1}if(Te=0,J=Y=j=null,jt=!1,Kt=0,ho.current=null,t===null||t.return===null){Q=1,$t=e,$=null;break}n:{var o=n,i=t.return,r=t,l=e;if(e=en,r.flags|=32768,l!==null&&typeof l=="object"&&typeof l.then=="function"){var u=l,y=r,f=y.tag;if(!(y.mode&1)&&(f===0||f===11||f===15)){var p=y.alternate;p?(y.updateQueue=p.updateQueue,y.memoizedState=p.memoizedState,y.lanes=p.lanes):(y.updateQueue=null,y.memoizedState=null)}var g=pl(i);if(g!==null){g.flags&=-257,fl(g,i,r,o,e),g.mode&1&&hl(o,u,e),e=g,l=u;var N=e.updateQueue;if(N===null){var w=new Set;w.add(l),e.updateQueue=w}else N.add(l);break n}else{if(!(e&1)){hl(o,u,e),So();break n}l=Error(I(426))}}else if(F&&r.mode&1){var D=pl(i);if(D!==null){!(D.flags&65536)&&(D.flags|=256),fl(D,i,r,o,e),Ld(at(l,r));break n}}o=l=at(l,r),Q!==4&&(Q=2),Yt===null?Yt=[o]:Yt.push(o),o=i;do{switch(o.tag){case 3:o.flags|=65536,e&=-e,o.lanes|=e;var h=sl(o,l,e);Fr(o,h);break n;case 1:r=l;var m=o.type,c=o.stateNode;if(!(o.flags&128)&&(typeof m.getDerivedStateFromError=="function"||c!==null&&typeof c.componentDidCatch=="function"&&(ce===null||!ce.has(c)))){o.flags|=65536,e&=-e,o.lanes|=e;var v=cl(o,r,e);Fr(o,v);break n}}o=o.return}while(o!==null)}Gl(t)}catch(S){e=S,$===t&&t!==null&&($=t=t.return);continue}break}while(!0)}function Hl(){var n=Za.current;return Za.current=Ga,n===null?Ga:n}function So(){(Q===0||Q===3||Q===2)&&(Q=4),X===null||!(Me&268435455)&&!(qa&268435455)||fe(X,en)}function o0(n,e){var t=B;B|=2;var a=Hl();(X!==n||en!==e)&&(Jn=null,ke(n,e));do try{Ps();break}catch(d){Ul(n,d)}while(!0);if(Ed(),B=t,Za.current=a,$!==null)throw Error(I(261));return X=null,en=0,Q}function Ps(){for(;$!==null;)Wl($)}function Ts(){for(;$!==null&&!Jm();)Wl($)}function Wl(n){var e=Ql(n.alternate,n,In);n.memoizedProps=n.pendingProps,e===null?Gl(n):$=e,ho.current=null}function Gl(n){var e=n;do{var t=e.alternate;if(n=e.return,e.flags&32768){if(t=vs(t,e),t!==null){t.flags&=32767,$=t;return}if(n!==null)n.flags|=32768,n.subtreeFlags=0,n.deletions=null;else{Q=6,$=null;return}}else if(t=gs(t,e,In),t!==null){$=t;return}if(e=e.sibling,e!==null){$=e;return}$=e=n}while(e!==null);Q===0&&(Q=5)}function xe(n,e,t){var a=E,d=Mn.transition;try{Mn.transition=null,E=1,Ms(n,e,t,a)}finally{Mn.transition=d,E=a}return null}function Ms(n,e,t,a){do rt();while(he!==null);if(B&6)throw Error(I(327));t=n.finishedWork;var d=n.finishedLanes;if(t===null)return null;if(n.finishedWork=null,n.finishedLanes=0,t===n.current)throw Error(I(177));n.callbackNode=null,n.callbackPriority=0;var o=t.lanes|t.childLanes;if(iu(n,o),n===X&&($=X=null,en=0),!(t.subtreeFlags&2064)&&!(t.flags&2064)||e0||(e0=!0,Jl(ma,function(){return rt(),null})),o=(t.flags&15990)!==0,t.subtreeFlags&15990||o){o=Mn.transition,Mn.transition=null;var i=E;E=1;var r=B;B|=4,ho.current=null,ws(n,t),Vl(t,n),Gu(Id),ya=!!wd,Id=wd=null,n.current=t,Is(t),Xm(),B=r,E=i,Mn.transition=o}else n.current=t;if(e0&&(e0=!1,he=n,t0=d),o=n.pendingLanes,o===0&&(ce=null),nu(t.stateNode),fn(n,H()),e!==null)for(a=n.onRecoverableError,t=0;t<e.length;t++)d=e[t],a(d.value,{componentStack:d.stack,digest:d.digest});if(n0)throw n0=!1,n=yo,yo=null,n;return t0&1&&n.tag!==0&&rt(),o=n.pendingLanes,o&1?n===go?Qt++:(Qt=0,go=n):Qt=0,le(),null}function rt(){if(he!==null){var n=Ei(t0),e=Mn.transition,t=E;try{if(Mn.transition=null,E=16>n?16:n,he===null)var a=!1;else{if(n=he,he=null,t0=0,B&6)throw Error(I(331));var d=B;for(B|=4,A=n.current;A!==null;){var o=A,i=o.child;if(A.flags&16){var r=o.deletions;if(r!==null){for(var l=0;l<r.length;l++){var u=r[l];for(A=u;A!==null;){var y=A;switch(y.tag){case 0:case 11:case 15:Gt(8,y,o)}var f=y.child;if(f!==null)f.return=y,A=f;else for(;A!==null;){y=A;var p=y.sibling,g=y.return;if(Dl(y),y===u){A=null;break}if(p!==null){p.return=g,A=p;break}A=g}}}var N=o.alternate;if(N!==null){var w=N.child;if(w!==null){N.child=null;do{var D=w.sibling;w.sibling=null,w=D}while(w!==null)}}A=o}}if(o.subtreeFlags&2064&&i!==null)i.return=o,A=i;else n:for(;A!==null;){if(o=A,o.flags&2048)switch(o.tag){case 0:case 11:case 15:Gt(9,o,o.return)}var h=o.sibling;if(h!==null){h.return=o.return,A=h;break n}A=o.return}}var m=n.current;for(A=m;A!==null;){i=A;var c=i.child;if(i.subtreeFlags&2064&&c!==null)c.return=i,A=c;else n:for(i=m;A!==null;){if(r=A,r.flags&2048)try{switch(r.tag){case 0:case 11:case 15:Xa(9,r)}}catch(S){K(r,r.return,S)}if(r===i){A=null;break n}var v=r.sibling;if(v!==null){v.return=r.return,A=v;break n}A=r.return}}if(B=d,le(),Vn&&typeof Vn.onPostCommitFiberRoot=="function")try{Vn.onPostCommitFiberRoot(ua,n)}catch(S){}a=!0}return a}finally{E=t,Mn.transition=e}}return!1}function $l(n,e,t){e=at(t,e),e=sl(n,e,1),n=ue(n,e,1),e=un(),n!==null&&(Nt(n,1,e),fn(n,e))}function K(n,e,t){if(n.tag===3)$l(n,n,t);else for(;e!==null;){if(e.tag===3){$l(e,n,t);break}else if(e.tag===1){var a=e.stateNode;if(typeof e.type.getDerivedStateFromError=="function"||typeof a.componentDidCatch=="function"&&(ce===null||!ce.has(a))){n=at(t,n),n=cl(e,n,1),e=ue(e,n,1),n=un(),e!==null&&(Nt(e,1,n),fn(e,n));break}}e=e.return}}function Cs(n,e,t){var a=n.pingCache;a!==null&&a.delete(e),e=un(),n.pingedLanes|=n.suspendedLanes&t,X===n&&(en&t)===t&&(Q===4||Q===3&&(en&130023424)===en&&500>H()-fo?ke(n,0):po|=t),fn(n,e)}function Yl(n,e){e===0&&(n.mode&1?(e=ca,ca<<=1,!(ca&130023424)&&(ca=4194304)):e=1);var t=un();n=$n(n,e),n!==null&&(Nt(n,e,t),fn(n,t))}function ks(n){var e=n.memoizedState,t=0;e!==null&&(t=e.retryLane),Yl(n,t)}function xs(n,e){var t=0;switch(n.tag){case 13:var a=n.stateNode,d=n.memoizedState;d!==null&&(t=d.retryLane);break;case 19:a=n.stateNode;break;default:throw Error(I(314))}a!==null&&a.delete(e),Yl(n,t)}var Ql;Ql=function(n,e,t){if(n!==null)if(n.memoizedProps!==e.pendingProps||sn.current)hn=!0;else{if(!(n.lanes&t)&&!(e.flags&128))return hn=!1,ys(n,e,t);hn=!!(n.flags&131072)}else hn=!1,F&&e.flags&1048576&&kr(e,Ea,e.index);switch(e.lanes=0,e.tag){case 2:var a=e.type;Qa(n,e),n=e.pendingProps;var d=Qe(e,tn.current);et(e,t),d=Wd(null,e,a,n,d,t);var o=Gd();return e.flags|=1,typeof d=="object"&&d!==null&&typeof d.render=="function"&&d.$$typeof===void 0?(e.tag=1,e.memoizedState=null,e.updateQueue=null,cn(a)?(o=!0,Da(e)):o=!1,e.memoizedState=d.state!==null&&d.state!==void 0?d.state:null,Fd(e),d.updater=$a,e.stateNode=d,d._reactInternals=e,Zd(e,a,n,t),e=to(null,e,a,!0,o,t)):(e.tag=0,F&&o&&kd(e),mn(null,e,d,t),e=e.child),e;case 16:a=e.elementType;n:{switch(Qa(n,e),n=e.pendingProps,d=a._init,a=d(a._payload),e.type=a,d=e.tag=Ds(a),n=Dn(a,n),d){case 0:e=eo(null,e,a,n,t);break n;case 1:e=Il(null,e,a,n,t);break n;case 11:e=yl(null,e,a,n,t);break n;case 14:e=gl(null,e,a,Dn(a.type,n),t);break n}throw Error(I(306,a,""))}return e;case 0:return a=e.type,d=e.pendingProps,d=e.elementType===a?d:Dn(a,d),eo(n,e,a,d,t);case 1:return a=e.type,d=e.pendingProps,d=e.elementType===a?d:Dn(a,d),Il(n,e,a,d,t);case 3:n:{if(Sl(e),n===null)throw Error(I(387));a=e.pendingProps,o=e.memoizedState,d=o.element,Or(n,e),ba(e,a,null,t);var i=e.memoizedState;if(a=i.element,o.isDehydrated)if(o={element:a,isDehydrated:!1,cache:i.cache,pendingSuspenseBoundaries:i.pendingSuspenseBoundaries,transitions:i.transitions},e.updateQueue.baseState=o,e.memoizedState=o,e.flags&256){d=at(Error(I(423)),e),e=Al(n,e,a,t,d);break n}else if(a!==d){d=at(Error(I(424)),e),e=Al(n,e,a,t,d);break n}else for(wn=oe(e.stateNode.containerInfo.firstChild),Nn=e,F=!0,_n=null,t=Rr(e,null,a,t),e.child=t;t;)t.flags=t.flags&-3|4096,t=t.sibling;else{if(Ze(),a===d){e=Qn(n,e,t);break n}mn(n,e,a,t)}e=e.child}return e;case 5:return br(e),n===null&&Dd(e),a=e.type,d=e.pendingProps,o=n!==null?n.memoizedProps:null,i=d.children,Sd(a,d)?i=null:o!==null&&Sd(a,o)&&(e.flags|=32),wl(n,e),mn(n,e,i,t),e.child;case 6:return n===null&&Dd(e),null;case 13:return Pl(n,e,t);case 4:return zd(e,e.stateNode.containerInfo),a=e.pendingProps,n===null?e.child=qe(e,null,a,t):mn(n,e,a,t),e.child;case 11:return a=e.type,d=e.pendingProps,d=e.elementType===a?d:Dn(a,d),yl(n,e,a,d,t);case 7:return mn(n,e,e.pendingProps,t),e.child;case 8:return mn(n,e,e.pendingProps.children,t),e.child;case 12:return mn(n,e,e.pendingProps.children,t),e.child;case 10:n:{if(a=e.type._context,d=e.pendingProps,o=e.memoizedProps,i=d.value,R(Oa,a._currentValue),a._currentValue=i,o!==null)if(xn(o.value,i)){if(o.children===d.children&&!sn.current){e=Qn(n,e,t);break n}}else for(o=e.child,o!==null&&(o.return=e);o!==null;){var r=o.dependencies;if(r!==null){i=o.child;for(var l=r.firstContext;l!==null;){if(l.context===a){if(o.tag===1){l=Yn(-1,t&-t),l.tag=2;var u=o.updateQueue;if(u!==null){u=u.shared;var y=u.pending;y===null?l.next=l:(l.next=y.next,y.next=l),u.pending=l}}o.lanes|=t,l=o.alternate,l!==null&&(l.lanes|=t),Vd(o.return,t,e),r.lanes|=t;break}l=l.next}}else if(o.tag===10)i=o.type===e.type?null:o.child;else if(o.tag===18){if(i=o.return,i===null)throw Error(I(341));i.lanes|=t,r=i.alternate,r!==null&&(r.lanes|=t),Vd(i,t,e),i=o.sibling}else i=o.child;if(i!==null)i.return=o;else for(i=o;i!==null;){if(i===e){i=null;break}if(o=i.sibling,o!==null){o.return=i.return,i=o;break}i=i.return}o=i}mn(n,e,d.children,t),e=e.child}return e;case 9:return d=e.type,a=e.pendingProps.children,et(e,t),d=Pn(d),a=a(d),e.flags|=1,mn(n,e,a,t),e.child;case 14:return a=e.type,d=Dn(a,e.pendingProps),d=Dn(a.type,d),gl(n,e,a,d,t);case 15:return vl(n,e,e.type,e.pendingProps,t);case 17:return a=e.type,d=e.pendingProps,d=e.elementType===a?d:Dn(a,d),Qa(n,e),e.tag=1,cn(a)?(n=!0,Da(e)):n=!1,et(e,t),ml(e,a,d),Zd(e,a,d,t),to(null,e,a,!0,n,t);case 19:return Ml(n,e,t);case 22:return Nl(n,e,t)}throw Error(I(156,e.tag))};function Jl(n,e){return xi(n,e)}function _s(n,e,t,a){this.tag=n,this.key=t,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=e,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=a,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function Cn(n,e,t,a){return new _s(n,e,t,a)}function Ao(n){return n=n.prototype,!(!n||!n.isReactComponent)}function Ds(n){if(typeof n=="function")return Ao(n)?1:0;if(n!=null){if(n=n.$$typeof,n===k0)return 11;if(n===D0)return 14}return 2}function ye(n,e){var t=n.alternate;return t===null?(t=Cn(n.tag,e,n.key,n.mode),t.elementType=n.elementType,t.type=n.type,t.stateNode=n.stateNode,t.alternate=n,n.alternate=t):(t.pendingProps=e,t.type=n.type,t.flags=0,t.subtreeFlags=0,t.deletions=null),t.flags=n.flags&14680064,t.childLanes=n.childLanes,t.lanes=n.lanes,t.child=n.child,t.memoizedProps=n.memoizedProps,t.memoizedState=n.memoizedState,t.updateQueue=n.updateQueue,e=n.dependencies,t.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext},t.sibling=n.sibling,t.index=n.index,t.ref=n.ref,t}function i0(n,e,t,a,d,o){var i=2;if(a=n,typeof n=="function")Ao(n)&&(i=1);else if(typeof n=="string")i=5;else n:switch(n){case Ve:return _e(t.children,d,o,e);case M0:i=8,d|=8;break;case C0:return n=Cn(12,t,e,d|2),n.elementType=C0,n.lanes=o,n;case x0:return n=Cn(13,t,e,d),n.elementType=x0,n.lanes=o,n;case _0:return n=Cn(19,t,e,d),n.elementType=_0,n.lanes=o,n;case oi:return r0(t,d,o,e);default:if(typeof n=="object"&&n!==null)switch(n.$$typeof){case ai:i=10;break n;case di:i=9;break n;case k0:i=11;break n;case D0:i=14;break n;case Xn:i=16,a=null;break n}throw Error(I(130,n==null?n:typeof n,""))}return e=Cn(i,t,e,d),e.elementType=n,e.type=a,e.lanes=o,e}function _e(n,e,t,a){return n=Cn(7,n,a,e),n.lanes=t,n}function r0(n,e,t,a){return n=Cn(22,n,a,e),n.elementType=oi,n.lanes=t,n.stateNode={isHidden:!1},n}function Po(n,e,t){return n=Cn(6,n,null,e),n.lanes=t,n}function To(n,e,t){return e=Cn(4,n.children!==null?n.children:[],n.key,e),e.lanes=t,e.stateNode={containerInfo:n.containerInfo,pendingChildren:null,implementation:n.implementation},e}function Ls(n,e,t,a,d){this.tag=e,this.containerInfo=n,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=X0(0),this.expirationTimes=X0(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=X0(0),this.identifierPrefix=a,this.onRecoverableError=d,this.mutableSourceEagerHydrationData=null}function Mo(n,e,t,a,d,o,i,r,l){return n=new Ls(n,e,t,r,l),e===1?(e=1,o===!0&&(e|=8)):e=0,o=Cn(3,null,null,e),n.current=o,o.stateNode=n,o.memoizedState={element:a,isDehydrated:t,cache:null,transitions:null,pendingSuspenseBoundaries:null},Fd(o),n}function Bs(n,e,t){var a=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:Re,key:a==null?null:""+a,children:n,containerInfo:e,implementation:t}}function Xl(n){if(!n)return re;n=n._reactInternals;n:{if(ve(n)!==n||n.tag!==1)throw Error(I(170));var e=n;do{switch(e.tag){case 3:e=e.stateNode.context;break n;case 1:if(cn(e.type)){e=e.stateNode.__reactInternalMemoizedMergedChildContext;break n}}e=e.return}while(e!==null);throw Error(I(171))}if(n.tag===1){var t=n.type;if(cn(t))return Tr(n,t,e)}return e}function Zl(n,e,t,a,d,o,i,r,l){return n=Mo(t,a,!0,n,d,o,i,r,l),n.context=Xl(null),t=n.current,a=un(),d=pe(t),o=Yn(a,d),o.callback=e!=null?e:null,ue(t,o,d),n.current.lanes=d,Nt(n,d,a),fn(n,a),n}function l0(n,e,t,a){var d=e.current,o=un(),i=pe(d);return t=Xl(t),e.context===null?e.context=t:e.pendingContext=t,e=Yn(o,i),e.payload={element:n},a=a===void 0?null:a,a!==null&&(e.callback=a),n=ue(d,e,i),n!==null&&(En(n,d,i,o),za(n,d,i)),i}function m0(n){if(n=n.current,!n.child)return null;switch(n.child.tag){case 5:return n.child.stateNode;default:return n.child.stateNode}}function ql(n,e){if(n=n.memoizedState,n!==null&&n.dehydrated!==null){var t=n.retryLane;n.retryLane=t!==0&&t<e?t:e}}function Co(n,e){ql(n,e),(n=n.alternate)&&ql(n,e)}function Es(){return null}var nm=typeof reportError=="function"?reportError:function(n){console.error(n)};function ko(n){this._internalRoot=n}u0.prototype.render=ko.prototype.render=function(n){var e=this._internalRoot;if(e===null)throw Error(I(409));l0(n,e,null,null)},u0.prototype.unmount=ko.prototype.unmount=function(){var n=this._internalRoot;if(n!==null){this._internalRoot=null;var e=n.containerInfo;Ce(function(){l0(null,n,null,null)}),e[Un]=null}};function u0(n){this._internalRoot=n}u0.prototype.unstable_scheduleHydration=function(n){if(n){var e=Oi();n={blockedOn:null,target:n,priority:e};for(var t=0;t<te.length&&e!==0&&e<te[t].priority;t++);te.splice(t,0,n),t===0&&bi(n)}};function xo(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11)}function s0(n){return!(!n||n.nodeType!==1&&n.nodeType!==9&&n.nodeType!==11&&(n.nodeType!==8||n.nodeValue!==" react-mount-point-unstable "))}function em(){}function Rs(n,e,t,a,d){if(d){if(typeof a=="function"){var o=a;a=function(){var u=m0(i);o.call(u)}}var i=Zl(e,a,n,0,null,!1,!1,"",em);return n._reactRootContainer=i,n[Un]=i.current,Bt(n.nodeType===8?n.parentNode:n),Ce(),i}for(;d=n.lastChild;)n.removeChild(d);if(typeof a=="function"){var r=a;a=function(){var u=m0(l);r.call(u)}}var l=Mo(n,0,!1,null,null,!1,!1,"",em);return n._reactRootContainer=l,n[Un]=l.current,Bt(n.nodeType===8?n.parentNode:n),Ce(function(){l0(e,l,t,a)}),l}function c0(n,e,t,a,d){var o=t._reactRootContainer;if(o){var i=o;if(typeof d=="function"){var r=d;d=function(){var l=m0(i);r.call(l)}}l0(e,i,n,d)}else i=Rs(t,e,n,d,a);return m0(i)}Ri=function(n){switch(n.tag){case 3:var e=n.stateNode;if(e.current.memoizedState.isDehydrated){var t=vt(e.pendingLanes);t!==0&&(Z0(e,t|1),fn(e,H()),!(B&6)&&(it=H()+500,le()))}break;case 13:Ce(function(){var a=$n(n,1);if(a!==null){var d=un();En(a,n,1,d)}}),Co(n,1)}},q0=function(n){if(n.tag===13){var e=$n(n,134217728);if(e!==null){var t=un();En(e,n,134217728,t)}Co(n,134217728)}},Vi=function(n){if(n.tag===13){var e=pe(n),t=$n(n,e);if(t!==null){var a=un();En(t,n,e,a)}Co(n,e)}},Oi=function(){return E},Fi=function(n,e){var t=E;try{return E=n,e()}finally{E=t}},W0=function(n,e,t){switch(e){case"input":if(O0(n,t),e=t.name,t.type==="radio"&&e!=null){for(t=n;t.parentNode;)t=t.parentNode;for(t=t.querySelectorAll("input[name="+JSON.stringify(""+e)+'][type="radio"]'),e=0;e<t.length;e++){var a=t[e];if(a!==n&&a.form===n.form){var d=xa(a);if(!d)throw Error(I(90));li(a),O0(a,d)}}}break;case"textarea":hi(n,t);break;case"select":e=t.value,e!=null&&Oe(n,!!t.multiple,e,!1)}},Si=wo,Ai=Ce;var Vs={usingClientEntryPoint:!1,Events:[Vt,$e,xa,wi,Ii,wo]},Jt={findFiberByHostInstance:Ne,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},Os={bundleType:Jt.bundleType,version:Jt.version,rendererPackageName:Jt.rendererPackageName,rendererConfig:Jt.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:Kn.ReactCurrentDispatcher,findHostInstanceByFiber:function(n){return n=Ci(n),n===null?null:n.stateNode},findFiberByHostInstance:Jt.findFiberByHostInstance||Es,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var h0=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!h0.isDisabled&&h0.supportsFiber)try{ua=h0.inject(Os),Vn=h0}catch(n){}}yn.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=Vs,yn.createPortal=function(n,e){var t=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!xo(e))throw Error(I(200));return Bs(n,e,null,t)},yn.createRoot=function(n,e){if(!xo(n))throw Error(I(299));var t=!1,a="",d=nm;return e!=null&&(e.unstable_strictMode===!0&&(t=!0),e.identifierPrefix!==void 0&&(a=e.identifierPrefix),e.onRecoverableError!==void 0&&(d=e.onRecoverableError)),e=Mo(n,1,!1,null,null,t,!1,a,d),n[Un]=e.current,Bt(n.nodeType===8?n.parentNode:n),new ko(e)},yn.findDOMNode=function(n){if(n==null)return null;if(n.nodeType===1)return n;var e=n._reactInternals;if(e===void 0)throw typeof n.render=="function"?Error(I(188)):(n=Object.keys(n).join(","),Error(I(268,n)));return n=Ci(e),n=n===null?null:n.stateNode,n},yn.flushSync=function(n){return Ce(n)},yn.hydrate=function(n,e,t){if(!s0(e))throw Error(I(200));return c0(null,n,e,!0,t)},yn.hydrateRoot=function(n,e,t){if(!xo(n))throw Error(I(405));var a=t!=null&&t.hydratedSources||null,d=!1,o="",i=nm;if(t!=null&&(t.unstable_strictMode===!0&&(d=!0),t.identifierPrefix!==void 0&&(o=t.identifierPrefix),t.onRecoverableError!==void 0&&(i=t.onRecoverableError)),e=Zl(e,null,n,1,t!=null?t:null,d,!1,o,i),n[Un]=e.current,Bt(n),a)for(n=0;n<a.length;n++)t=a[n],d=t._getVersion,d=d(t._source),e.mutableSourceEagerHydrationData==null?e.mutableSourceEagerHydrationData=[t,d]:e.mutableSourceEagerHydrationData.push(t,d);return new u0(e)},yn.render=function(n,e,t){if(!s0(e))throw Error(I(200));return c0(null,n,e,!1,t)},yn.unmountComponentAtNode=function(n){if(!s0(n))throw Error(I(40));return n._reactRootContainer?(Ce(function(){c0(null,null,n,!1,function(){n._reactRootContainer=null,n[Un]=null})}),!0):!1},yn.unstable_batchedUpdates=wo,yn.unstable_renderSubtreeIntoContainer=function(n,e,t,a){if(!s0(t))throw Error(I(200));if(n==null||n._reactInternals===void 0)throw Error(I(38));return c0(n,e,t,!1,a)},yn.version="18.3.1-next-f1338f8080-20240426";function tm(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(tm)}catch(n){console.error(n)}}tm(),Xo.exports=yn;var am=Xo.exports,dm,om=am;dm=om.createRoot,om.hydrateRoot;const Fs=`{
  "data": {
    "value": [
      {
        "mdId": 1,
        "phId": 1,
        "gdIsLocked": 0,
        "gdIsCurrent": 1,
        "subsAllowed": 2,
        "maxSubsCf": 1,
        "deadline": "09/08/26 06:45:00 PM",
        "gameday": 1,
        "gamedayNew": 2,
        "roundId": 2002239,
        "round": "",
        "mdIsLocked": 0,
        "mdIsCurrent": 1,
        "isActNewUser": 1,
        "showLeaderboards": 0,
        "leagueIndent": 0,
        "match": [
          {
            "mId": 2049558,
            "gdId": "1",
            "dateTime": "09/08/2026 18:45:00",
            "htId": 50129,
            "htName": "AEK Athens",
            "htCCode": "AEK",
            "htPtName": "Pot 4",
            "atId": 63405,
            "atName": "LASK",
            "atCCode": "LASK",
            "atPtName": "Pot 4",
            "stadiumName": "AEK Arena",
            "venueName": "Athens"
          },
          {
            "mId": 2049556,
            "gdId": "1",
            "dateTime": "09/08/2026 18:45:00",
            "htId": 50043,
            "htName": "Club Brugge",
            "htCCode": "BRU",
            "htPtName": "Pot 2",
            "atId": 52683,
            "atName": "Aston Villa",
            "atCCode": "AVL",
            "atPtName": "Pot 2",
            "stadiumName": "Jan Breydelstadion",
            "venueName": "Bruges"
          },
          {
            "mId": 2049553,
            "gdId": "1",
            "dateTime": "09/08/2026 21:00:00",
            "htId": 50051,
            "htName": "Real Madrid",
            "htCCode": "RMA",
            "htPtName": "Pot 1",
            "atId": 50138,
            "atName": "Inter",
            "atCCode": "INT",
            "atPtName": "Pot 1",
            "stadiumName": "Estadio Santiago Bernabéu",
            "venueName": "Madrid"
          },
          {
            "mId": 2049555,
            "gdId": "1",
            "dateTime": "09/08/2026 21:00:00",
            "htId": 50064,
            "htName": "Porto",
            "htCCode": "POR",
            "htPtName": "Pot 2",
            "atId": 52919,
            "atName": "Man City",
            "atCCode": "MCI",
            "atPtName": "Pot 1",
            "stadiumName": "Estádio do Dragão",
            "venueName": "Porto"
          },
          {
            "mId": 2049557,
            "gdId": "1",
            "dateTime": "09/08/2026 21:00:00",
            "htId": 75797,
            "htName": "Lille",
            "htCCode": "LIL",
            "htPtName": "Pot 3",
            "atId": 52265,
            "atName": "Real Betis",
            "atCCode": "BET",
            "atPtName": "Pot 2",
            "stadiumName": "Stade Pierre Mauroy",
            "venueName": "Villeneuve d'Ascq"
          },
          {
            "mId": 2049554,
            "gdId": "1",
            "dateTime": "09/08/2026 21:00:00",
            "htId": 52758,
            "htName": "B. Dortmund",
            "htCCode": "BVB",
            "htPtName": "Pot 2",
            "atId": 70691,
            "atName": "Villarreal",
            "atCCode": "VIL",
            "atPtName": "Pot 3",
            "stadiumName": "BVB Stadion Dortmund",
            "venueName": "Dortmund"
          },
          {
            "mId": 2049564,
            "gdId": "2",
            "dateTime": "09/09/2026 18:45:00",
            "htId": 50107,
            "htName": "Stuttgart",
            "htCCode": "STU",
            "htPtName": "Pot 4",
            "atId": 52319,
            "atName": "Viking",
            "atCCode": "VFK",
            "atPtName": "Pot 4",
            "stadiumName": "Arena Stuttgart",
            "venueName": "Stuttgart"
          },
          {
            "mId": 2049561,
            "gdId": "2",
            "dateTime": "09/09/2026 18:45:00",
            "htId": 50080,
            "htName": "Barcelona",
            "htCCode": "BAR",
            "htPtName": "Pot 1",
            "atId": 52749,
            "atName": "Feyenoord",
            "atCCode": "FEY",
            "atPtName": "Pot 3",
            "stadiumName": "Camp Nou",
            "venueName": "Barcelona"
          },
          {
            "mId": 2049562,
            "gdId": "2",
            "dateTime": "09/09/2026 21:00:00",
            "htId": 50149,
            "htName": "Sporting CP",
            "htCCode": "SPO",
            "htPtName": "Pot 2",
            "atId": 50067,
            "atName": "Galatasaray",
            "atCCode": "GAL",
            "atPtName": "Pot 3",
            "stadiumName": "Estádio José Alvalade",
            "venueName": "Lisbon"
          },
          {
            "mId": 2049563,
            "gdId": "2",
            "dateTime": "09/09/2026 21:00:00",
            "htId": 50136,
            "htName": "Napoli",
            "htCCode": "NAP",
            "htPtName": "Pot 3",
            "atId": 52280,
            "atName": "Arsenal",
            "atCCode": "ARS",
            "atPtName": "Pot 1",
            "stadiumName": "Stadio Diego Armando Maradona",
            "venueName": "Naples"
          },
          {
            "mId": 2049560,
            "gdId": "2",
            "dateTime": "09/09/2026 21:00:00",
            "htId": 7889,
            "htName": "Liverpool",
            "htCCode": "LIV",
            "htPtName": "Pot 1",
            "atId": 50124,
            "atName": "Atleti",
            "atCCode": "ATM",
            "atPtName": "Pot 1",
            "stadiumName": "Anfield",
            "venueName": "Liverpool"
          },
          {
            "mId": 2049559,
            "gdId": "2",
            "dateTime": "09/09/2026 21:00:00",
            "htId": 52747,
            "htName": "Paris",
            "htCCode": "PSG",
            "htPtName": "Pot 1",
            "atId": 52797,
            "atName": "S. Bratislava",
            "atCCode": "SBR",
            "atPtName": "Pot 4",
            "stadiumName": "Parc des Princes",
            "venueName": "Paris"
          },
          {
            "mId": 2049567,
            "gdId": "3",
            "dateTime": "09/10/2026 18:45:00",
            "htId": 50062,
            "htName": "PSV",
            "htCCode": "PSV",
            "htPtName": "Pot 2",
            "atId": 52707,
            "atName": "Shakhtar",
            "atCCode": "SHK",
            "atPtName": "Pot 3",
            "stadiumName": "PSV Stadion",
            "venueName": "Eindhoven"
          },
          {
            "mId": 2049568,
            "gdId": "3",
            "dateTime": "09/10/2026 18:45:00",
            "htId": 52692,
            "htName": "Fenerbahçe",
            "htCCode": "FEN",
            "htPtName": "Pot 3",
            "atId": 50137,
            "atName": "Roma",
            "atCCode": "ROM",
            "atPtName": "Pot 2",
            "stadiumName": "Fenerbahçe Şükrü Saracoğlu Spor Kompleksi",
            "venueName": "Istanbul"
          },
          {
            "mId": 2049570,
            "gdId": "3",
            "dateTime": "09/10/2026 21:00:00",
            "htId": 79946,
            "htName": "Como",
            "htCCode": "COM",
            "htPtName": "Pot 4",
            "atId": 2603790,
            "atName": "Leipzig",
            "atCCode": "RBL",
            "atPtName": "Pot 3",
            "stadiumName": "Giuseppe Sinigaglia",
            "venueName": "Como"
          },
          {
            "mId": 2049566,
            "gdId": "3",
            "dateTime": "09/10/2026 21:00:00",
            "htId": 52682,
            "htName": "Man Utd",
            "htCCode": "MUN",
            "htPtName": "Pot 2",
            "atId": 2609356,
            "atName": "Sabah",
            "atCCode": "SAB",
            "atPtName": "Pot 4",
            "stadiumName": "Old Trafford",
            "venueName": "Manchester"
          },
          {
            "mId": 2049569,
            "gdId": "3",
            "dateTime": "09/10/2026 21:00:00",
            "htId": 52498,
            "htName": "Slavia Praha",
            "htCCode": "SLA",
            "htPtName": "Pot 4",
            "atId": 52277,
            "atName": "Lens",
            "atCCode": "LEN",
            "atPtName": "Pot 4",
            "stadiumName": "Eden Arena",
            "venueName": "Prague"
          },
          {
            "mId": 2049565,
            "gdId": "3",
            "dateTime": "09/10/2026 21:00:00",
            "htId": 50037,
            "htName": "Bayern München",
            "htCCode": "BAY",
            "htPtName": "Pot 1",
            "atId": 59333,
            "atName": "Bodø/Glimt",
            "atCCode": "BOD",
            "atPtName": "Pot 3",
            "stadiumName": "Fußball Arena München",
            "venueName": "Munich"
          }
        ]
      },
      {
        "mdId": 2,
        "phId": 1,
        "gdIsLocked": 0,
        "gdIsCurrent": 0,
        "subsAllowed": 2,
        "maxSubsCf": 1,
        "deadline": "10/13/26 06:45:00 PM",
        "gameday": 0,
        "gamedayNew": 4,
        "roundId": 2002239,
        "round": "",
        "mdIsLocked": 0,
        "mdIsCurrent": 0,
        "isActNewUser": 0,
        "showLeaderboards": 0,
        "leagueIndent": 0,
        "match": [
          {
            "mId": 2049579,
            "gdId": "4",
            "dateTime": "10/13/2026 18:45:00",
            "htId": 2609356,
            "htName": "Sabah",
            "htCCode": "SAB",
            "htPtName": "Pot 4",
            "atId": 52498,
            "atName": "Slavia Praha",
            "atCCode": "SLA",
            "atPtName": "Pot 4",
            "stadiumName": "",
            "venueName": ""
          },
          {
            "mId": 2049577,
            "gdId": "4",
            "dateTime": "10/13/2026 18:45:00",
            "htId": 52277,
            "htName": "Lens",
            "htCCode": "LEN",
            "htPtName": "Pot 4",
            "atId": 50149,
            "atName": "Sporting CP",
            "atCCode": "SPO",
            "atPtName": "Pot 2",
            "stadiumName": "Stade Bollaert-Delelis",
            "venueName": "Lens Agglo"
          },
          {
            "mId": 2049576,
            "gdId": "4",
            "dateTime": "10/13/2026 21:00:00",
            "htId": 50067,
            "htName": "Galatasaray",
            "htCCode": "GAL",
            "htPtName": "Pot 3",
            "atId": 50080,
            "atName": "Barcelona",
            "atCCode": "BAR",
            "atPtName": "Pot 1",
            "stadiumName": "Ali Sami Yen Spor Kompleksi",
            "venueName": "Istanbul"
          },
          {
            "mId": 2049571,
            "gdId": "4",
            "dateTime": "10/13/2026 21:00:00",
            "htId": 50138,
            "htName": "Inter",
            "htCCode": "INT",
            "htPtName": "Pot 1",
            "atId": 50043,
            "atName": "Club Brugge",
            "atCCode": "BRU",
            "atPtName": "Pot 2",
            "stadiumName": "Stadio San Siro",
            "venueName": "Milan"
          },
          {
            "mId": 2049572,
            "gdId": "4",
            "dateTime": "10/13/2026 21:00:00",
            "htId": 52280,
            "htName": "Arsenal",
            "htCCode": "ARS",
            "htPtName": "Pot 1",
            "atId": 75797,
            "atName": "Lille",
            "atCCode": "LIL",
            "atPtName": "Pot 3",
            "stadiumName": "Arsenal Stadium",
            "venueName": "London"
          },
          {
            "mId": 2049573,
            "gdId": "4",
            "dateTime": "10/13/2026 21:00:00",
            "htId": 50124,
            "htName": "Atleti",
            "htCCode": "ATM",
            "htPtName": "Pot 1",
            "atId": 52682,
            "atName": "Man Utd",
            "atCCode": "MUN",
            "atPtName": "Pot 2",
            "stadiumName": "Estadio Metropolitano",
            "venueName": "Madrid"
          },
          {
            "mId": 2049574,
            "gdId": "4",
            "dateTime": "10/13/2026 21:00:00",
            "htId": 2603790,
            "htName": "Leipzig",
            "htCCode": "RBL",
            "htPtName": "Pot 3",
            "atId": 50062,
            "atName": "PSV",
            "atCCode": "PSV",
            "atPtName": "Pot 2",
            "stadiumName": "RB Arena",
            "venueName": "Leipzig"
          },
          {
            "mId": 2049575,
            "gdId": "4",
            "dateTime": "10/13/2026 21:00:00",
            "htId": 70691,
            "htName": "Villarreal",
            "htCCode": "VIL",
            "htPtName": "Pot 3",
            "atId": 50136,
            "atName": "Napoli",
            "atCCode": "NAP",
            "atPtName": "Pot 3",
            "stadiumName": "Estadio de la Cerámica",
            "venueName": "Villarreal"
          },
          {
            "mId": 2049578,
            "gdId": "4",
            "dateTime": "10/13/2026 21:00:00",
            "htId": 52319,
            "htName": "Viking",
            "htCCode": "VFK",
            "htPtName": "Pot 4",
            "atId": 50037,
            "atName": "Bayern München",
            "atCCode": "BAY",
            "atPtName": "Pot 1",
            "stadiumName": "Viking stadion",
            "venueName": "Stavanger"
          },
          {
            "mId": 2049584,
            "gdId": "5",
            "dateTime": "10/14/2026 18:45:00",
            "htId": 52749,
            "htName": "Feyenoord",
            "htCCode": "FEY",
            "htPtName": "Pot 3",
            "atId": 79946,
            "atName": "Como",
            "atCCode": "COM",
            "atPtName": "Pot 4",
            "stadiumName": "Stadion Feijenoord 'De Kuip'",
            "venueName": "Rotterdam"
          },
          {
            "mId": 2049588,
            "gdId": "5",
            "dateTime": "10/14/2026 18:45:00",
            "htId": 63405,
            "htName": "LASK",
            "htCCode": "LASK",
            "htPtName": "Pot 4",
            "atId": 7889,
            "atName": "Liverpool",
            "atCCode": "LIV",
            "atPtName": "Pot 1",
            "stadiumName": "Oberösterreich Arena",
            "venueName": "Linz"
          },
          {
            "mId": 2049581,
            "gdId": "5",
            "dateTime": "10/14/2026 21:00:00",
            "htId": 50137,
            "htName": "Roma",
            "htCCode": "ROM",
            "htPtName": "Pot 2",
            "atId": 50051,
            "atName": "Real Madrid",
            "atCCode": "RMA",
            "atPtName": "Pot 1",
            "stadiumName": "Stadio Olimpico",
            "venueName": "Rome"
          },
          {
            "mId": 2049582,
            "gdId": "5",
            "dateTime": "10/14/2026 21:00:00",
            "htId": 52683,
            "htName": "Aston Villa",
            "htCCode": "AVL",
            "htPtName": "Pot 2",
            "atId": 52692,
            "atName": "Fenerbahçe",
            "atCCode": "FEN",
            "atPtName": "Pot 3",
            "stadiumName": "Villa Park",
            "venueName": "Birmingham"
          },
          {
            "mId": 2049583,
            "gdId": "5",
            "dateTime": "10/14/2026 21:00:00",
            "htId": 52265,
            "htName": "Real Betis",
            "htCCode": "BET",
            "htPtName": "Pot 2",
            "atId": 50064,
            "atName": "Porto",
            "atCCode": "POR",
            "atPtName": "Pot 2",
            "stadiumName": "LA CARTUJA DE SEVILLA",
            "venueName": "Seville"
          },
          {
            "mId": 2049585,
            "gdId": "5",
            "dateTime": "10/14/2026 21:00:00",
            "htId": 59333,
            "htName": "Bodø/Glimt",
            "htCCode": "BOD",
            "htPtName": "Pot 3",
            "atId": 52758,
            "atName": "B. Dortmund",
            "atCCode": "BVB",
            "atPtName": "Pot 2",
            "stadiumName": "Aspmyra",
            "venueName": "Bodø"
          },
          {
            "mId": 2049587,
            "gdId": "5",
            "dateTime": "10/14/2026 21:00:00",
            "htId": 52797,
            "htName": "S. Bratislava",
            "htCCode": "SBR",
            "htPtName": "Pot 4",
            "atId": 50107,
            "atName": "Stuttgart",
            "atCCode": "STU",
            "atPtName": "Pot 4",
            "stadiumName": "Národný futbalový štadión ",
            "venueName": "Bratislava"
          },
          {
            "mId": 2049586,
            "gdId": "5",
            "dateTime": "10/14/2026 21:00:00",
            "htId": 52707,
            "htName": "Shakhtar",
            "htCCode": "SHK",
            "htPtName": "Pot 3",
            "atId": 50129,
            "atName": "AEK Athens",
            "atCCode": "AEK",
            "atPtName": "Pot 4",
            "stadiumName": "Stamford Bridge",
            "venueName": "London"
          },
          {
            "mId": 2049580,
            "gdId": "5",
            "dateTime": "10/14/2026 21:00:00",
            "htId": 52919,
            "htName": "Man City",
            "htCCode": "MCI",
            "htPtName": "Pot 1",
            "atId": 52747,
            "atName": "Paris",
            "atCCode": "PSG",
            "atPtName": "Pot 1",
            "stadiumName": "City of Manchester Stadium",
            "venueName": "Manchester"
          }
        ]
      },
      {
        "mdId": 3,
        "phId": 1,
        "gdIsLocked": 0,
        "gdIsCurrent": 0,
        "subsAllowed": 2,
        "maxSubsCf": 1,
        "deadline": "10/20/26 06:45:00 PM",
        "gameday": 0,
        "gamedayNew": 1,
        "roundId": 2002239,
        "round": "",
        "mdIsLocked": 0,
        "mdIsCurrent": 0,
        "isActNewUser": 0,
        "showLeaderboards": 0,
        "leagueIndent": 0,
        "match": [
          {
            "mId": 2049595,
            "gdId": "6",
            "dateTime": "10/20/2026 18:45:00",
            "htId": 52692,
            "htName": "Fenerbahçe",
            "htCCode": "FEN",
            "htPtName": "Pot 3",
            "atId": 52498,
            "atName": "Slavia Praha",
            "atCCode": "SLA",
            "atPtName": "Pot 4",
            "stadiumName": "Fenerbahçe Şükrü Saracoğlu Spor Kompleksi",
            "venueName": "Istanbul"
          },
          {
            "mId": 2049597,
            "gdId": "6",
            "dateTime": "10/20/2026 18:45:00",
            "htId": 2609356,
            "htName": "Sabah",
            "htCCode": "SAB",
            "htPtName": "Pot 4",
            "atId": 52758,
            "atName": "B. Dortmund",
            "atCCode": "BVB",
            "atPtName": "Pot 2",
            "stadiumName": "",
            "venueName": ""
          },
          {
            "mId": 2049596,
            "gdId": "6",
            "dateTime": "10/20/2026 21:00:00",
            "htId": 50107,
            "htName": "Stuttgart",
            "htCCode": "STU",
            "htPtName": "Pot 4",
            "atId": 50124,
            "atName": "Atleti",
            "atCCode": "ATM",
            "atPtName": "Pot 1",
            "stadiumName": "Arena Stuttgart",
            "venueName": "Stuttgart"
          },
          {
            "mId": 2049589,
            "gdId": "6",
            "dateTime": "10/20/2026 21:00:00",
            "htId": 52747,
            "htName": "Paris",
            "htCCode": "PSG",
            "htPtName": "Pot 1",
            "atId": 50080,
            "atName": "Barcelona",
            "atCCode": "BAR",
            "atPtName": "Pot 1",
            "stadiumName": "Parc des Princes",
            "venueName": "Paris"
          },
          {
            "mId": 2049590,
            "gdId": "6",
            "dateTime": "10/20/2026 21:00:00",
            "htId": 7889,
            "htName": "Liverpool",
            "htCCode": "LIV",
            "htPtName": "Pot 1",
            "atId": 70691,
            "atName": "Villarreal",
            "atCCode": "VIL",
            "atPtName": "Pot 3",
            "stadiumName": "Anfield",
            "venueName": "Liverpool"
          },
          {
            "mId": 2049591,
            "gdId": "6",
            "dateTime": "10/20/2026 21:00:00",
            "htId": 52919,
            "htName": "Man City",
            "htCCode": "MCI",
            "htPtName": "Pot 1",
            "atId": 50129,
            "atName": "AEK Athens",
            "atCCode": "AEK",
            "atPtName": "Pot 4",
            "stadiumName": "City of Manchester Stadium",
            "venueName": "Manchester"
          },
          {
            "mId": 2049592,
            "gdId": "6",
            "dateTime": "10/20/2026 21:00:00",
            "htId": 50137,
            "htName": "Roma",
            "htCCode": "ROM",
            "htPtName": "Pot 2",
            "atId": 52797,
            "atName": "S. Bratislava",
            "atCCode": "SBR",
            "atPtName": "Pot 4",
            "stadiumName": "Stadio Olimpico",
            "venueName": "Rome"
          },
          {
            "mId": 2049593,
            "gdId": "6",
            "dateTime": "10/20/2026 21:00:00",
            "htId": 50064,
            "htName": "Porto",
            "htCCode": "POR",
            "htPtName": "Pot 2",
            "atId": 50062,
            "atName": "PSV",
            "atCCode": "PSV",
            "atPtName": "Pot 2",
            "stadiumName": "Estádio do Dragão",
            "venueName": "Porto"
          },
          {
            "mId": 2049594,
            "gdId": "6",
            "dateTime": "10/20/2026 21:00:00",
            "htId": 50136,
            "htName": "Napoli",
            "htCCode": "NAP",
            "htPtName": "Pot 3",
            "atId": 59333,
            "atName": "Bodø/Glimt",
            "atCCode": "BOD",
            "atPtName": "Pot 3",
            "stadiumName": "Stadio Diego Armando Maradona",
            "venueName": "Naples"
          },
          {
            "mId": 2049605,
            "gdId": "7",
            "dateTime": "10/21/2026 18:45:00",
            "htId": 75797,
            "htName": "Lille",
            "htCCode": "LIL",
            "htPtName": "Pot 3",
            "atId": 50067,
            "atName": "Galatasaray",
            "atCCode": "GAL",
            "atPtName": "Pot 3",
            "stadiumName": "Stade Pierre Mauroy",
            "venueName": "Villeneuve d'Ascq"
          },
          {
            "mId": 2049606,
            "gdId": "7",
            "dateTime": "10/21/2026 18:45:00",
            "htId": 79946,
            "htName": "Como",
            "htCCode": "COM",
            "htPtName": "Pot 4",
            "atId": 52682,
            "atName": "Man Utd",
            "atCCode": "MUN",
            "atPtName": "Pot 2",
            "stadiumName": "Giuseppe Sinigaglia",
            "venueName": "Como"
          },
          {
            "mId": 2049603,
            "gdId": "7",
            "dateTime": "10/21/2026 21:00:00",
            "htId": 50043,
            "htName": "Club Brugge",
            "htCCode": "BRU",
            "htPtName": "Pot 2",
            "atId": 52277,
            "atName": "Lens",
            "atCCode": "LEN",
            "atPtName": "Pot 4",
            "stadiumName": "Jan Breydelstadion",
            "venueName": "Bruges"
          },
          {
            "mId": 2049598,
            "gdId": "7",
            "dateTime": "10/21/2026 21:00:00",
            "htId": 50037,
            "htName": "Bayern München",
            "htCCode": "BAY",
            "htPtName": "Pot 1",
            "atId": 52280,
            "atName": "Arsenal",
            "atCCode": "ARS",
            "atPtName": "Pot 1",
            "stadiumName": "Fußball Arena München",
            "venueName": "Munich"
          },
          {
            "mId": 2049599,
            "gdId": "7",
            "dateTime": "10/21/2026 21:00:00",
            "htId": 50051,
            "htName": "Real Madrid",
            "htCCode": "RMA",
            "htPtName": "Pot 1",
            "atId": 2603790,
            "atName": "Leipzig",
            "atCCode": "RBL",
            "atPtName": "Pot 3",
            "stadiumName": "Estadio Santiago Bernabéu",
            "venueName": "Madrid"
          },
          {
            "mId": 2049600,
            "gdId": "7",
            "dateTime": "10/21/2026 21:00:00",
            "htId": 50138,
            "htName": "Inter",
            "htCCode": "INT",
            "htPtName": "Pot 1",
            "atId": 52707,
            "atName": "Shakhtar",
            "atCCode": "SHK",
            "atPtName": "Pot 3",
            "stadiumName": "Stadio San Siro",
            "venueName": "Milan"
          },
          {
            "mId": 2049601,
            "gdId": "7",
            "dateTime": "10/21/2026 21:00:00",
            "htId": 50149,
            "htName": "Sporting CP",
            "htCCode": "SPO",
            "htPtName": "Pot 2",
            "atId": 63405,
            "atName": "LASK",
            "atCCode": "LASK",
            "atPtName": "Pot 4",
            "stadiumName": "Estádio José Alvalade",
            "venueName": "Lisbon"
          },
          {
            "mId": 2049602,
            "gdId": "7",
            "dateTime": "10/21/2026 21:00:00",
            "htId": 52683,
            "htName": "Aston Villa",
            "htCCode": "AVL",
            "htPtName": "Pot 2",
            "atId": 52319,
            "atName": "Viking",
            "atCCode": "VFK",
            "atPtName": "Pot 4",
            "stadiumName": "Villa Park",
            "venueName": "Birmingham"
          },
          {
            "mId": 2049604,
            "gdId": "7",
            "dateTime": "10/21/2026 21:00:00",
            "htId": 52265,
            "htName": "Real Betis",
            "htCCode": "BET",
            "htPtName": "Pot 2",
            "atId": 52749,
            "atName": "Feyenoord",
            "atCCode": "FEY",
            "atPtName": "Pot 3",
            "stadiumName": "LA CARTUJA DE SEVILLA",
            "venueName": "Seville"
          }
        ]
      },
      {
        "mdId": 4,
        "phId": 1,
        "gdIsLocked": 0,
        "gdIsCurrent": 0,
        "subsAllowed": 2,
        "maxSubsCf": 1,
        "deadline": "11/03/26 06:45:00 PM",
        "gameday": 0,
        "gamedayNew": 1,
        "roundId": 2002239,
        "round": "",
        "mdIsLocked": 0,
        "mdIsCurrent": 0,
        "isActNewUser": 0,
        "showLeaderboards": 0,
        "leagueIndent": 0,
        "match": [
          {
            "mId": 2049613,
            "gdId": "8",
            "dateTime": "11/03/2026 18:45:00",
            "htId": 52707,
            "htName": "Shakhtar",
            "htCCode": "SHK",
            "htPtName": "Pot 3",
            "atId": 50149,
            "atName": "Sporting CP",
            "atCCode": "SPO",
            "atPtName": "Pot 2",
            "stadiumName": "Stamford Bridge",
            "venueName": "London"
          },
          {
            "mId": 2049614,
            "gdId": "8",
            "dateTime": "11/03/2026 18:45:00",
            "htId": 50067,
            "htName": "Galatasaray",
            "htCCode": "GAL",
            "htPtName": "Pot 3",
            "atId": 50107,
            "atName": "Stuttgart",
            "atCCode": "STU",
            "atPtName": "Pot 4",
            "stadiumName": "Ali Sami Yen Spor Kompleksi",
            "venueName": "Istanbul"
          },
          {
            "mId": 2049608,
            "gdId": "8",
            "dateTime": "11/03/2026 21:00:00",
            "htId": 50124,
            "htName": "Atleti",
            "htCCode": "ATM",
            "htPtName": "Pot 1",
            "atId": 50037,
            "atName": "Bayern München",
            "atCCode": "BAY",
            "atPtName": "Pot 1",
            "stadiumName": "Estadio Metropolitano",
            "venueName": "Madrid"
          },
          {
            "mId": 2049612,
            "gdId": "8",
            "dateTime": "11/03/2026 21:00:00",
            "htId": 70691,
            "htName": "Villarreal",
            "htCCode": "VIL",
            "htPtName": "Pot 3",
            "atId": 52747,
            "atName": "Paris",
            "atCCode": "PSG",
            "atPtName": "Pot 1",
            "stadiumName": "Estadio de la Cerámica",
            "venueName": "Villarreal"
          },
          {
            "mId": 2049607,
            "gdId": "8",
            "dateTime": "11/03/2026 21:00:00",
            "htId": 50080,
            "htName": "Barcelona",
            "htCCode": "BAR",
            "htPtName": "Pot 1",
            "atId": 52683,
            "atName": "Aston Villa",
            "atCCode": "AVL",
            "atPtName": "Pot 2",
            "stadiumName": "Camp Nou",
            "venueName": "Barcelona"
          },
          {
            "mId": 2049609,
            "gdId": "8",
            "dateTime": "11/03/2026 21:00:00",
            "htId": 52682,
            "htName": "Man Utd",
            "htCCode": "MUN",
            "htPtName": "Pot 2",
            "atId": 50137,
            "atName": "Roma",
            "atCCode": "ROM",
            "atPtName": "Pot 2",
            "stadiumName": "Old Trafford",
            "venueName": "Manchester"
          },
          {
            "mId": 2049610,
            "gdId": "8",
            "dateTime": "11/03/2026 21:00:00",
            "htId": 52749,
            "htName": "Feyenoord",
            "htCCode": "FEY",
            "htPtName": "Pot 3",
            "atId": 50138,
            "atName": "Inter",
            "atCCode": "INT",
            "atPtName": "Pot 1",
            "stadiumName": "Stadion Feijenoord 'De Kuip'",
            "venueName": "Rotterdam"
          },
          {
            "mId": 2049611,
            "gdId": "8",
            "dateTime": "11/03/2026 21:00:00",
            "htId": 59333,
            "htName": "Bodø/Glimt",
            "htCCode": "BOD",
            "htPtName": "Pot 3",
            "atId": 75797,
            "atName": "Lille",
            "atCCode": "LIL",
            "atPtName": "Pot 3",
            "stadiumName": "Aspmyra",
            "venueName": "Bodø"
          },
          {
            "mId": 2049615,
            "gdId": "8",
            "dateTime": "11/03/2026 21:00:00",
            "htId": 63405,
            "htName": "LASK",
            "htCCode": "LASK",
            "htPtName": "Pot 4",
            "atId": 52797,
            "atName": "S. Bratislava",
            "atCCode": "SBR",
            "atPtName": "Pot 4",
            "stadiumName": "Oberösterreich Arena",
            "venueName": "Linz"
          },
          {
            "mId": 2049622,
            "gdId": "9",
            "dateTime": "11/04/2026 18:45:00",
            "htId": 50129,
            "htName": "AEK Athens",
            "htCCode": "AEK",
            "htPtName": "Pot 4",
            "atId": 50051,
            "atName": "Real Madrid",
            "atCCode": "RMA",
            "atPtName": "Pot 1",
            "stadiumName": "AEK Arena",
            "venueName": "Athens"
          },
          {
            "mId": 2049620,
            "gdId": "9",
            "dateTime": "11/04/2026 18:45:00",
            "htId": 52692,
            "htName": "Fenerbahçe",
            "htCCode": "FEN",
            "htPtName": "Pot 3",
            "atId": 7889,
            "atName": "Liverpool",
            "atCCode": "LIV",
            "atPtName": "Pot 1",
            "stadiumName": "Fenerbahçe Şükrü Saracoğlu Spor Kompleksi",
            "venueName": "Istanbul"
          },
          {
            "mId": 2049617,
            "gdId": "9",
            "dateTime": "11/04/2026 21:00:00",
            "htId": 50064,
            "htName": "Porto",
            "htCCode": "POR",
            "htPtName": "Pot 2",
            "atId": 50136,
            "atName": "Napoli",
            "atCCode": "NAP",
            "atPtName": "Pot 3",
            "stadiumName": "Estádio do Dragão",
            "venueName": "Porto"
          },
          {
            "mId": 2049624,
            "gdId": "9",
            "dateTime": "11/04/2026 21:00:00",
            "htId": 52319,
            "htName": "Viking",
            "htCCode": "VFK",
            "htPtName": "Pot 4",
            "atId": 2609356,
            "atName": "Sabah",
            "atCCode": "SAB",
            "atPtName": "Pot 4",
            "stadiumName": "Viking stadion",
            "venueName": "Stavanger"
          },
          {
            "mId": 2049619,
            "gdId": "9",
            "dateTime": "11/04/2026 21:00:00",
            "htId": 2603790,
            "htName": "Leipzig",
            "htCCode": "RBL",
            "htPtName": "Pot 3",
            "atId": 52919,
            "atName": "Man City",
            "atCCode": "MCI",
            "atPtName": "Pot 1",
            "stadiumName": "RB Arena",
            "venueName": "Leipzig"
          },
          {
            "mId": 2049621,
            "gdId": "9",
            "dateTime": "11/04/2026 21:00:00",
            "htId": 52498,
            "htName": "Slavia Praha",
            "htCCode": "SLA",
            "htPtName": "Pot 4",
            "atId": 52280,
            "atName": "Arsenal",
            "atCCode": "ARS",
            "atPtName": "Pot 1",
            "stadiumName": "Eden Arena",
            "venueName": "Prague"
          },
          {
            "mId": 2049623,
            "gdId": "9",
            "dateTime": "11/04/2026 21:00:00",
            "htId": 52277,
            "htName": "Lens",
            "htCCode": "LEN",
            "htPtName": "Pot 4",
            "atId": 79946,
            "atName": "Como",
            "atCCode": "COM",
            "atPtName": "Pot 4",
            "stadiumName": "Stade Bollaert-Delelis",
            "venueName": "Lens Agglo"
          },
          {
            "mId": 2049618,
            "gdId": "9",
            "dateTime": "11/04/2026 21:00:00",
            "htId": 50062,
            "htName": "PSV",
            "htCCode": "PSV",
            "htPtName": "Pot 2",
            "atId": 50043,
            "atName": "Club Brugge",
            "atCCode": "BRU",
            "atPtName": "Pot 2",
            "stadiumName": "PSV Stadion",
            "venueName": "Eindhoven"
          },
          {
            "mId": 2049616,
            "gdId": "9",
            "dateTime": "11/04/2026 21:00:00",
            "htId": 52758,
            "htName": "B. Dortmund",
            "htCCode": "BVB",
            "htPtName": "Pot 2",
            "atId": 52265,
            "atName": "Real Betis",
            "atCCode": "BET",
            "atPtName": "Pot 2",
            "stadiumName": "BVB Stadion Dortmund",
            "venueName": "Dortmund"
          }
        ]
      },
      {
        "mdId": 5,
        "phId": 1,
        "gdIsLocked": 0,
        "gdIsCurrent": 0,
        "subsAllowed": 2,
        "maxSubsCf": 1,
        "deadline": "11/24/26 06:45:00 PM",
        "gameday": 0,
        "gamedayNew": 1,
        "roundId": 2002239,
        "round": "",
        "mdIsLocked": 0,
        "mdIsCurrent": 0,
        "isActNewUser": 0,
        "showLeaderboards": 0,
        "leagueIndent": 0,
        "match": [
          {
            "mId": 2049629,
            "gdId": "10",
            "dateTime": "11/24/2026 18:45:00",
            "htId": 59333,
            "htName": "Bodø/Glimt",
            "htCCode": "BOD",
            "htPtName": "Pot 3",
            "atId": 63405,
            "atName": "LASK",
            "atCCode": "LASK",
            "atPtName": "Pot 4",
            "stadiumName": "Aspmyra",
            "venueName": "Bodø"
          },
          {
            "mId": 2049631,
            "gdId": "10",
            "dateTime": "11/24/2026 18:45:00",
            "htId": 50067,
            "htName": "Galatasaray",
            "htCCode": "GAL",
            "htPtName": "Pot 3",
            "atId": 52683,
            "atName": "Aston Villa",
            "atCCode": "AVL",
            "atPtName": "Pot 2",
            "stadiumName": "Ali Sami Yen Spor Kompleksi",
            "venueName": "Istanbul"
          },
          {
            "mId": 2049632,
            "gdId": "10",
            "dateTime": "11/24/2026 21:00:00",
            "htId": 52797,
            "htName": "S. Bratislava",
            "htCCode": "SBR",
            "htPtName": "Pot 4",
            "atId": 52265,
            "atName": "Real Betis",
            "atCCode": "BET",
            "atPtName": "Pot 2",
            "stadiumName": "Národný futbalový štadión ",
            "venueName": "Bratislava"
          },
          {
            "mId": 2049627,
            "gdId": "10",
            "dateTime": "11/24/2026 21:00:00",
            "htId": 52280,
            "htName": "Arsenal",
            "htCCode": "ARS",
            "htPtName": "Pot 1",
            "atId": 52758,
            "atName": "B. Dortmund",
            "atCCode": "BVB",
            "atPtName": "Pot 2",
            "stadiumName": "Arsenal Stadium",
            "venueName": "London"
          },
          {
            "mId": 2049630,
            "gdId": "10",
            "dateTime": "11/24/2026 21:00:00",
            "htId": 2603790,
            "htName": "Leipzig",
            "htCCode": "RBL",
            "htPtName": "Pot 3",
            "atId": 52277,
            "atName": "Lens",
            "atCCode": "LEN",
            "atPtName": "Pot 4",
            "stadiumName": "RB Arena",
            "venueName": "Leipzig"
          },
          {
            "mId": 2049628,
            "gdId": "10",
            "dateTime": "11/24/2026 21:00:00",
            "htId": 52749,
            "htName": "Feyenoord",
            "htCCode": "FEY",
            "htPtName": "Pot 3",
            "atId": 50064,
            "atName": "Porto",
            "atCCode": "POR",
            "atPtName": "Pot 2",
            "stadiumName": "Stadion Feijenoord 'De Kuip'",
            "venueName": "Rotterdam"
          },
          {
            "mId": 2049626,
            "gdId": "10",
            "dateTime": "11/24/2026 21:00:00",
            "htId": 52919,
            "htName": "Man City",
            "htCCode": "MCI",
            "htPtName": "Pot 1",
            "atId": 50136,
            "atName": "Napoli",
            "atCCode": "NAP",
            "atPtName": "Pot 3",
            "stadiumName": "City of Manchester Stadium",
            "venueName": "Manchester"
          },
          {
            "mId": 2049625,
            "gdId": "10",
            "dateTime": "11/24/2026 21:00:00",
            "htId": 50051,
            "htName": "Real Madrid",
            "htCCode": "RMA",
            "htPtName": "Pot 1",
            "atId": 50062,
            "atName": "PSV",
            "atCCode": "PSV",
            "atPtName": "Pot 2",
            "stadiumName": "Estadio Santiago Bernabéu",
            "venueName": "Madrid"
          },
          {
            "mId": 2049633,
            "gdId": "10",
            "dateTime": "11/24/2026 21:00:00",
            "htId": 79946,
            "htName": "Como",
            "htCCode": "COM",
            "htPtName": "Pot 4",
            "atId": 50129,
            "atName": "AEK Athens",
            "atCCode": "AEK",
            "atPtName": "Pot 4",
            "stadiumName": "Giuseppe Sinigaglia",
            "venueName": "Como"
          },
          {
            "mId": 2049642,
            "gdId": "11",
            "dateTime": "11/25/2026 18:45:00",
            "htId": 2609356,
            "htName": "Sabah",
            "htCCode": "SAB",
            "htPtName": "Pot 4",
            "atId": 50080,
            "atName": "Barcelona",
            "atCCode": "BAR",
            "atPtName": "Pot 1",
            "stadiumName": "",
            "venueName": ""
          },
          {
            "mId": 2049641,
            "gdId": "11",
            "dateTime": "11/25/2026 18:45:00",
            "htId": 52498,
            "htName": "Slavia Praha",
            "htCCode": "SLA",
            "htPtName": "Pot 4",
            "atId": 70691,
            "atName": "Villarreal",
            "atCCode": "VIL",
            "atPtName": "Pot 3",
            "stadiumName": "Eden Arena",
            "venueName": "Prague"
          },
          {
            "mId": 2049640,
            "gdId": "11",
            "dateTime": "11/25/2026 21:00:00",
            "htId": 52707,
            "htName": "Shakhtar",
            "htCCode": "SHK",
            "htPtName": "Pot 3",
            "atId": 52692,
            "atName": "Fenerbahçe",
            "atCCode": "FEN",
            "atPtName": "Pot 3",
            "stadiumName": "Stamford Bridge",
            "venueName": "London"
          },
          {
            "mId": 2049634,
            "gdId": "11",
            "dateTime": "11/25/2026 21:00:00",
            "htId": 52747,
            "htName": "Paris",
            "htCCode": "PSG",
            "htPtName": "Pot 1",
            "atId": 50137,
            "atName": "Roma",
            "atCCode": "ROM",
            "atPtName": "Pot 2",
            "stadiumName": "Parc des Princes",
            "venueName": "Paris"
          },
          {
            "mId": 2049635,
            "gdId": "11",
            "dateTime": "11/25/2026 21:00:00",
            "htId": 50138,
            "htName": "Inter",
            "htCCode": "INT",
            "htPtName": "Pot 1",
            "atId": 50107,
            "atName": "Stuttgart",
            "atCCode": "STU",
            "atPtName": "Pot 4",
            "stadiumName": "Stadio San Siro",
            "venueName": "Milan"
          },
          {
            "mId": 2049636,
            "gdId": "11",
            "dateTime": "11/25/2026 21:00:00",
            "htId": 50124,
            "htName": "Atleti",
            "htCCode": "ATM",
            "htPtName": "Pot 1",
            "atId": 52319,
            "atName": "Viking",
            "atCCode": "VFK",
            "atPtName": "Pot 4",
            "stadiumName": "Estadio Metropolitano",
            "venueName": "Madrid"
          },
          {
            "mId": 2049637,
            "gdId": "11",
            "dateTime": "11/25/2026 21:00:00",
            "htId": 50149,
            "htName": "Sporting CP",
            "htCCode": "SPO",
            "htPtName": "Pot 2",
            "atId": 52682,
            "atName": "Man Utd",
            "atCCode": "MUN",
            "atPtName": "Pot 2",
            "stadiumName": "Estádio José Alvalade",
            "venueName": "Lisbon"
          },
          {
            "mId": 2049638,
            "gdId": "11",
            "dateTime": "11/25/2026 21:00:00",
            "htId": 50043,
            "htName": "Club Brugge",
            "htCCode": "BRU",
            "htPtName": "Pot 2",
            "atId": 7889,
            "atName": "Liverpool",
            "atCCode": "LIV",
            "atPtName": "Pot 1",
            "stadiumName": "Jan Breydelstadion",
            "venueName": "Bruges"
          },
          {
            "mId": 2049639,
            "gdId": "11",
            "dateTime": "11/25/2026 21:00:00",
            "htId": 75797,
            "htName": "Lille",
            "htCCode": "LIL",
            "htPtName": "Pot 3",
            "atId": 50037,
            "atName": "Bayern München",
            "atCCode": "BAY",
            "atPtName": "Pot 1",
            "stadiumName": "Stade Pierre Mauroy",
            "venueName": "Villeneuve d'Ascq"
          }
        ]
      },
      {
        "mdId": 6,
        "phId": 1,
        "gdIsLocked": 0,
        "gdIsCurrent": 0,
        "subsAllowed": 2,
        "maxSubsCf": 1,
        "deadline": "12/08/26 06:45:00 PM",
        "gameday": 0,
        "gamedayNew": 1,
        "roundId": 2002239,
        "round": "",
        "mdIsLocked": 0,
        "mdIsCurrent": 0,
        "isActNewUser": 0,
        "showLeaderboards": 0,
        "leagueIndent": 0,
        "match": [
          {
            "mId": 2049651,
            "gdId": "12",
            "dateTime": "12/08/2026 18:45:00",
            "htId": 52319,
            "htName": "Viking",
            "htCCode": "VFK",
            "htPtName": "Pot 4",
            "atId": 52749,
            "atName": "Feyenoord",
            "atCCode": "FEY",
            "atPtName": "Pot 3",
            "stadiumName": "Viking stadion",
            "venueName": "Stavanger"
          },
          {
            "mId": 2049649,
            "gdId": "12",
            "dateTime": "12/08/2026 18:45:00",
            "htId": 70691,
            "htName": "Villarreal",
            "htCCode": "VIL",
            "htPtName": "Pot 3",
            "atId": 2609356,
            "atName": "Sabah",
            "atCCode": "SAB",
            "atPtName": "Pot 4",
            "stadiumName": "Estadio de la Cerámica",
            "venueName": "Villarreal"
          },
          {
            "mId": 2049643,
            "gdId": "12",
            "dateTime": "12/08/2026 21:00:00",
            "htId": 50037,
            "htName": "Bayern München",
            "htCCode": "BAY",
            "htPtName": "Pot 1",
            "atId": 52498,
            "atName": "Slavia Praha",
            "atCCode": "SLA",
            "atPtName": "Pot 4",
            "stadiumName": "Fußball Arena München",
            "venueName": "Munich"
          },
          {
            "mId": 2049644,
            "gdId": "12",
            "dateTime": "12/08/2026 21:00:00",
            "htId": 50080,
            "htName": "Barcelona",
            "htCCode": "BAR",
            "htPtName": "Pot 1",
            "atId": 52919,
            "atName": "Man City",
            "atCCode": "MCI",
            "atPtName": "Pot 1",
            "stadiumName": "Camp Nou",
            "venueName": "Barcelona"
          },
          {
            "mId": 2049645,
            "gdId": "12",
            "dateTime": "12/08/2026 21:00:00",
            "htId": 50137,
            "htName": "Roma",
            "htCCode": "ROM",
            "htPtName": "Pot 2",
            "atId": 50149,
            "atName": "Sporting CP",
            "atCCode": "SPO",
            "atPtName": "Pot 2",
            "stadiumName": "Stadio Olimpico",
            "venueName": "Rome"
          },
          {
            "mId": 2049646,
            "gdId": "12",
            "dateTime": "12/08/2026 21:00:00",
            "htId": 52683,
            "htName": "Aston Villa",
            "htCCode": "AVL",
            "htPtName": "Pot 2",
            "atId": 52747,
            "atName": "Paris",
            "atCCode": "PSG",
            "atPtName": "Pot 1",
            "stadiumName": "Villa Park",
            "venueName": "Birmingham"
          },
          {
            "mId": 2049647,
            "gdId": "12",
            "dateTime": "12/08/2026 21:00:00",
            "htId": 52682,
            "htName": "Man Utd",
            "htCCode": "MUN",
            "htPtName": "Pot 2",
            "atId": 2603790,
            "atName": "Leipzig",
            "atCCode": "RBL",
            "atPtName": "Pot 3",
            "stadiumName": "Old Trafford",
            "venueName": "Manchester"
          },
          {
            "mId": 2049648,
            "gdId": "12",
            "dateTime": "12/08/2026 21:00:00",
            "htId": 50136,
            "htName": "Napoli",
            "htCCode": "NAP",
            "htPtName": "Pot 3",
            "atId": 50043,
            "atName": "Club Brugge",
            "atCCode": "BRU",
            "atPtName": "Pot 2",
            "stadiumName": "Stadio Diego Armando Maradona",
            "venueName": "Naples"
          },
          {
            "mId": 2049650,
            "gdId": "12",
            "dateTime": "12/08/2026 21:00:00",
            "htId": 50129,
            "htName": "AEK Athens",
            "htCCode": "AEK",
            "htPtName": "Pot 4",
            "atId": 50067,
            "atName": "Galatasaray",
            "atCCode": "GAL",
            "atPtName": "Pot 3",
            "stadiumName": "AEK Arena",
            "venueName": "Athens"
          },
          {
            "mId": 2049655,
            "gdId": "13",
            "dateTime": "12/09/2026 18:45:00",
            "htId": 52265,
            "htName": "Real Betis",
            "htCCode": "BET",
            "htPtName": "Pot 2",
            "atId": 79946,
            "atName": "Como",
            "atCCode": "COM",
            "atPtName": "Pot 4",
            "stadiumName": "LA CARTUJA DE SEVILLA",
            "venueName": "Seville"
          },
          {
            "mId": 2049657,
            "gdId": "13",
            "dateTime": "12/09/2026 18:45:00",
            "htId": 52797,
            "htName": "S. Bratislava",
            "htCCode": "SBR",
            "htPtName": "Pot 4",
            "atId": 52707,
            "atName": "Shakhtar",
            "atCCode": "SHK",
            "atPtName": "Pot 3",
            "stadiumName": "Národný futbalový štadión ",
            "venueName": "Bratislava"
          },
          {
            "mId": 2049652,
            "gdId": "13",
            "dateTime": "12/09/2026 21:00:00",
            "htId": 7889,
            "htName": "Liverpool",
            "htCCode": "LIV",
            "htPtName": "Pot 1",
            "atId": 50064,
            "atName": "Porto",
            "atCCode": "POR",
            "atPtName": "Pot 2",
            "stadiumName": "Anfield",
            "venueName": "Liverpool"
          },
          {
            "mId": 2049653,
            "gdId": "13",
            "dateTime": "12/09/2026 21:00:00",
            "htId": 52280,
            "htName": "Arsenal",
            "htCCode": "ARS",
            "htPtName": "Pot 1",
            "atId": 50051,
            "atName": "Real Madrid",
            "atCCode": "RMA",
            "atPtName": "Pot 1",
            "stadiumName": "Arsenal Stadium",
            "venueName": "London"
          },
          {
            "mId": 2049654,
            "gdId": "13",
            "dateTime": "12/09/2026 21:00:00",
            "htId": 52758,
            "htName": "B. Dortmund",
            "htCCode": "BVB",
            "htPtName": "Pot 2",
            "atId": 50138,
            "atName": "Inter",
            "atCCode": "INT",
            "atPtName": "Pot 1",
            "stadiumName": "BVB Stadion Dortmund",
            "venueName": "Dortmund"
          },
          {
            "mId": 2049656,
            "gdId": "13",
            "dateTime": "12/09/2026 21:00:00",
            "htId": 50062,
            "htName": "PSV",
            "htCCode": "PSV",
            "htPtName": "Pot 2",
            "atId": 50124,
            "atName": "Atleti",
            "atCCode": "ATM",
            "atPtName": "Pot 1",
            "stadiumName": "PSV Stadion",
            "venueName": "Eindhoven"
          },
          {
            "mId": 2049658,
            "gdId": "13",
            "dateTime": "12/09/2026 21:00:00",
            "htId": 50107,
            "htName": "Stuttgart",
            "htCCode": "STU",
            "htPtName": "Pot 4",
            "atId": 75797,
            "atName": "Lille",
            "atCCode": "LIL",
            "atPtName": "Pot 3",
            "stadiumName": "Arena Stuttgart",
            "venueName": "Stuttgart"
          },
          {
            "mId": 2049659,
            "gdId": "13",
            "dateTime": "12/09/2026 21:00:00",
            "htId": 63405,
            "htName": "LASK",
            "htCCode": "LASK",
            "htPtName": "Pot 4",
            "atId": 52692,
            "atName": "Fenerbahçe",
            "atCCode": "FEN",
            "atPtName": "Pot 3",
            "stadiumName": "Oberösterreich Arena",
            "venueName": "Linz"
          },
          {
            "mId": 2049660,
            "gdId": "13",
            "dateTime": "12/09/2026 21:00:00",
            "htId": 52277,
            "htName": "Lens",
            "htCCode": "LEN",
            "htPtName": "Pot 4",
            "atId": 59333,
            "atName": "Bodø/Glimt",
            "atCCode": "BOD",
            "atPtName": "Pot 3",
            "stadiumName": "Stade Bollaert-Delelis",
            "venueName": "Lens Agglo"
          }
        ]
      },
      {
        "mdId": 7,
        "phId": 1,
        "gdIsLocked": 0,
        "gdIsCurrent": 0,
        "subsAllowed": 2,
        "maxSubsCf": 1,
        "deadline": "01/19/27 06:45:00 PM",
        "gameday": 0,
        "gamedayNew": 1,
        "roundId": 2002239,
        "round": "",
        "mdIsLocked": 0,
        "mdIsCurrent": 0,
        "isActNewUser": 0,
        "showLeaderboards": 0,
        "leagueIndent": 0,
        "match": [
          {
            "mId": 2049666,
            "gdId": "14",
            "dateTime": "01/19/2027 18:45:00",
            "htId": 59333,
            "htName": "Bodø/Glimt",
            "htCCode": "BOD",
            "htPtName": "Pot 3",
            "atId": 50124,
            "atName": "Atleti",
            "atCCode": "ATM",
            "atPtName": "Pot 1",
            "stadiumName": "Aspmyra",
            "venueName": "Bodø"
          },
          {
            "mId": 2049667,
            "gdId": "14",
            "dateTime": "01/19/2027 18:45:00",
            "htId": 50067,
            "htName": "Galatasaray",
            "htCCode": "GAL",
            "htPtName": "Pot 3",
            "atId": 52749,
            "atName": "Feyenoord",
            "atCCode": "FEY",
            "atPtName": "Pot 3",
            "stadiumName": "Ali Sami Yen Spor Kompleksi",
            "venueName": "Istanbul"
          },
          {
            "mId": 2049664,
            "gdId": "14",
            "dateTime": "01/19/2027 21:00:00",
            "htId": 50064,
            "htName": "Porto",
            "htCCode": "POR",
            "htPtName": "Pot 2",
            "atId": 52498,
            "atName": "Slavia Praha",
            "atCCode": "SLA",
            "atPtName": "Pot 4",
            "stadiumName": "Estádio do Dragão",
            "venueName": "Porto"
          },
          {
            "mId": 2049665,
            "gdId": "14",
            "dateTime": "01/19/2027 21:00:00",
            "htId": 75797,
            "htName": "Lille",
            "htCCode": "LIL",
            "htPtName": "Pot 3",
            "atId": 52797,
            "atName": "S. Bratislava",
            "atCCode": "SBR",
            "atPtName": "Pot 4",
            "stadiumName": "Stade Pierre Mauroy",
            "venueName": "Villeneuve d'Ascq"
          },
          {
            "mId": 2049668,
            "gdId": "14",
            "dateTime": "01/19/2027 21:00:00",
            "htId": 50107,
            "htName": "Stuttgart",
            "htCCode": "STU",
            "htPtName": "Pot 4",
            "atId": 50043,
            "atName": "Club Brugge",
            "atCCode": "BRU",
            "atPtName": "Pot 2",
            "stadiumName": "Arena Stuttgart",
            "venueName": "Stuttgart"
          },
          {
            "mId": 2049669,
            "gdId": "14",
            "dateTime": "01/19/2027 21:00:00",
            "htId": 50129,
            "htName": "AEK Athens",
            "htCCode": "AEK",
            "htPtName": "Pot 4",
            "atId": 50137,
            "atName": "Roma",
            "atCCode": "ROM",
            "atPtName": "Pot 2",
            "stadiumName": "AEK Arena",
            "venueName": "Athens"
          },
          {
            "mId": 2049661,
            "gdId": "14",
            "dateTime": "01/19/2027 21:00:00",
            "htId": 50051,
            "htName": "Real Madrid",
            "htCCode": "RMA",
            "htPtName": "Pot 1",
            "atId": 63405,
            "atName": "LASK",
            "atCCode": "LASK",
            "atPtName": "Pot 4",
            "stadiumName": "Estadio Santiago Bernabéu",
            "venueName": "Madrid"
          },
          {
            "mId": 2049662,
            "gdId": "14",
            "dateTime": "01/19/2027 21:00:00",
            "htId": 50138,
            "htName": "Inter",
            "htCCode": "INT",
            "htPtName": "Pot 1",
            "atId": 7889,
            "atName": "Liverpool",
            "atCCode": "LIV",
            "atPtName": "Pot 1",
            "stadiumName": "Stadio San Siro",
            "venueName": "Milan"
          },
          {
            "mId": 2049663,
            "gdId": "14",
            "dateTime": "01/19/2027 21:00:00",
            "htId": 52683,
            "htName": "Aston Villa",
            "htCCode": "AVL",
            "htPtName": "Pot 2",
            "atId": 52758,
            "atName": "B. Dortmund",
            "atCCode": "BVB",
            "atPtName": "Pot 2",
            "stadiumName": "Villa Park",
            "venueName": "Birmingham"
          },
          {
            "mId": 2049678,
            "gdId": "15",
            "dateTime": "01/20/2027 18:45:00",
            "htId": 2609356,
            "htName": "Sabah",
            "htCCode": "SAB",
            "htPtName": "Pot 4",
            "atId": 50136,
            "atName": "Napoli",
            "atCCode": "NAP",
            "atPtName": "Pot 3",
            "stadiumName": "",
            "venueName": ""
          },
          {
            "mId": 2049674,
            "gdId": "15",
            "dateTime": "01/20/2027 18:45:00",
            "htId": 52692,
            "htName": "Fenerbahçe",
            "htCCode": "FEN",
            "htPtName": "Pot 3",
            "atId": 70691,
            "atName": "Villarreal",
            "atCCode": "VIL",
            "atPtName": "Pot 3",
            "stadiumName": "Fenerbahçe Şükrü Saracoğlu Spor Kompleksi",
            "venueName": "Istanbul"
          },
          {
            "mId": 2049673,
            "gdId": "15",
            "dateTime": "01/20/2027 21:00:00",
            "htId": 2603790,
            "htName": "Leipzig",
            "htCCode": "RBL",
            "htPtName": "Pot 3",
            "atId": 52707,
            "atName": "Shakhtar",
            "atCCode": "SHK",
            "atPtName": "Pot 3",
            "stadiumName": "RB Arena",
            "venueName": "Leipzig"
          },
          {
            "mId": 2049675,
            "gdId": "15",
            "dateTime": "01/20/2027 21:00:00",
            "htId": 79946,
            "htName": "Como",
            "htCCode": "COM",
            "htPtName": "Pot 4",
            "atId": 52747,
            "atName": "Paris",
            "atCCode": "PSG",
            "atPtName": "Pot 1",
            "stadiumName": "Giuseppe Sinigaglia",
            "venueName": "Como"
          },
          {
            "mId": 2049676,
            "gdId": "15",
            "dateTime": "01/20/2027 21:00:00",
            "htId": 52277,
            "htName": "Lens",
            "htCCode": "LEN",
            "htPtName": "Pot 4",
            "atId": 52919,
            "atName": "Man City",
            "atCCode": "MCI",
            "atPtName": "Pot 1",
            "stadiumName": "Stade Bollaert-Delelis",
            "venueName": "Lens Agglo"
          },
          {
            "mId": 2049677,
            "gdId": "15",
            "dateTime": "01/20/2027 21:00:00",
            "htId": 52319,
            "htName": "Viking",
            "htCCode": "VFK",
            "htPtName": "Pot 4",
            "atId": 50062,
            "atName": "PSV",
            "atCCode": "PSV",
            "atPtName": "Pot 2",
            "stadiumName": "Viking stadion",
            "venueName": "Stavanger"
          },
          {
            "mId": 2049671,
            "gdId": "15",
            "dateTime": "01/20/2027 21:00:00",
            "htId": 52682,
            "htName": "Man Utd",
            "htCCode": "MUN",
            "htPtName": "Pot 2",
            "atId": 50037,
            "atName": "Bayern München",
            "atCCode": "BAY",
            "atPtName": "Pot 1",
            "stadiumName": "Old Trafford",
            "venueName": "Manchester"
          },
          {
            "mId": 2049670,
            "gdId": "15",
            "dateTime": "01/20/2027 21:00:00",
            "htId": 50149,
            "htName": "Sporting CP",
            "htCCode": "SPO",
            "htPtName": "Pot 2",
            "atId": 50080,
            "atName": "Barcelona",
            "atCCode": "BAR",
            "atPtName": "Pot 1",
            "stadiumName": "Estádio José Alvalade",
            "venueName": "Lisbon"
          },
          {
            "mId": 2049672,
            "gdId": "15",
            "dateTime": "01/20/2027 21:00:00",
            "htId": 52265,
            "htName": "Real Betis",
            "htCCode": "BET",
            "htPtName": "Pot 2",
            "atId": 52280,
            "atName": "Arsenal",
            "atCCode": "ARS",
            "atPtName": "Pot 1",
            "stadiumName": "LA CARTUJA DE SEVILLA",
            "venueName": "Seville"
          }
        ]
      },
      {
        "mdId": 8,
        "phId": 1,
        "gdIsLocked": 0,
        "gdIsCurrent": 0,
        "subsAllowed": 2,
        "maxSubsCf": 1,
        "deadline": "01/27/27 09:00:00 PM",
        "gameday": 0,
        "gamedayNew": 1,
        "roundId": 2002239,
        "round": "",
        "mdIsLocked": 0,
        "mdIsCurrent": 0,
        "isActNewUser": 0,
        "showLeaderboards": 0,
        "leagueIndent": 0,
        "match": [
          {
            "mId": 2049694,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 52498,
            "htName": "Slavia Praha",
            "htCCode": "SLA",
            "htPtName": "Pot 4",
            "atId": 52683,
            "atName": "Aston Villa",
            "atCCode": "AVL",
            "atPtName": "Pot 2",
            "stadiumName": "Eden Arena",
            "venueName": "Prague"
          },
          {
            "mId": 2049696,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 63405,
            "htName": "LASK",
            "htCCode": "LASK",
            "htPtName": "Pot 4",
            "atId": 50064,
            "atName": "Porto",
            "atCCode": "POR",
            "atPtName": "Pot 2",
            "stadiumName": "Oberösterreich Arena",
            "venueName": "Linz"
          },
          {
            "mId": 2049680,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 50037,
            "htName": "Bayern München",
            "htCCode": "BAY",
            "htPtName": "Pot 1",
            "atId": 52265,
            "atName": "Real Betis",
            "atCCode": "BET",
            "atPtName": "Pot 2",
            "stadiumName": "Fußball Arena München",
            "venueName": "Munich"
          },
          {
            "mId": 2049679,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 52747,
            "htName": "Paris",
            "htCCode": "PSG",
            "htPtName": "Pot 1",
            "atId": 50067,
            "atName": "Galatasaray",
            "atCCode": "GAL",
            "atPtName": "Pot 3",
            "stadiumName": "Parc des Princes",
            "venueName": "Paris"
          },
          {
            "mId": 2049695,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 52797,
            "htName": "S. Bratislava",
            "htCCode": "SBR",
            "htPtName": "Pot 4",
            "atId": 50138,
            "atName": "Inter",
            "atCCode": "INT",
            "atPtName": "Pot 1",
            "stadiumName": "Národný futbalový štadión ",
            "venueName": "Bratislava"
          },
          {
            "mId": 2049681,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 7889,
            "htName": "Liverpool",
            "htCCode": "LIV",
            "htPtName": "Pot 1",
            "atId": 52277,
            "atName": "Lens",
            "atCCode": "LEN",
            "atPtName": "Pot 4",
            "stadiumName": "Anfield",
            "venueName": "Liverpool"
          },
          {
            "mId": 2049682,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 52919,
            "htName": "Man City",
            "htCCode": "MCI",
            "htPtName": "Pot 1",
            "atId": 50149,
            "atName": "Sporting CP",
            "atCCode": "SPO",
            "atPtName": "Pot 2",
            "stadiumName": "City of Manchester Stadium",
            "venueName": "Manchester"
          },
          {
            "mId": 2049683,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 52280,
            "htName": "Arsenal",
            "htCCode": "ARS",
            "htPtName": "Pot 1",
            "atId": 2609356,
            "atName": "Sabah",
            "atCCode": "SAB",
            "atPtName": "Pot 4",
            "stadiumName": "Arsenal Stadium",
            "venueName": "London"
          },
          {
            "mId": 2049684,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 50080,
            "htName": "Barcelona",
            "htCCode": "BAR",
            "htPtName": "Pot 1",
            "atId": 79946,
            "atName": "Como",
            "atCCode": "COM",
            "atPtName": "Pot 4",
            "stadiumName": "Camp Nou",
            "venueName": "Barcelona"
          },
          {
            "mId": 2049685,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 50124,
            "htName": "Atleti",
            "htCCode": "ATM",
            "htPtName": "Pot 1",
            "atId": 52692,
            "atName": "Fenerbahçe",
            "atCCode": "FEN",
            "atPtName": "Pot 3",
            "stadiumName": "Estadio Metropolitano",
            "venueName": "Madrid"
          },
          {
            "mId": 2049686,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 52758,
            "htName": "B. Dortmund",
            "htCCode": "BVB",
            "htPtName": "Pot 2",
            "atId": 50129,
            "atName": "AEK Athens",
            "atCCode": "AEK",
            "atPtName": "Pot 4",
            "stadiumName": "BVB Stadion Dortmund",
            "venueName": "Dortmund"
          },
          {
            "mId": 2049687,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 50137,
            "htName": "Roma",
            "htCCode": "ROM",
            "htPtName": "Pot 2",
            "atId": 75797,
            "atName": "Lille",
            "atCCode": "LIL",
            "atPtName": "Pot 3",
            "stadiumName": "Stadio Olimpico",
            "venueName": "Rome"
          },
          {
            "mId": 2049688,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 50043,
            "htName": "Club Brugge",
            "htCCode": "BRU",
            "htPtName": "Pot 2",
            "atId": 59333,
            "atName": "Bodø/Glimt",
            "atCCode": "BOD",
            "atPtName": "Pot 3",
            "stadiumName": "Jan Breydelstadion",
            "venueName": "Bruges"
          },
          {
            "mId": 2049689,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 50062,
            "htName": "PSV",
            "htCCode": "PSV",
            "htPtName": "Pot 2",
            "atId": 50107,
            "atName": "Stuttgart",
            "atCCode": "STU",
            "atPtName": "Pot 4",
            "stadiumName": "PSV Stadion",
            "venueName": "Eindhoven"
          },
          {
            "mId": 2049690,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 52749,
            "htName": "Feyenoord",
            "htCCode": "FEY",
            "htPtName": "Pot 3",
            "atId": 2603790,
            "atName": "Leipzig",
            "atCCode": "RBL",
            "atPtName": "Pot 3",
            "stadiumName": "Stadion Feijenoord 'De Kuip'",
            "venueName": "Rotterdam"
          },
          {
            "mId": 2049691,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 50136,
            "htName": "Napoli",
            "htCCode": "NAP",
            "htPtName": "Pot 3",
            "atId": 52319,
            "atName": "Viking",
            "atCCode": "VFK",
            "atPtName": "Pot 4",
            "stadiumName": "Stadio Diego Armando Maradona",
            "venueName": "Naples"
          },
          {
            "mId": 2049692,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 70691,
            "htName": "Villarreal",
            "htCCode": "VIL",
            "htPtName": "Pot 3",
            "atId": 52682,
            "atName": "Man Utd",
            "atCCode": "MUN",
            "atPtName": "Pot 2",
            "stadiumName": "Estadio de la Cerámica",
            "venueName": "Villarreal"
          },
          {
            "mId": 2049693,
            "gdId": "16",
            "dateTime": "01/27/2027 21:00:00",
            "htId": 52707,
            "htName": "Shakhtar",
            "htCCode": "SHK",
            "htPtName": "Pot 3",
            "atId": 50051,
            "atName": "Real Madrid",
            "atCCode": "RMA",
            "atPtName": "Pot 1",
            "stadiumName": "Stamford Bridge",
            "venueName": "London"
          }
        ]
      }
    ],
    "feedTime": {
      "utcTime": "9/7/2026 5:11:53 PM",
      "istTime": "9/7/2026 10:41:53 PM",
      "cestTime": "9/7/2026 7:11:53 PM"
    }
  },
  "meta": {
    "message": "cl_fant_match_day_fixture_get",
    "retVal": 1,
    "success": true,
    "timestamp": {
      "utcTime": "9/7/2026 5:11:53 PM",
      "istTime": "9/7/2026 10:41:53 PM",
      "cestTime": "9/7/2026 7:11:53 PM"
    }
  }
}
`,im={Sun:"周日",Mon:"周一",Tue:"周二",Wed:"周三",Thu:"周四",Fri:"周五",Sat:"周六"};function _o(n){return n>=1&&n<=20?String.fromCodePoint(9311+n):`#${n}`}function zs(n){var t;return(t=["一","二","三","四","五","六","七","八","九","十"][n-1])!=null?t:String(n)}const bs=["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];function js(n,e,t){const a=u=>{const y=new Date(Date.UTC(n,u+1,0));return y.getUTCDate()-y.getUTCDay()},d=a(2),o=a(9),i=(e+1)*100+t,r=3*100+d,l=10*100+o;return i>=r&&i<l?2:1}function Ks(n){const[e,t]=n.split(" "),[a,d,o]=e.split("/").map(N=>parseInt(N,10)),[i,r]=t.split(":").map(N=>parseInt(N,10)),l=Date.UTC(o,a-1,d,i,r,0)-js(o,a-1,d)*3600*1e3,u=new Date(l+8*3600*1e3),y=N=>String(N).padStart(2,"0"),f=`${u.getUTCFullYear()}-${y(u.getUTCMonth()+1)}-${y(u.getUTCDate())}`,p=bs[u.getUTCDay()],g=`${y(u.getUTCHours())}:${y(u.getUTCMinutes())}`;return{dateKey:f,weekday:p,kickoffTime:g}}function rm(n,e,t){return{id:n,code:e,name:t}}const Us=JSON.parse(Fs);function Hs(n){const e=new Map;for(const d of n)for(const o of d.match)e.has(o.htCCode)||e.set(o.htCCode,{id:o.htId,code:o.htCCode,name:o.htName,pot:o.htPtName}),e.has(o.atCCode)||e.set(o.atCCode,{id:o.atId,code:o.atCCode,name:o.atName,pot:o.atPtName});const t=Array.from(e.values()).sort((d,o)=>d.code.localeCompare(o.code)),a={};for(const d of t)a[d.code]=d;return{teams:t,teamByCode:a}}function Ws(){const n=Us.data.value,e=n.map((l,u)=>{var m,c;const y=l.match.map(v=>{const{dateKey:S,weekday:T,kickoffTime:M}=Ks(v.dateTime);return{id:v.mId,matchday:u+1,gdId:parseInt(v.gdId,10),dateKey:S,weekday:T,kickoffTime:M,home:rm(v.htId,v.htCCode,v.htName),away:rm(v.atId,v.atCCode,v.atName),stadium:v.stadiumName,venue:v.venueName,extensions:[]}}).sort((v,S)=>(v.dateKey+v.kickoffTime).localeCompare(S.dateKey+S.kickoffTime)),f=Array.from(new Set(y.map(v=>v.dateKey))).sort(),p={};for(const v of y)p[v.dateKey]=v.weekday;const g=new Map;for(const v of y)g.has(v.gdId)||g.set(v.gdId,{dateKey:v.dateKey,weekday:v.weekday});const N=Array.from(g.entries()).map(([v,S])=>({gdId:v,dateKey:S.dateKey,weekday:S.weekday})).sort((v,S)=>v.dateKey.localeCompare(S.dateKey)).map((v,S)=>({...v,ordinal:S+1,label:`比赛日${zs(S+1)}`})),w=(m=f[0])!=null?m:"",D=(c=f[f.length-1])!=null?c:"",h=w===D?w.slice(5):`${w.slice(5)} ~ ${D.slice(5)}`;return{number:u+1,matches:y,dateKeys:f,weekdayByDate:p,dateRangeLabel:h,subDays:N}}),{teams:t,teamByCode:a}=Hs(n),d=new Date,o=l=>String(l).padStart(2,"0"),i=`${d.getFullYear()}-${o(d.getMonth()+1)}-${o(d.getDate())}`;let r=e.length;for(const l of e){const u=l.dateKeys[l.dateKeys.length-1];if(u&&u>=i){r=l.number;break}}return{teams:t,teamByCode:a,matchdays:e,currentMatchday:r}}function Gs({captainRoute:n,hasSelection:e,onToggleCaptainRoute:t,onClear:a}){return s.jsxs("header",{className:"header",children:[s.jsxs("div",{className:"brand",children:[s.jsx("div",{className:"brand__logo","aria-hidden":"true",children:s.jsxs("svg",{width:"32",height:"32",viewBox:"0 0 48 48",fill:"none",children:[s.jsxs("defs",{children:[s.jsxs("linearGradient",{id:"lg-gold",x1:"0",y1:"0",x2:"0",y2:"1",children:[s.jsx("stop",{offset:"0",stopColor:"#e9cb7e"}),s.jsx("stop",{offset:"1",stopColor:"#d4af37"})]}),s.jsxs("linearGradient",{id:"lg-ice",x1:"0",y1:"0",x2:"1",y2:"1",children:[s.jsx("stop",{offset:"0",stopColor:"#a5d8ff"}),s.jsx("stop",{offset:"1",stopColor:"#38bdf8"})]})]}),s.jsx("ellipse",{cx:"24",cy:"8.5",rx:"18",ry:"4.2",stroke:"#a5d8ff",strokeOpacity:"0.5",strokeWidth:"1"}),s.jsx("path",{d:"M16 15.5h16v4.5a8 8 0 0 1-16 0z",stroke:"url(#lg-gold)",strokeWidth:"1.8",strokeLinejoin:"round"}),s.jsx("path",{d:"M13.5 15.5h21",stroke:"url(#lg-gold)",strokeWidth:"1.8",strokeLinecap:"round"}),s.jsx("path",{d:"M15.5 17.5c-3.3 0-4.5 3.5-2.6 6.2",stroke:"url(#lg-ice)",strokeWidth:"1.5",strokeLinecap:"round"}),s.jsx("path",{d:"M32.5 17.5c3.3 0 4.5 3.5 2.6 6.2",stroke:"url(#lg-ice)",strokeWidth:"1.5",strokeLinecap:"round"}),s.jsx("path",{d:"M20 24.5h8l1.1 3.6h-10.2z",stroke:"url(#lg-gold)",strokeWidth:"1.8",strokeLinejoin:"round"}),s.jsx("path",{d:"M17.5 29.5h13",stroke:"url(#lg-gold)",strokeWidth:"1.8",strokeLinecap:"round"})]})}),s.jsxs("div",{children:[s.jsx("div",{className:"brand__title",children:"紫葱酱 · 欧冠 Fantasy 赛程规划器"}),s.jsx("div",{className:"brand__sub",children:"UCL FIXTURE PLANNER"})]})]}),s.jsxs("div",{className:"header__actions",children:[s.jsxs("button",{className:`toggle ${n?"toggle--on":""}`,onClick:t,"aria-pressed":n,title:"开启后叠加队长路线浮层与开球先后序号，不改变矩阵结构",children:[s.jsx("span",{className:"toggle__dot"}),"队长路线"]}),s.jsx("button",{className:"btn-ghost",onClick:a,disabled:!e,children:"清空"})]})]})}function lm(n){const e=n.match(/(\d+)/);return e?parseInt(e[1],10):0}function $s({teams:n,selectedCodes:e,maxTeams:t,onToggle:a}){const[d,o]=U.useState(""),i=U.useMemo(()=>{const y=d.trim().toLowerCase();return y?n.filter(f=>f.code.toLowerCase().includes(y)||f.name.toLowerCase().includes(y)):n},[d,n]),r=U.useMemo(()=>{var f;const y=new Map;for(const p of i){const g=(f=y.get(p.pot))!=null?f:[];g.push(p),y.set(p.pot,g)}return Array.from(y.entries()).sort((p,g)=>lm(p[0])-lm(g[0])).map(([p,g])=>[p,[...g].sort((N,w)=>N.code.localeCompare(w.code))])},[i]),l=e.length>=t,u=y=>!e.includes(y)&&l;return s.jsxs("div",{className:"selector",children:[s.jsxs("div",{className:"selector__head",children:[s.jsx("span",{className:"selector__title",children:"球队选择"}),s.jsxs("span",{className:"selector__count",children:[e.length,"/",t]})]}),s.jsx("input",{className:"search__input selector__search",placeholder:"搜索球队 / 缩写，如 ARS",value:d,onChange:y=>o(y.target.value),"aria-label":"搜索球队"}),s.jsx("div",{className:"selector__list",children:i.length===0?s.jsx("div",{className:"search__empty",children:"未找到匹配球队"}):r.map(([y,f])=>s.jsxs("div",{className:"selector__group",children:[s.jsx("div",{className:"selector__group-title",children:y}),f.map(p=>{const g=e.includes(p.code);return s.jsxs("label",{className:`selector__item ${g?"selector__item--checked":""}`,children:[s.jsx("input",{type:"checkbox",checked:g,disabled:u(p.code),onChange:()=>a(p.code)}),s.jsx("span",{className:"selector__code",children:p.code}),s.jsx("span",{className:"selector__name",children:p.name})]},p.code)})]},y))})]})}function Ys(){return s.jsxs("div",{className:"legend",children:[s.jsxs("span",{className:"legend__item",children:[s.jsx("span",{className:"legend__swatch legend__swatch--home"}),"主场 (H)"]}),s.jsxs("span",{className:"legend__item",children:[s.jsx("span",{className:"legend__swatch legend__swatch--away"}),"客场 (A)"]}),s.jsxs("span",{className:"legend__item",children:[s.jsx("span",{className:"legend__swatch legend__swatch--conflict"}),"同刻撞车"]}),s.jsxs("span",{className:"legend__item",children:[s.jsx("span",{className:"legend__swatch legend__swatch--route"}),"队长路线序号"]})]})}function mm(n,e){const t=new Set(e.map(r=>r.code)),a=new Map;for(const r of n.matches){const l=t.has(r.home.code),u=t.has(r.away.code);if(!l&&!u)continue;const y=r.dateKey+"|"+r.kickoffTime;let f=a.get(y);f||(f={dateKey:r.dateKey,weekday:r.weekday,gdId:r.gdId,kickoffTime:r.kickoffTime,teams:[]},a.set(y,f)),l&&f.teams.push({code:r.home.code,isHome:!0,opp:r.away.code}),u&&f.teams.push({code:r.away.code,isHome:!1,opp:r.home.code})}const o=Array.from(a.keys()).sort().map((r,l)=>{const u=a.get(r);return{key:r,...u,no:l+1,conflict:u.teams.length>=2}}),i=o.map(r=>r.teams.length===1?r.teams[0].code:`(${r.teams.map(l=>l.code).join("|")})`);return{slots:o,chain:i}}function Qs({match:n,isHome:e,conflict:t,badge:a,onHover:d}){const o=e?n.away:n.home,i=`cell ${e?"cell--home":"cell--away"} ${t?"cell--conflict":""}`;return s.jsxs("span",{className:i,onMouseEnter:r=>d({match:n,isHome:e,x:r.clientX,y:r.clientY}),onMouseLeave:()=>d(null),children:[a&&s.jsx("span",{className:"cell__badge",children:a}),s.jsxs("span",{className:"cell__main",children:[o.code,s.jsxs("span",{className:"cell__ha",children:["(",e?"H":"A",")"]})]}),s.jsx("span",{className:"cell__time",children:n.kickoffTime}),n.extensions.length>0&&s.jsx("span",{className:"cell__ext",children:n.extensions.map(r=>s.jsx("span",{className:`cell__chip cell__chip--${r.tone}`,children:r.label},r.key))})]})}function Js({matchdays:n,selectedTeams:e,captainRoute:t}){var f;const[a,d]=U.useState(null),o=new Set(e.map(p=>p.code)),i=new Map;for(const p of n)for(const g of p.matches)o.has(g.home.code)&&i.set(`${g.home.code}|${p.number}`,{match:g,isHome:!0}),o.has(g.away.code)&&i.set(`${g.away.code}|${p.number}`,{match:g,isHome:!1});const r=p=>{var w;const g=n.find(D=>D.number===p.matchday),N=g==null?void 0:g.subDays.find(D=>D.gdId===p.gdId);return(w=N==null?void 0:N.label)!=null?w:""},l=new Map;for(const p of n){const g=mm(p,e),N=new Map;for(const w of g.slots)N.set(w.key,{no:w.no,conflict:w.conflict});l.set(p.number,N)}const u=a?Math.min(a.x+14,window.innerWidth-260):0,y=a?Math.min(a.y+14,window.innerHeight-200):0;return s.jsxs("div",{className:"matrix",children:[s.jsxs("table",{className:"matrix__table",children:[s.jsxs("thead",{children:[s.jsxs("tr",{children:[s.jsxs("th",{rowSpan:2,className:"matrix__th matrix__th--corner",children:["球队",s.jsx("span",{className:"matrix__th-sub",children:"已选"})]}),n.map(p=>s.jsxs("th",{colSpan:p.subDays.length,className:"matrix__th matrix__th--md",children:["Match Day ",p.number]},p.number))]}),s.jsx("tr",{children:n.map(p=>p.subDays.map(g=>s.jsxs("th",{className:"matrix__th matrix__th--date",title:`${g.label} · ${g.dateKey}（北京时间）`,children:[g.label,s.jsx("span",{className:"matrix__th-sub",children:g.dateKey.slice(5)})]},`${p.number}-${g.gdId}`)))})]}),s.jsx("tbody",{children:e.map(p=>s.jsxs("tr",{children:[s.jsx("th",{className:"matrix__td-team",title:p.name,children:p.code}),n.map(g=>g.subDays.map(N=>{var c;const w=i.get(`${p.code}|${g.number}`);if(!w||w.match.gdId!==N.gdId)return s.jsx("td",{children:s.jsx("span",{className:"cell cell--empty"})},`${g.number}-${N.gdId}`);const h=l.get(g.number).get(w.match.dateKey+"|"+w.match.kickoffTime),m=t&&h?_o(h.no):"";return s.jsx("td",{children:s.jsx(Qs,{match:w.match,isHome:w.isHome,conflict:(c=h==null?void 0:h.conflict)!=null?c:!1,badge:m,onHover:d})},`${g.number}-${N.gdId}`)}))]},p.code))})]}),a&&am.createPortal(s.jsxs("div",{className:"tooltip",style:{left:u,top:y},children:[s.jsxs("div",{className:"tooltip__title",children:[a.isHome?a.match.home.name:a.match.away.name," vs"," ",a.isHome?a.match.away.name:a.match.home.name]}),s.jsxs("div",{className:"tooltip__row",children:[s.jsx("span",{className:"tooltip__label",children:"Matchday"}),s.jsx("span",{children:a.match.matchday})]}),s.jsxs("div",{className:"tooltip__row",children:[s.jsx("span",{className:"tooltip__label",children:"比赛日"}),s.jsx("span",{children:r(a.match)})]}),s.jsxs("div",{className:"tooltip__row",children:[s.jsx("span",{className:"tooltip__label",children:"日期"}),s.jsxs("span",{children:[a.match.dateKey,"（",(f=im[a.match.weekday])!=null?f:a.match.weekday,"）"]})]}),s.jsxs("div",{className:"tooltip__row",children:[s.jsx("span",{className:"tooltip__label",children:"开球"}),s.jsxs("span",{children:[a.match.kickoffTime,"（北京时间）"]})]}),s.jsxs("div",{className:"tooltip__row",children:[s.jsx("span",{className:"tooltip__label",children:"身份"}),s.jsx("span",{className:a.isHome?"tooltip__home":"tooltip__away",children:a.isHome?"Home 主场":"Away 客场"})]})]}),document.body)]})}function Xs({start:n,end:e,total:t,onChange:a}){const d=Array.from({length:t},(r,l)=>l+1),o=r=>{r>e?a(e,r):a(r,e)},i=r=>{r<n?a(r,n):a(n,r)};return s.jsxs("div",{className:"range",role:"group","aria-label":"比赛日范围",children:[s.jsx("span",{className:"range__label",children:"比赛日范围"}),s.jsx("select",{className:"range__select",value:n,onChange:r=>o(Number(r.target.value)),"aria-label":"起始 Matchday",children:d.map(r=>s.jsxs("option",{value:r,children:["MD",r]},r))}),s.jsx("span",{className:"range__arrow",children:"→"}),s.jsx("select",{className:"range__select",value:e,onChange:r=>i(Number(r.target.value)),"aria-label":"结束 Matchday",children:d.map(r=>s.jsxs("option",{value:r,children:["MD",r]},r))}),s.jsxs("span",{className:"range__hint",children:["共 ",t," 轮"]})]})}function Zs({matchdays:n,selectedTeams:e,onClose:t}){const a=e.length>0;return s.jsxs("div",{className:"overlay",role:"dialog","aria-label":"队长路线",children:[s.jsxs("div",{className:"overlay__head",children:[s.jsxs("div",{children:[s.jsx("span",{className:"overlay__title",children:"队长路线"}),s.jsx("span",{className:"overlay__subtitle",children:"比赛日顺序分析"})]}),s.jsx("button",{className:"overlay__close",onClick:t,"aria-label":"关闭",children:"×"})]}),a?s.jsx("div",{className:"overlay__body",children:n.map(d=>{var r;const o=mm(d,e);if(o.slots.length===0)return null;const i=new Map;for(const l of o.slots){const u=(r=i.get(l.gdId))!=null?r:[];u.push(l),i.set(l.gdId,u)}return s.jsxs("div",{className:"overlay__md",children:[s.jsxs("div",{className:"overlay__md-title",children:["Matchday ",d.number]}),d.subDays.map(l=>{var y;const u=i.get(l.gdId);return!u||u.length===0?null:s.jsxs("div",{className:"overlay__route",children:[s.jsxs("div",{className:"overlay__route-title",children:["Route ",l.ordinal," · ",l.label,s.jsxs("span",{className:"overlay__route-date",children:[l.dateKey.slice(5)," ",(y=im[l.weekday])!=null?y:l.weekday]})]}),u.map(f=>s.jsxs("div",{className:"overlay__slot",children:[s.jsx("span",{className:"overlay__no",children:_o(f.no)}),s.jsx("span",{className:"overlay__meta",children:f.kickoffTime}),s.jsxs("span",{className:"overlay__teams",children:[f.teams.map(p=>`${p.code} ${p.isHome?"主":"客"}${p.opp}`).join(" / "),f.conflict&&s.jsx("span",{className:"overlay__warn",children:" ⚠"})]})]},f.key))]},l.gdId)}),s.jsx("div",{className:"overlay__chain",children:o.chain.join(" → ")})]},d.number)})}):s.jsx("div",{className:"overlay__empty",children:"请先选择球队"}),s.jsx("div",{className:"overlay__foot",children:"序号 = 北京开球先后 · 同序号 = 撞车，不可互切"})]})}const p0=JSON.parse(`{
  "meta": {
    "generatedAt": "2026-09-08T12:39:41+08:00",
    "sourceFile": "fixtures_90_en.json",
    "outputFile": "src/data/fixtures_normalized.json",
    "timezone": "Asia/Shanghai",
    "timezoneOffset": "+08:00",
    "season": "2026/2027",
    "stats": {
      "matches": 144,
      "teams": 36,
      "matchdays": 8,
      "days": 16
    }
  },
  "matchdays": [
    {
      "id": 1,
      "name": "Matchday 1",
      "dateRange": "09-09 ~ 09-11",
      "days": [
        {
          "day": 1,
          "name": "比赛日一",
          "date": "2026-09-09",
          "gdId": 1,
          "matches": [
            {
              "id": 2049558,
              "matchday": 1,
              "gdId": 1,
              "date": "2026-09-09",
              "weekday": "Wed",
              "time": "00:45",
              "datetime": "2026-09-09T00:45:00+08:00",
              "home": {
                "id": 50129,
                "code": "AEK",
                "name": "AEK Athens"
              },
              "away": {
                "id": 63405,
                "code": "LASK",
                "name": "LASK"
              },
              "stadium": "AEK Arena",
              "venue": "Athens"
            },
            {
              "id": 2049556,
              "matchday": 1,
              "gdId": 1,
              "date": "2026-09-09",
              "weekday": "Wed",
              "time": "00:45",
              "datetime": "2026-09-09T00:45:00+08:00",
              "home": {
                "id": 50043,
                "code": "BRU",
                "name": "Club Brugge"
              },
              "away": {
                "id": 52683,
                "code": "AVL",
                "name": "Aston Villa"
              },
              "stadium": "Jan Breydelstadion",
              "venue": "Bruges"
            },
            {
              "id": 2049553,
              "matchday": 1,
              "gdId": 1,
              "date": "2026-09-09",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-09-09T03:00:00+08:00",
              "home": {
                "id": 50051,
                "code": "RMA",
                "name": "Real Madrid"
              },
              "away": {
                "id": 50138,
                "code": "INT",
                "name": "Inter"
              },
              "stadium": "Estadio Santiago Bernabéu",
              "venue": "Madrid"
            },
            {
              "id": 2049555,
              "matchday": 1,
              "gdId": 1,
              "date": "2026-09-09",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-09-09T03:00:00+08:00",
              "home": {
                "id": 50064,
                "code": "POR",
                "name": "Porto"
              },
              "away": {
                "id": 52919,
                "code": "MCI",
                "name": "Man City"
              },
              "stadium": "Estádio do Dragão",
              "venue": "Porto"
            },
            {
              "id": 2049557,
              "matchday": 1,
              "gdId": 1,
              "date": "2026-09-09",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-09-09T03:00:00+08:00",
              "home": {
                "id": 75797,
                "code": "LIL",
                "name": "Lille"
              },
              "away": {
                "id": 52265,
                "code": "BET",
                "name": "Real Betis"
              },
              "stadium": "Stade Pierre Mauroy",
              "venue": "Villeneuve d'Ascq"
            },
            {
              "id": 2049554,
              "matchday": 1,
              "gdId": 1,
              "date": "2026-09-09",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-09-09T03:00:00+08:00",
              "home": {
                "id": 52758,
                "code": "BVB",
                "name": "B. Dortmund"
              },
              "away": {
                "id": 70691,
                "code": "VIL",
                "name": "Villarreal"
              },
              "stadium": "BVB Stadion Dortmund",
              "venue": "Dortmund"
            }
          ]
        },
        {
          "day": 2,
          "name": "比赛日二",
          "date": "2026-09-10",
          "gdId": 2,
          "matches": [
            {
              "id": 2049564,
              "matchday": 1,
              "gdId": 2,
              "date": "2026-09-10",
              "weekday": "Thu",
              "time": "00:45",
              "datetime": "2026-09-10T00:45:00+08:00",
              "home": {
                "id": 50107,
                "code": "STU",
                "name": "Stuttgart"
              },
              "away": {
                "id": 52319,
                "code": "VFK",
                "name": "Viking"
              },
              "stadium": "Arena Stuttgart",
              "venue": "Stuttgart"
            },
            {
              "id": 2049561,
              "matchday": 1,
              "gdId": 2,
              "date": "2026-09-10",
              "weekday": "Thu",
              "time": "00:45",
              "datetime": "2026-09-10T00:45:00+08:00",
              "home": {
                "id": 50080,
                "code": "BAR",
                "name": "Barcelona"
              },
              "away": {
                "id": 52749,
                "code": "FEY",
                "name": "Feyenoord"
              },
              "stadium": "Camp Nou",
              "venue": "Barcelona"
            },
            {
              "id": 2049562,
              "matchday": 1,
              "gdId": 2,
              "date": "2026-09-10",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-09-10T03:00:00+08:00",
              "home": {
                "id": 50149,
                "code": "SPO",
                "name": "Sporting CP"
              },
              "away": {
                "id": 50067,
                "code": "GAL",
                "name": "Galatasaray"
              },
              "stadium": "Estádio José Alvalade",
              "venue": "Lisbon"
            },
            {
              "id": 2049563,
              "matchday": 1,
              "gdId": 2,
              "date": "2026-09-10",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-09-10T03:00:00+08:00",
              "home": {
                "id": 50136,
                "code": "NAP",
                "name": "Napoli"
              },
              "away": {
                "id": 52280,
                "code": "ARS",
                "name": "Arsenal"
              },
              "stadium": "Stadio Diego Armando Maradona",
              "venue": "Naples"
            },
            {
              "id": 2049560,
              "matchday": 1,
              "gdId": 2,
              "date": "2026-09-10",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-09-10T03:00:00+08:00",
              "home": {
                "id": 7889,
                "code": "LIV",
                "name": "Liverpool"
              },
              "away": {
                "id": 50124,
                "code": "ATM",
                "name": "Atleti"
              },
              "stadium": "Anfield",
              "venue": "Liverpool"
            },
            {
              "id": 2049559,
              "matchday": 1,
              "gdId": 2,
              "date": "2026-09-10",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-09-10T03:00:00+08:00",
              "home": {
                "id": 52747,
                "code": "PSG",
                "name": "Paris"
              },
              "away": {
                "id": 52797,
                "code": "SBR",
                "name": "S. Bratislava"
              },
              "stadium": "Parc des Princes",
              "venue": "Paris"
            }
          ]
        },
        {
          "day": 3,
          "name": "比赛日三",
          "date": "2026-09-11",
          "gdId": 3,
          "matches": [
            {
              "id": 2049567,
              "matchday": 1,
              "gdId": 3,
              "date": "2026-09-11",
              "weekday": "Fri",
              "time": "00:45",
              "datetime": "2026-09-11T00:45:00+08:00",
              "home": {
                "id": 50062,
                "code": "PSV",
                "name": "PSV"
              },
              "away": {
                "id": 52707,
                "code": "SHK",
                "name": "Shakhtar"
              },
              "stadium": "PSV Stadion",
              "venue": "Eindhoven"
            },
            {
              "id": 2049568,
              "matchday": 1,
              "gdId": 3,
              "date": "2026-09-11",
              "weekday": "Fri",
              "time": "00:45",
              "datetime": "2026-09-11T00:45:00+08:00",
              "home": {
                "id": 52692,
                "code": "FEN",
                "name": "Fenerbahçe"
              },
              "away": {
                "id": 50137,
                "code": "ROM",
                "name": "Roma"
              },
              "stadium": "Fenerbahçe Şükrü Saracoğlu Spor Kompleksi",
              "venue": "Istanbul"
            },
            {
              "id": 2049570,
              "matchday": 1,
              "gdId": 3,
              "date": "2026-09-11",
              "weekday": "Fri",
              "time": "03:00",
              "datetime": "2026-09-11T03:00:00+08:00",
              "home": {
                "id": 79946,
                "code": "COM",
                "name": "Como"
              },
              "away": {
                "id": 2603790,
                "code": "RBL",
                "name": "Leipzig"
              },
              "stadium": "Giuseppe Sinigaglia",
              "venue": "Como"
            },
            {
              "id": 2049566,
              "matchday": 1,
              "gdId": 3,
              "date": "2026-09-11",
              "weekday": "Fri",
              "time": "03:00",
              "datetime": "2026-09-11T03:00:00+08:00",
              "home": {
                "id": 52682,
                "code": "MUN",
                "name": "Man Utd"
              },
              "away": {
                "id": 2609356,
                "code": "SAB",
                "name": "Sabah"
              },
              "stadium": "Old Trafford",
              "venue": "Manchester"
            },
            {
              "id": 2049569,
              "matchday": 1,
              "gdId": 3,
              "date": "2026-09-11",
              "weekday": "Fri",
              "time": "03:00",
              "datetime": "2026-09-11T03:00:00+08:00",
              "home": {
                "id": 52498,
                "code": "SLA",
                "name": "Slavia Praha"
              },
              "away": {
                "id": 52277,
                "code": "LEN",
                "name": "Lens"
              },
              "stadium": "Eden Arena",
              "venue": "Prague"
            },
            {
              "id": 2049565,
              "matchday": 1,
              "gdId": 3,
              "date": "2026-09-11",
              "weekday": "Fri",
              "time": "03:00",
              "datetime": "2026-09-11T03:00:00+08:00",
              "home": {
                "id": 50037,
                "code": "BAY",
                "name": "Bayern München"
              },
              "away": {
                "id": 59333,
                "code": "BOD",
                "name": "Bodø/Glimt"
              },
              "stadium": "Fußball Arena München",
              "venue": "Munich"
            }
          ]
        }
      ]
    },
    {
      "id": 2,
      "name": "Matchday 2",
      "dateRange": "10-14 ~ 10-15",
      "days": [
        {
          "day": 1,
          "name": "比赛日一",
          "date": "2026-10-14",
          "gdId": 4,
          "matches": [
            {
              "id": 2049579,
              "matchday": 2,
              "gdId": 4,
              "date": "2026-10-14",
              "weekday": "Wed",
              "time": "00:45",
              "datetime": "2026-10-14T00:45:00+08:00",
              "home": {
                "id": 2609356,
                "code": "SAB",
                "name": "Sabah"
              },
              "away": {
                "id": 52498,
                "code": "SLA",
                "name": "Slavia Praha"
              },
              "stadium": "",
              "venue": ""
            },
            {
              "id": 2049577,
              "matchday": 2,
              "gdId": 4,
              "date": "2026-10-14",
              "weekday": "Wed",
              "time": "00:45",
              "datetime": "2026-10-14T00:45:00+08:00",
              "home": {
                "id": 52277,
                "code": "LEN",
                "name": "Lens"
              },
              "away": {
                "id": 50149,
                "code": "SPO",
                "name": "Sporting CP"
              },
              "stadium": "Stade Bollaert-Delelis",
              "venue": "Lens Agglo"
            },
            {
              "id": 2049576,
              "matchday": 2,
              "gdId": 4,
              "date": "2026-10-14",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-14T03:00:00+08:00",
              "home": {
                "id": 50067,
                "code": "GAL",
                "name": "Galatasaray"
              },
              "away": {
                "id": 50080,
                "code": "BAR",
                "name": "Barcelona"
              },
              "stadium": "Ali Sami Yen Spor Kompleksi",
              "venue": "Istanbul"
            },
            {
              "id": 2049571,
              "matchday": 2,
              "gdId": 4,
              "date": "2026-10-14",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-14T03:00:00+08:00",
              "home": {
                "id": 50138,
                "code": "INT",
                "name": "Inter"
              },
              "away": {
                "id": 50043,
                "code": "BRU",
                "name": "Club Brugge"
              },
              "stadium": "Stadio San Siro",
              "venue": "Milan"
            },
            {
              "id": 2049572,
              "matchday": 2,
              "gdId": 4,
              "date": "2026-10-14",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-14T03:00:00+08:00",
              "home": {
                "id": 52280,
                "code": "ARS",
                "name": "Arsenal"
              },
              "away": {
                "id": 75797,
                "code": "LIL",
                "name": "Lille"
              },
              "stadium": "Arsenal Stadium",
              "venue": "London"
            },
            {
              "id": 2049573,
              "matchday": 2,
              "gdId": 4,
              "date": "2026-10-14",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-14T03:00:00+08:00",
              "home": {
                "id": 50124,
                "code": "ATM",
                "name": "Atleti"
              },
              "away": {
                "id": 52682,
                "code": "MUN",
                "name": "Man Utd"
              },
              "stadium": "Estadio Metropolitano",
              "venue": "Madrid"
            },
            {
              "id": 2049574,
              "matchday": 2,
              "gdId": 4,
              "date": "2026-10-14",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-14T03:00:00+08:00",
              "home": {
                "id": 2603790,
                "code": "RBL",
                "name": "Leipzig"
              },
              "away": {
                "id": 50062,
                "code": "PSV",
                "name": "PSV"
              },
              "stadium": "RB Arena",
              "venue": "Leipzig"
            },
            {
              "id": 2049575,
              "matchday": 2,
              "gdId": 4,
              "date": "2026-10-14",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-14T03:00:00+08:00",
              "home": {
                "id": 70691,
                "code": "VIL",
                "name": "Villarreal"
              },
              "away": {
                "id": 50136,
                "code": "NAP",
                "name": "Napoli"
              },
              "stadium": "Estadio de la Cerámica",
              "venue": "Villarreal"
            },
            {
              "id": 2049578,
              "matchday": 2,
              "gdId": 4,
              "date": "2026-10-14",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-14T03:00:00+08:00",
              "home": {
                "id": 52319,
                "code": "VFK",
                "name": "Viking"
              },
              "away": {
                "id": 50037,
                "code": "BAY",
                "name": "Bayern München"
              },
              "stadium": "Viking stadion",
              "venue": "Stavanger"
            }
          ]
        },
        {
          "day": 2,
          "name": "比赛日二",
          "date": "2026-10-15",
          "gdId": 5,
          "matches": [
            {
              "id": 2049584,
              "matchday": 2,
              "gdId": 5,
              "date": "2026-10-15",
              "weekday": "Thu",
              "time": "00:45",
              "datetime": "2026-10-15T00:45:00+08:00",
              "home": {
                "id": 52749,
                "code": "FEY",
                "name": "Feyenoord"
              },
              "away": {
                "id": 79946,
                "code": "COM",
                "name": "Como"
              },
              "stadium": "Stadion Feijenoord 'De Kuip'",
              "venue": "Rotterdam"
            },
            {
              "id": 2049588,
              "matchday": 2,
              "gdId": 5,
              "date": "2026-10-15",
              "weekday": "Thu",
              "time": "00:45",
              "datetime": "2026-10-15T00:45:00+08:00",
              "home": {
                "id": 63405,
                "code": "LASK",
                "name": "LASK"
              },
              "away": {
                "id": 7889,
                "code": "LIV",
                "name": "Liverpool"
              },
              "stadium": "Oberösterreich Arena",
              "venue": "Linz"
            },
            {
              "id": 2049581,
              "matchday": 2,
              "gdId": 5,
              "date": "2026-10-15",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-15T03:00:00+08:00",
              "home": {
                "id": 50137,
                "code": "ROM",
                "name": "Roma"
              },
              "away": {
                "id": 50051,
                "code": "RMA",
                "name": "Real Madrid"
              },
              "stadium": "Stadio Olimpico",
              "venue": "Rome"
            },
            {
              "id": 2049582,
              "matchday": 2,
              "gdId": 5,
              "date": "2026-10-15",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-15T03:00:00+08:00",
              "home": {
                "id": 52683,
                "code": "AVL",
                "name": "Aston Villa"
              },
              "away": {
                "id": 52692,
                "code": "FEN",
                "name": "Fenerbahçe"
              },
              "stadium": "Villa Park",
              "venue": "Birmingham"
            },
            {
              "id": 2049583,
              "matchday": 2,
              "gdId": 5,
              "date": "2026-10-15",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-15T03:00:00+08:00",
              "home": {
                "id": 52265,
                "code": "BET",
                "name": "Real Betis"
              },
              "away": {
                "id": 50064,
                "code": "POR",
                "name": "Porto"
              },
              "stadium": "LA CARTUJA DE SEVILLA",
              "venue": "Seville"
            },
            {
              "id": 2049585,
              "matchday": 2,
              "gdId": 5,
              "date": "2026-10-15",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-15T03:00:00+08:00",
              "home": {
                "id": 59333,
                "code": "BOD",
                "name": "Bodø/Glimt"
              },
              "away": {
                "id": 52758,
                "code": "BVB",
                "name": "B. Dortmund"
              },
              "stadium": "Aspmyra",
              "venue": "Bodø"
            },
            {
              "id": 2049587,
              "matchday": 2,
              "gdId": 5,
              "date": "2026-10-15",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-15T03:00:00+08:00",
              "home": {
                "id": 52797,
                "code": "SBR",
                "name": "S. Bratislava"
              },
              "away": {
                "id": 50107,
                "code": "STU",
                "name": "Stuttgart"
              },
              "stadium": "Národný futbalový štadión ",
              "venue": "Bratislava"
            },
            {
              "id": 2049586,
              "matchday": 2,
              "gdId": 5,
              "date": "2026-10-15",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-15T03:00:00+08:00",
              "home": {
                "id": 52707,
                "code": "SHK",
                "name": "Shakhtar"
              },
              "away": {
                "id": 50129,
                "code": "AEK",
                "name": "AEK Athens"
              },
              "stadium": "Stamford Bridge",
              "venue": "London"
            },
            {
              "id": 2049580,
              "matchday": 2,
              "gdId": 5,
              "date": "2026-10-15",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-15T03:00:00+08:00",
              "home": {
                "id": 52919,
                "code": "MCI",
                "name": "Man City"
              },
              "away": {
                "id": 52747,
                "code": "PSG",
                "name": "Paris"
              },
              "stadium": "City of Manchester Stadium",
              "venue": "Manchester"
            }
          ]
        }
      ]
    },
    {
      "id": 3,
      "name": "Matchday 3",
      "dateRange": "10-21 ~ 10-22",
      "days": [
        {
          "day": 1,
          "name": "比赛日一",
          "date": "2026-10-21",
          "gdId": 6,
          "matches": [
            {
              "id": 2049595,
              "matchday": 3,
              "gdId": 6,
              "date": "2026-10-21",
              "weekday": "Wed",
              "time": "00:45",
              "datetime": "2026-10-21T00:45:00+08:00",
              "home": {
                "id": 52692,
                "code": "FEN",
                "name": "Fenerbahçe"
              },
              "away": {
                "id": 52498,
                "code": "SLA",
                "name": "Slavia Praha"
              },
              "stadium": "Fenerbahçe Şükrü Saracoğlu Spor Kompleksi",
              "venue": "Istanbul"
            },
            {
              "id": 2049597,
              "matchday": 3,
              "gdId": 6,
              "date": "2026-10-21",
              "weekday": "Wed",
              "time": "00:45",
              "datetime": "2026-10-21T00:45:00+08:00",
              "home": {
                "id": 2609356,
                "code": "SAB",
                "name": "Sabah"
              },
              "away": {
                "id": 52758,
                "code": "BVB",
                "name": "B. Dortmund"
              },
              "stadium": "",
              "venue": ""
            },
            {
              "id": 2049596,
              "matchday": 3,
              "gdId": 6,
              "date": "2026-10-21",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-21T03:00:00+08:00",
              "home": {
                "id": 50107,
                "code": "STU",
                "name": "Stuttgart"
              },
              "away": {
                "id": 50124,
                "code": "ATM",
                "name": "Atleti"
              },
              "stadium": "Arena Stuttgart",
              "venue": "Stuttgart"
            },
            {
              "id": 2049589,
              "matchday": 3,
              "gdId": 6,
              "date": "2026-10-21",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-21T03:00:00+08:00",
              "home": {
                "id": 52747,
                "code": "PSG",
                "name": "Paris"
              },
              "away": {
                "id": 50080,
                "code": "BAR",
                "name": "Barcelona"
              },
              "stadium": "Parc des Princes",
              "venue": "Paris"
            },
            {
              "id": 2049590,
              "matchday": 3,
              "gdId": 6,
              "date": "2026-10-21",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-21T03:00:00+08:00",
              "home": {
                "id": 7889,
                "code": "LIV",
                "name": "Liverpool"
              },
              "away": {
                "id": 70691,
                "code": "VIL",
                "name": "Villarreal"
              },
              "stadium": "Anfield",
              "venue": "Liverpool"
            },
            {
              "id": 2049591,
              "matchday": 3,
              "gdId": 6,
              "date": "2026-10-21",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-21T03:00:00+08:00",
              "home": {
                "id": 52919,
                "code": "MCI",
                "name": "Man City"
              },
              "away": {
                "id": 50129,
                "code": "AEK",
                "name": "AEK Athens"
              },
              "stadium": "City of Manchester Stadium",
              "venue": "Manchester"
            },
            {
              "id": 2049592,
              "matchday": 3,
              "gdId": 6,
              "date": "2026-10-21",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-21T03:00:00+08:00",
              "home": {
                "id": 50137,
                "code": "ROM",
                "name": "Roma"
              },
              "away": {
                "id": 52797,
                "code": "SBR",
                "name": "S. Bratislava"
              },
              "stadium": "Stadio Olimpico",
              "venue": "Rome"
            },
            {
              "id": 2049593,
              "matchday": 3,
              "gdId": 6,
              "date": "2026-10-21",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-21T03:00:00+08:00",
              "home": {
                "id": 50064,
                "code": "POR",
                "name": "Porto"
              },
              "away": {
                "id": 50062,
                "code": "PSV",
                "name": "PSV"
              },
              "stadium": "Estádio do Dragão",
              "venue": "Porto"
            },
            {
              "id": 2049594,
              "matchday": 3,
              "gdId": 6,
              "date": "2026-10-21",
              "weekday": "Wed",
              "time": "03:00",
              "datetime": "2026-10-21T03:00:00+08:00",
              "home": {
                "id": 50136,
                "code": "NAP",
                "name": "Napoli"
              },
              "away": {
                "id": 59333,
                "code": "BOD",
                "name": "Bodø/Glimt"
              },
              "stadium": "Stadio Diego Armando Maradona",
              "venue": "Naples"
            }
          ]
        },
        {
          "day": 2,
          "name": "比赛日二",
          "date": "2026-10-22",
          "gdId": 7,
          "matches": [
            {
              "id": 2049605,
              "matchday": 3,
              "gdId": 7,
              "date": "2026-10-22",
              "weekday": "Thu",
              "time": "00:45",
              "datetime": "2026-10-22T00:45:00+08:00",
              "home": {
                "id": 75797,
                "code": "LIL",
                "name": "Lille"
              },
              "away": {
                "id": 50067,
                "code": "GAL",
                "name": "Galatasaray"
              },
              "stadium": "Stade Pierre Mauroy",
              "venue": "Villeneuve d'Ascq"
            },
            {
              "id": 2049606,
              "matchday": 3,
              "gdId": 7,
              "date": "2026-10-22",
              "weekday": "Thu",
              "time": "00:45",
              "datetime": "2026-10-22T00:45:00+08:00",
              "home": {
                "id": 79946,
                "code": "COM",
                "name": "Como"
              },
              "away": {
                "id": 52682,
                "code": "MUN",
                "name": "Man Utd"
              },
              "stadium": "Giuseppe Sinigaglia",
              "venue": "Como"
            },
            {
              "id": 2049603,
              "matchday": 3,
              "gdId": 7,
              "date": "2026-10-22",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-22T03:00:00+08:00",
              "home": {
                "id": 50043,
                "code": "BRU",
                "name": "Club Brugge"
              },
              "away": {
                "id": 52277,
                "code": "LEN",
                "name": "Lens"
              },
              "stadium": "Jan Breydelstadion",
              "venue": "Bruges"
            },
            {
              "id": 2049598,
              "matchday": 3,
              "gdId": 7,
              "date": "2026-10-22",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-22T03:00:00+08:00",
              "home": {
                "id": 50037,
                "code": "BAY",
                "name": "Bayern München"
              },
              "away": {
                "id": 52280,
                "code": "ARS",
                "name": "Arsenal"
              },
              "stadium": "Fußball Arena München",
              "venue": "Munich"
            },
            {
              "id": 2049599,
              "matchday": 3,
              "gdId": 7,
              "date": "2026-10-22",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-22T03:00:00+08:00",
              "home": {
                "id": 50051,
                "code": "RMA",
                "name": "Real Madrid"
              },
              "away": {
                "id": 2603790,
                "code": "RBL",
                "name": "Leipzig"
              },
              "stadium": "Estadio Santiago Bernabéu",
              "venue": "Madrid"
            },
            {
              "id": 2049600,
              "matchday": 3,
              "gdId": 7,
              "date": "2026-10-22",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-22T03:00:00+08:00",
              "home": {
                "id": 50138,
                "code": "INT",
                "name": "Inter"
              },
              "away": {
                "id": 52707,
                "code": "SHK",
                "name": "Shakhtar"
              },
              "stadium": "Stadio San Siro",
              "venue": "Milan"
            },
            {
              "id": 2049601,
              "matchday": 3,
              "gdId": 7,
              "date": "2026-10-22",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-22T03:00:00+08:00",
              "home": {
                "id": 50149,
                "code": "SPO",
                "name": "Sporting CP"
              },
              "away": {
                "id": 63405,
                "code": "LASK",
                "name": "LASK"
              },
              "stadium": "Estádio José Alvalade",
              "venue": "Lisbon"
            },
            {
              "id": 2049602,
              "matchday": 3,
              "gdId": 7,
              "date": "2026-10-22",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-22T03:00:00+08:00",
              "home": {
                "id": 52683,
                "code": "AVL",
                "name": "Aston Villa"
              },
              "away": {
                "id": 52319,
                "code": "VFK",
                "name": "Viking"
              },
              "stadium": "Villa Park",
              "venue": "Birmingham"
            },
            {
              "id": 2049604,
              "matchday": 3,
              "gdId": 7,
              "date": "2026-10-22",
              "weekday": "Thu",
              "time": "03:00",
              "datetime": "2026-10-22T03:00:00+08:00",
              "home": {
                "id": 52265,
                "code": "BET",
                "name": "Real Betis"
              },
              "away": {
                "id": 52749,
                "code": "FEY",
                "name": "Feyenoord"
              },
              "stadium": "LA CARTUJA DE SEVILLA",
              "venue": "Seville"
            }
          ]
        }
      ]
    },
    {
      "id": 4,
      "name": "Matchday 4",
      "dateRange": "11-04 ~ 11-05",
      "days": [
        {
          "day": 1,
          "name": "比赛日一",
          "date": "2026-11-04",
          "gdId": 8,
          "matches": [
            {
              "id": 2049613,
              "matchday": 4,
              "gdId": 8,
              "date": "2026-11-04",
              "weekday": "Wed",
              "time": "01:45",
              "datetime": "2026-11-04T01:45:00+08:00",
              "home": {
                "id": 52707,
                "code": "SHK",
                "name": "Shakhtar"
              },
              "away": {
                "id": 50149,
                "code": "SPO",
                "name": "Sporting CP"
              },
              "stadium": "Stamford Bridge",
              "venue": "London"
            },
            {
              "id": 2049614,
              "matchday": 4,
              "gdId": 8,
              "date": "2026-11-04",
              "weekday": "Wed",
              "time": "01:45",
              "datetime": "2026-11-04T01:45:00+08:00",
              "home": {
                "id": 50067,
                "code": "GAL",
                "name": "Galatasaray"
              },
              "away": {
                "id": 50107,
                "code": "STU",
                "name": "Stuttgart"
              },
              "stadium": "Ali Sami Yen Spor Kompleksi",
              "venue": "Istanbul"
            },
            {
              "id": 2049608,
              "matchday": 4,
              "gdId": 8,
              "date": "2026-11-04",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-04T04:00:00+08:00",
              "home": {
                "id": 50124,
                "code": "ATM",
                "name": "Atleti"
              },
              "away": {
                "id": 50037,
                "code": "BAY",
                "name": "Bayern München"
              },
              "stadium": "Estadio Metropolitano",
              "venue": "Madrid"
            },
            {
              "id": 2049612,
              "matchday": 4,
              "gdId": 8,
              "date": "2026-11-04",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-04T04:00:00+08:00",
              "home": {
                "id": 70691,
                "code": "VIL",
                "name": "Villarreal"
              },
              "away": {
                "id": 52747,
                "code": "PSG",
                "name": "Paris"
              },
              "stadium": "Estadio de la Cerámica",
              "venue": "Villarreal"
            },
            {
              "id": 2049607,
              "matchday": 4,
              "gdId": 8,
              "date": "2026-11-04",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-04T04:00:00+08:00",
              "home": {
                "id": 50080,
                "code": "BAR",
                "name": "Barcelona"
              },
              "away": {
                "id": 52683,
                "code": "AVL",
                "name": "Aston Villa"
              },
              "stadium": "Camp Nou",
              "venue": "Barcelona"
            },
            {
              "id": 2049609,
              "matchday": 4,
              "gdId": 8,
              "date": "2026-11-04",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-04T04:00:00+08:00",
              "home": {
                "id": 52682,
                "code": "MUN",
                "name": "Man Utd"
              },
              "away": {
                "id": 50137,
                "code": "ROM",
                "name": "Roma"
              },
              "stadium": "Old Trafford",
              "venue": "Manchester"
            },
            {
              "id": 2049610,
              "matchday": 4,
              "gdId": 8,
              "date": "2026-11-04",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-04T04:00:00+08:00",
              "home": {
                "id": 52749,
                "code": "FEY",
                "name": "Feyenoord"
              },
              "away": {
                "id": 50138,
                "code": "INT",
                "name": "Inter"
              },
              "stadium": "Stadion Feijenoord 'De Kuip'",
              "venue": "Rotterdam"
            },
            {
              "id": 2049611,
              "matchday": 4,
              "gdId": 8,
              "date": "2026-11-04",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-04T04:00:00+08:00",
              "home": {
                "id": 59333,
                "code": "BOD",
                "name": "Bodø/Glimt"
              },
              "away": {
                "id": 75797,
                "code": "LIL",
                "name": "Lille"
              },
              "stadium": "Aspmyra",
              "venue": "Bodø"
            },
            {
              "id": 2049615,
              "matchday": 4,
              "gdId": 8,
              "date": "2026-11-04",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-04T04:00:00+08:00",
              "home": {
                "id": 63405,
                "code": "LASK",
                "name": "LASK"
              },
              "away": {
                "id": 52797,
                "code": "SBR",
                "name": "S. Bratislava"
              },
              "stadium": "Oberösterreich Arena",
              "venue": "Linz"
            }
          ]
        },
        {
          "day": 2,
          "name": "比赛日二",
          "date": "2026-11-05",
          "gdId": 9,
          "matches": [
            {
              "id": 2049622,
              "matchday": 4,
              "gdId": 9,
              "date": "2026-11-05",
              "weekday": "Thu",
              "time": "01:45",
              "datetime": "2026-11-05T01:45:00+08:00",
              "home": {
                "id": 50129,
                "code": "AEK",
                "name": "AEK Athens"
              },
              "away": {
                "id": 50051,
                "code": "RMA",
                "name": "Real Madrid"
              },
              "stadium": "AEK Arena",
              "venue": "Athens"
            },
            {
              "id": 2049620,
              "matchday": 4,
              "gdId": 9,
              "date": "2026-11-05",
              "weekday": "Thu",
              "time": "01:45",
              "datetime": "2026-11-05T01:45:00+08:00",
              "home": {
                "id": 52692,
                "code": "FEN",
                "name": "Fenerbahçe"
              },
              "away": {
                "id": 7889,
                "code": "LIV",
                "name": "Liverpool"
              },
              "stadium": "Fenerbahçe Şükrü Saracoğlu Spor Kompleksi",
              "venue": "Istanbul"
            },
            {
              "id": 2049617,
              "matchday": 4,
              "gdId": 9,
              "date": "2026-11-05",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-05T04:00:00+08:00",
              "home": {
                "id": 50064,
                "code": "POR",
                "name": "Porto"
              },
              "away": {
                "id": 50136,
                "code": "NAP",
                "name": "Napoli"
              },
              "stadium": "Estádio do Dragão",
              "venue": "Porto"
            },
            {
              "id": 2049624,
              "matchday": 4,
              "gdId": 9,
              "date": "2026-11-05",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-05T04:00:00+08:00",
              "home": {
                "id": 52319,
                "code": "VFK",
                "name": "Viking"
              },
              "away": {
                "id": 2609356,
                "code": "SAB",
                "name": "Sabah"
              },
              "stadium": "Viking stadion",
              "venue": "Stavanger"
            },
            {
              "id": 2049619,
              "matchday": 4,
              "gdId": 9,
              "date": "2026-11-05",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-05T04:00:00+08:00",
              "home": {
                "id": 2603790,
                "code": "RBL",
                "name": "Leipzig"
              },
              "away": {
                "id": 52919,
                "code": "MCI",
                "name": "Man City"
              },
              "stadium": "RB Arena",
              "venue": "Leipzig"
            },
            {
              "id": 2049621,
              "matchday": 4,
              "gdId": 9,
              "date": "2026-11-05",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-05T04:00:00+08:00",
              "home": {
                "id": 52498,
                "code": "SLA",
                "name": "Slavia Praha"
              },
              "away": {
                "id": 52280,
                "code": "ARS",
                "name": "Arsenal"
              },
              "stadium": "Eden Arena",
              "venue": "Prague"
            },
            {
              "id": 2049623,
              "matchday": 4,
              "gdId": 9,
              "date": "2026-11-05",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-05T04:00:00+08:00",
              "home": {
                "id": 52277,
                "code": "LEN",
                "name": "Lens"
              },
              "away": {
                "id": 79946,
                "code": "COM",
                "name": "Como"
              },
              "stadium": "Stade Bollaert-Delelis",
              "venue": "Lens Agglo"
            },
            {
              "id": 2049618,
              "matchday": 4,
              "gdId": 9,
              "date": "2026-11-05",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-05T04:00:00+08:00",
              "home": {
                "id": 50062,
                "code": "PSV",
                "name": "PSV"
              },
              "away": {
                "id": 50043,
                "code": "BRU",
                "name": "Club Brugge"
              },
              "stadium": "PSV Stadion",
              "venue": "Eindhoven"
            },
            {
              "id": 2049616,
              "matchday": 4,
              "gdId": 9,
              "date": "2026-11-05",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-05T04:00:00+08:00",
              "home": {
                "id": 52758,
                "code": "BVB",
                "name": "B. Dortmund"
              },
              "away": {
                "id": 52265,
                "code": "BET",
                "name": "Real Betis"
              },
              "stadium": "BVB Stadion Dortmund",
              "venue": "Dortmund"
            }
          ]
        }
      ]
    },
    {
      "id": 5,
      "name": "Matchday 5",
      "dateRange": "11-25 ~ 11-26",
      "days": [
        {
          "day": 1,
          "name": "比赛日一",
          "date": "2026-11-25",
          "gdId": 10,
          "matches": [
            {
              "id": 2049629,
              "matchday": 5,
              "gdId": 10,
              "date": "2026-11-25",
              "weekday": "Wed",
              "time": "01:45",
              "datetime": "2026-11-25T01:45:00+08:00",
              "home": {
                "id": 59333,
                "code": "BOD",
                "name": "Bodø/Glimt"
              },
              "away": {
                "id": 63405,
                "code": "LASK",
                "name": "LASK"
              },
              "stadium": "Aspmyra",
              "venue": "Bodø"
            },
            {
              "id": 2049631,
              "matchday": 5,
              "gdId": 10,
              "date": "2026-11-25",
              "weekday": "Wed",
              "time": "01:45",
              "datetime": "2026-11-25T01:45:00+08:00",
              "home": {
                "id": 50067,
                "code": "GAL",
                "name": "Galatasaray"
              },
              "away": {
                "id": 52683,
                "code": "AVL",
                "name": "Aston Villa"
              },
              "stadium": "Ali Sami Yen Spor Kompleksi",
              "venue": "Istanbul"
            },
            {
              "id": 2049632,
              "matchday": 5,
              "gdId": 10,
              "date": "2026-11-25",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-25T04:00:00+08:00",
              "home": {
                "id": 52797,
                "code": "SBR",
                "name": "S. Bratislava"
              },
              "away": {
                "id": 52265,
                "code": "BET",
                "name": "Real Betis"
              },
              "stadium": "Národný futbalový štadión ",
              "venue": "Bratislava"
            },
            {
              "id": 2049627,
              "matchday": 5,
              "gdId": 10,
              "date": "2026-11-25",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-25T04:00:00+08:00",
              "home": {
                "id": 52280,
                "code": "ARS",
                "name": "Arsenal"
              },
              "away": {
                "id": 52758,
                "code": "BVB",
                "name": "B. Dortmund"
              },
              "stadium": "Arsenal Stadium",
              "venue": "London"
            },
            {
              "id": 2049630,
              "matchday": 5,
              "gdId": 10,
              "date": "2026-11-25",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-25T04:00:00+08:00",
              "home": {
                "id": 2603790,
                "code": "RBL",
                "name": "Leipzig"
              },
              "away": {
                "id": 52277,
                "code": "LEN",
                "name": "Lens"
              },
              "stadium": "RB Arena",
              "venue": "Leipzig"
            },
            {
              "id": 2049628,
              "matchday": 5,
              "gdId": 10,
              "date": "2026-11-25",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-25T04:00:00+08:00",
              "home": {
                "id": 52749,
                "code": "FEY",
                "name": "Feyenoord"
              },
              "away": {
                "id": 50064,
                "code": "POR",
                "name": "Porto"
              },
              "stadium": "Stadion Feijenoord 'De Kuip'",
              "venue": "Rotterdam"
            },
            {
              "id": 2049626,
              "matchday": 5,
              "gdId": 10,
              "date": "2026-11-25",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-25T04:00:00+08:00",
              "home": {
                "id": 52919,
                "code": "MCI",
                "name": "Man City"
              },
              "away": {
                "id": 50136,
                "code": "NAP",
                "name": "Napoli"
              },
              "stadium": "City of Manchester Stadium",
              "venue": "Manchester"
            },
            {
              "id": 2049625,
              "matchday": 5,
              "gdId": 10,
              "date": "2026-11-25",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-25T04:00:00+08:00",
              "home": {
                "id": 50051,
                "code": "RMA",
                "name": "Real Madrid"
              },
              "away": {
                "id": 50062,
                "code": "PSV",
                "name": "PSV"
              },
              "stadium": "Estadio Santiago Bernabéu",
              "venue": "Madrid"
            },
            {
              "id": 2049633,
              "matchday": 5,
              "gdId": 10,
              "date": "2026-11-25",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-11-25T04:00:00+08:00",
              "home": {
                "id": 79946,
                "code": "COM",
                "name": "Como"
              },
              "away": {
                "id": 50129,
                "code": "AEK",
                "name": "AEK Athens"
              },
              "stadium": "Giuseppe Sinigaglia",
              "venue": "Como"
            }
          ]
        },
        {
          "day": 2,
          "name": "比赛日二",
          "date": "2026-11-26",
          "gdId": 11,
          "matches": [
            {
              "id": 2049642,
              "matchday": 5,
              "gdId": 11,
              "date": "2026-11-26",
              "weekday": "Thu",
              "time": "01:45",
              "datetime": "2026-11-26T01:45:00+08:00",
              "home": {
                "id": 2609356,
                "code": "SAB",
                "name": "Sabah"
              },
              "away": {
                "id": 50080,
                "code": "BAR",
                "name": "Barcelona"
              },
              "stadium": "",
              "venue": ""
            },
            {
              "id": 2049641,
              "matchday": 5,
              "gdId": 11,
              "date": "2026-11-26",
              "weekday": "Thu",
              "time": "01:45",
              "datetime": "2026-11-26T01:45:00+08:00",
              "home": {
                "id": 52498,
                "code": "SLA",
                "name": "Slavia Praha"
              },
              "away": {
                "id": 70691,
                "code": "VIL",
                "name": "Villarreal"
              },
              "stadium": "Eden Arena",
              "venue": "Prague"
            },
            {
              "id": 2049640,
              "matchday": 5,
              "gdId": 11,
              "date": "2026-11-26",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-26T04:00:00+08:00",
              "home": {
                "id": 52707,
                "code": "SHK",
                "name": "Shakhtar"
              },
              "away": {
                "id": 52692,
                "code": "FEN",
                "name": "Fenerbahçe"
              },
              "stadium": "Stamford Bridge",
              "venue": "London"
            },
            {
              "id": 2049634,
              "matchday": 5,
              "gdId": 11,
              "date": "2026-11-26",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-26T04:00:00+08:00",
              "home": {
                "id": 52747,
                "code": "PSG",
                "name": "Paris"
              },
              "away": {
                "id": 50137,
                "code": "ROM",
                "name": "Roma"
              },
              "stadium": "Parc des Princes",
              "venue": "Paris"
            },
            {
              "id": 2049635,
              "matchday": 5,
              "gdId": 11,
              "date": "2026-11-26",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-26T04:00:00+08:00",
              "home": {
                "id": 50138,
                "code": "INT",
                "name": "Inter"
              },
              "away": {
                "id": 50107,
                "code": "STU",
                "name": "Stuttgart"
              },
              "stadium": "Stadio San Siro",
              "venue": "Milan"
            },
            {
              "id": 2049636,
              "matchday": 5,
              "gdId": 11,
              "date": "2026-11-26",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-26T04:00:00+08:00",
              "home": {
                "id": 50124,
                "code": "ATM",
                "name": "Atleti"
              },
              "away": {
                "id": 52319,
                "code": "VFK",
                "name": "Viking"
              },
              "stadium": "Estadio Metropolitano",
              "venue": "Madrid"
            },
            {
              "id": 2049637,
              "matchday": 5,
              "gdId": 11,
              "date": "2026-11-26",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-26T04:00:00+08:00",
              "home": {
                "id": 50149,
                "code": "SPO",
                "name": "Sporting CP"
              },
              "away": {
                "id": 52682,
                "code": "MUN",
                "name": "Man Utd"
              },
              "stadium": "Estádio José Alvalade",
              "venue": "Lisbon"
            },
            {
              "id": 2049638,
              "matchday": 5,
              "gdId": 11,
              "date": "2026-11-26",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-26T04:00:00+08:00",
              "home": {
                "id": 50043,
                "code": "BRU",
                "name": "Club Brugge"
              },
              "away": {
                "id": 7889,
                "code": "LIV",
                "name": "Liverpool"
              },
              "stadium": "Jan Breydelstadion",
              "venue": "Bruges"
            },
            {
              "id": 2049639,
              "matchday": 5,
              "gdId": 11,
              "date": "2026-11-26",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-11-26T04:00:00+08:00",
              "home": {
                "id": 75797,
                "code": "LIL",
                "name": "Lille"
              },
              "away": {
                "id": 50037,
                "code": "BAY",
                "name": "Bayern München"
              },
              "stadium": "Stade Pierre Mauroy",
              "venue": "Villeneuve d'Ascq"
            }
          ]
        }
      ]
    },
    {
      "id": 6,
      "name": "Matchday 6",
      "dateRange": "12-09 ~ 12-10",
      "days": [
        {
          "day": 1,
          "name": "比赛日一",
          "date": "2026-12-09",
          "gdId": 12,
          "matches": [
            {
              "id": 2049651,
              "matchday": 6,
              "gdId": 12,
              "date": "2026-12-09",
              "weekday": "Wed",
              "time": "01:45",
              "datetime": "2026-12-09T01:45:00+08:00",
              "home": {
                "id": 52319,
                "code": "VFK",
                "name": "Viking"
              },
              "away": {
                "id": 52749,
                "code": "FEY",
                "name": "Feyenoord"
              },
              "stadium": "Viking stadion",
              "venue": "Stavanger"
            },
            {
              "id": 2049649,
              "matchday": 6,
              "gdId": 12,
              "date": "2026-12-09",
              "weekday": "Wed",
              "time": "01:45",
              "datetime": "2026-12-09T01:45:00+08:00",
              "home": {
                "id": 70691,
                "code": "VIL",
                "name": "Villarreal"
              },
              "away": {
                "id": 2609356,
                "code": "SAB",
                "name": "Sabah"
              },
              "stadium": "Estadio de la Cerámica",
              "venue": "Villarreal"
            },
            {
              "id": 2049643,
              "matchday": 6,
              "gdId": 12,
              "date": "2026-12-09",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-12-09T04:00:00+08:00",
              "home": {
                "id": 50037,
                "code": "BAY",
                "name": "Bayern München"
              },
              "away": {
                "id": 52498,
                "code": "SLA",
                "name": "Slavia Praha"
              },
              "stadium": "Fußball Arena München",
              "venue": "Munich"
            },
            {
              "id": 2049644,
              "matchday": 6,
              "gdId": 12,
              "date": "2026-12-09",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-12-09T04:00:00+08:00",
              "home": {
                "id": 50080,
                "code": "BAR",
                "name": "Barcelona"
              },
              "away": {
                "id": 52919,
                "code": "MCI",
                "name": "Man City"
              },
              "stadium": "Camp Nou",
              "venue": "Barcelona"
            },
            {
              "id": 2049645,
              "matchday": 6,
              "gdId": 12,
              "date": "2026-12-09",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-12-09T04:00:00+08:00",
              "home": {
                "id": 50137,
                "code": "ROM",
                "name": "Roma"
              },
              "away": {
                "id": 50149,
                "code": "SPO",
                "name": "Sporting CP"
              },
              "stadium": "Stadio Olimpico",
              "venue": "Rome"
            },
            {
              "id": 2049646,
              "matchday": 6,
              "gdId": 12,
              "date": "2026-12-09",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-12-09T04:00:00+08:00",
              "home": {
                "id": 52683,
                "code": "AVL",
                "name": "Aston Villa"
              },
              "away": {
                "id": 52747,
                "code": "PSG",
                "name": "Paris"
              },
              "stadium": "Villa Park",
              "venue": "Birmingham"
            },
            {
              "id": 2049647,
              "matchday": 6,
              "gdId": 12,
              "date": "2026-12-09",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-12-09T04:00:00+08:00",
              "home": {
                "id": 52682,
                "code": "MUN",
                "name": "Man Utd"
              },
              "away": {
                "id": 2603790,
                "code": "RBL",
                "name": "Leipzig"
              },
              "stadium": "Old Trafford",
              "venue": "Manchester"
            },
            {
              "id": 2049648,
              "matchday": 6,
              "gdId": 12,
              "date": "2026-12-09",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-12-09T04:00:00+08:00",
              "home": {
                "id": 50136,
                "code": "NAP",
                "name": "Napoli"
              },
              "away": {
                "id": 50043,
                "code": "BRU",
                "name": "Club Brugge"
              },
              "stadium": "Stadio Diego Armando Maradona",
              "venue": "Naples"
            },
            {
              "id": 2049650,
              "matchday": 6,
              "gdId": 12,
              "date": "2026-12-09",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2026-12-09T04:00:00+08:00",
              "home": {
                "id": 50129,
                "code": "AEK",
                "name": "AEK Athens"
              },
              "away": {
                "id": 50067,
                "code": "GAL",
                "name": "Galatasaray"
              },
              "stadium": "AEK Arena",
              "venue": "Athens"
            }
          ]
        },
        {
          "day": 2,
          "name": "比赛日二",
          "date": "2026-12-10",
          "gdId": 13,
          "matches": [
            {
              "id": 2049655,
              "matchday": 6,
              "gdId": 13,
              "date": "2026-12-10",
              "weekday": "Thu",
              "time": "01:45",
              "datetime": "2026-12-10T01:45:00+08:00",
              "home": {
                "id": 52265,
                "code": "BET",
                "name": "Real Betis"
              },
              "away": {
                "id": 79946,
                "code": "COM",
                "name": "Como"
              },
              "stadium": "LA CARTUJA DE SEVILLA",
              "venue": "Seville"
            },
            {
              "id": 2049657,
              "matchday": 6,
              "gdId": 13,
              "date": "2026-12-10",
              "weekday": "Thu",
              "time": "01:45",
              "datetime": "2026-12-10T01:45:00+08:00",
              "home": {
                "id": 52797,
                "code": "SBR",
                "name": "S. Bratislava"
              },
              "away": {
                "id": 52707,
                "code": "SHK",
                "name": "Shakhtar"
              },
              "stadium": "Národný futbalový štadión ",
              "venue": "Bratislava"
            },
            {
              "id": 2049652,
              "matchday": 6,
              "gdId": 13,
              "date": "2026-12-10",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-12-10T04:00:00+08:00",
              "home": {
                "id": 7889,
                "code": "LIV",
                "name": "Liverpool"
              },
              "away": {
                "id": 50064,
                "code": "POR",
                "name": "Porto"
              },
              "stadium": "Anfield",
              "venue": "Liverpool"
            },
            {
              "id": 2049653,
              "matchday": 6,
              "gdId": 13,
              "date": "2026-12-10",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-12-10T04:00:00+08:00",
              "home": {
                "id": 52280,
                "code": "ARS",
                "name": "Arsenal"
              },
              "away": {
                "id": 50051,
                "code": "RMA",
                "name": "Real Madrid"
              },
              "stadium": "Arsenal Stadium",
              "venue": "London"
            },
            {
              "id": 2049654,
              "matchday": 6,
              "gdId": 13,
              "date": "2026-12-10",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-12-10T04:00:00+08:00",
              "home": {
                "id": 52758,
                "code": "BVB",
                "name": "B. Dortmund"
              },
              "away": {
                "id": 50138,
                "code": "INT",
                "name": "Inter"
              },
              "stadium": "BVB Stadion Dortmund",
              "venue": "Dortmund"
            },
            {
              "id": 2049656,
              "matchday": 6,
              "gdId": 13,
              "date": "2026-12-10",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-12-10T04:00:00+08:00",
              "home": {
                "id": 50062,
                "code": "PSV",
                "name": "PSV"
              },
              "away": {
                "id": 50124,
                "code": "ATM",
                "name": "Atleti"
              },
              "stadium": "PSV Stadion",
              "venue": "Eindhoven"
            },
            {
              "id": 2049658,
              "matchday": 6,
              "gdId": 13,
              "date": "2026-12-10",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-12-10T04:00:00+08:00",
              "home": {
                "id": 50107,
                "code": "STU",
                "name": "Stuttgart"
              },
              "away": {
                "id": 75797,
                "code": "LIL",
                "name": "Lille"
              },
              "stadium": "Arena Stuttgart",
              "venue": "Stuttgart"
            },
            {
              "id": 2049659,
              "matchday": 6,
              "gdId": 13,
              "date": "2026-12-10",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-12-10T04:00:00+08:00",
              "home": {
                "id": 63405,
                "code": "LASK",
                "name": "LASK"
              },
              "away": {
                "id": 52692,
                "code": "FEN",
                "name": "Fenerbahçe"
              },
              "stadium": "Oberösterreich Arena",
              "venue": "Linz"
            },
            {
              "id": 2049660,
              "matchday": 6,
              "gdId": 13,
              "date": "2026-12-10",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2026-12-10T04:00:00+08:00",
              "home": {
                "id": 52277,
                "code": "LEN",
                "name": "Lens"
              },
              "away": {
                "id": 59333,
                "code": "BOD",
                "name": "Bodø/Glimt"
              },
              "stadium": "Stade Bollaert-Delelis",
              "venue": "Lens Agglo"
            }
          ]
        }
      ]
    },
    {
      "id": 7,
      "name": "Matchday 7",
      "dateRange": "01-20 ~ 01-21",
      "days": [
        {
          "day": 1,
          "name": "比赛日一",
          "date": "2027-01-20",
          "gdId": 14,
          "matches": [
            {
              "id": 2049666,
              "matchday": 7,
              "gdId": 14,
              "date": "2027-01-20",
              "weekday": "Wed",
              "time": "01:45",
              "datetime": "2027-01-20T01:45:00+08:00",
              "home": {
                "id": 59333,
                "code": "BOD",
                "name": "Bodø/Glimt"
              },
              "away": {
                "id": 50124,
                "code": "ATM",
                "name": "Atleti"
              },
              "stadium": "Aspmyra",
              "venue": "Bodø"
            },
            {
              "id": 2049667,
              "matchday": 7,
              "gdId": 14,
              "date": "2027-01-20",
              "weekday": "Wed",
              "time": "01:45",
              "datetime": "2027-01-20T01:45:00+08:00",
              "home": {
                "id": 50067,
                "code": "GAL",
                "name": "Galatasaray"
              },
              "away": {
                "id": 52749,
                "code": "FEY",
                "name": "Feyenoord"
              },
              "stadium": "Ali Sami Yen Spor Kompleksi",
              "venue": "Istanbul"
            },
            {
              "id": 2049664,
              "matchday": 7,
              "gdId": 14,
              "date": "2027-01-20",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2027-01-20T04:00:00+08:00",
              "home": {
                "id": 50064,
                "code": "POR",
                "name": "Porto"
              },
              "away": {
                "id": 52498,
                "code": "SLA",
                "name": "Slavia Praha"
              },
              "stadium": "Estádio do Dragão",
              "venue": "Porto"
            },
            {
              "id": 2049665,
              "matchday": 7,
              "gdId": 14,
              "date": "2027-01-20",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2027-01-20T04:00:00+08:00",
              "home": {
                "id": 75797,
                "code": "LIL",
                "name": "Lille"
              },
              "away": {
                "id": 52797,
                "code": "SBR",
                "name": "S. Bratislava"
              },
              "stadium": "Stade Pierre Mauroy",
              "venue": "Villeneuve d'Ascq"
            },
            {
              "id": 2049668,
              "matchday": 7,
              "gdId": 14,
              "date": "2027-01-20",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2027-01-20T04:00:00+08:00",
              "home": {
                "id": 50107,
                "code": "STU",
                "name": "Stuttgart"
              },
              "away": {
                "id": 50043,
                "code": "BRU",
                "name": "Club Brugge"
              },
              "stadium": "Arena Stuttgart",
              "venue": "Stuttgart"
            },
            {
              "id": 2049669,
              "matchday": 7,
              "gdId": 14,
              "date": "2027-01-20",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2027-01-20T04:00:00+08:00",
              "home": {
                "id": 50129,
                "code": "AEK",
                "name": "AEK Athens"
              },
              "away": {
                "id": 50137,
                "code": "ROM",
                "name": "Roma"
              },
              "stadium": "AEK Arena",
              "venue": "Athens"
            },
            {
              "id": 2049661,
              "matchday": 7,
              "gdId": 14,
              "date": "2027-01-20",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2027-01-20T04:00:00+08:00",
              "home": {
                "id": 50051,
                "code": "RMA",
                "name": "Real Madrid"
              },
              "away": {
                "id": 63405,
                "code": "LASK",
                "name": "LASK"
              },
              "stadium": "Estadio Santiago Bernabéu",
              "venue": "Madrid"
            },
            {
              "id": 2049662,
              "matchday": 7,
              "gdId": 14,
              "date": "2027-01-20",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2027-01-20T04:00:00+08:00",
              "home": {
                "id": 50138,
                "code": "INT",
                "name": "Inter"
              },
              "away": {
                "id": 7889,
                "code": "LIV",
                "name": "Liverpool"
              },
              "stadium": "Stadio San Siro",
              "venue": "Milan"
            },
            {
              "id": 2049663,
              "matchday": 7,
              "gdId": 14,
              "date": "2027-01-20",
              "weekday": "Wed",
              "time": "04:00",
              "datetime": "2027-01-20T04:00:00+08:00",
              "home": {
                "id": 52683,
                "code": "AVL",
                "name": "Aston Villa"
              },
              "away": {
                "id": 52758,
                "code": "BVB",
                "name": "B. Dortmund"
              },
              "stadium": "Villa Park",
              "venue": "Birmingham"
            }
          ]
        },
        {
          "day": 2,
          "name": "比赛日二",
          "date": "2027-01-21",
          "gdId": 15,
          "matches": [
            {
              "id": 2049678,
              "matchday": 7,
              "gdId": 15,
              "date": "2027-01-21",
              "weekday": "Thu",
              "time": "01:45",
              "datetime": "2027-01-21T01:45:00+08:00",
              "home": {
                "id": 2609356,
                "code": "SAB",
                "name": "Sabah"
              },
              "away": {
                "id": 50136,
                "code": "NAP",
                "name": "Napoli"
              },
              "stadium": "",
              "venue": ""
            },
            {
              "id": 2049674,
              "matchday": 7,
              "gdId": 15,
              "date": "2027-01-21",
              "weekday": "Thu",
              "time": "01:45",
              "datetime": "2027-01-21T01:45:00+08:00",
              "home": {
                "id": 52692,
                "code": "FEN",
                "name": "Fenerbahçe"
              },
              "away": {
                "id": 70691,
                "code": "VIL",
                "name": "Villarreal"
              },
              "stadium": "Fenerbahçe Şükrü Saracoğlu Spor Kompleksi",
              "venue": "Istanbul"
            },
            {
              "id": 2049673,
              "matchday": 7,
              "gdId": 15,
              "date": "2027-01-21",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-21T04:00:00+08:00",
              "home": {
                "id": 2603790,
                "code": "RBL",
                "name": "Leipzig"
              },
              "away": {
                "id": 52707,
                "code": "SHK",
                "name": "Shakhtar"
              },
              "stadium": "RB Arena",
              "venue": "Leipzig"
            },
            {
              "id": 2049675,
              "matchday": 7,
              "gdId": 15,
              "date": "2027-01-21",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-21T04:00:00+08:00",
              "home": {
                "id": 79946,
                "code": "COM",
                "name": "Como"
              },
              "away": {
                "id": 52747,
                "code": "PSG",
                "name": "Paris"
              },
              "stadium": "Giuseppe Sinigaglia",
              "venue": "Como"
            },
            {
              "id": 2049676,
              "matchday": 7,
              "gdId": 15,
              "date": "2027-01-21",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-21T04:00:00+08:00",
              "home": {
                "id": 52277,
                "code": "LEN",
                "name": "Lens"
              },
              "away": {
                "id": 52919,
                "code": "MCI",
                "name": "Man City"
              },
              "stadium": "Stade Bollaert-Delelis",
              "venue": "Lens Agglo"
            },
            {
              "id": 2049677,
              "matchday": 7,
              "gdId": 15,
              "date": "2027-01-21",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-21T04:00:00+08:00",
              "home": {
                "id": 52319,
                "code": "VFK",
                "name": "Viking"
              },
              "away": {
                "id": 50062,
                "code": "PSV",
                "name": "PSV"
              },
              "stadium": "Viking stadion",
              "venue": "Stavanger"
            },
            {
              "id": 2049671,
              "matchday": 7,
              "gdId": 15,
              "date": "2027-01-21",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-21T04:00:00+08:00",
              "home": {
                "id": 52682,
                "code": "MUN",
                "name": "Man Utd"
              },
              "away": {
                "id": 50037,
                "code": "BAY",
                "name": "Bayern München"
              },
              "stadium": "Old Trafford",
              "venue": "Manchester"
            },
            {
              "id": 2049670,
              "matchday": 7,
              "gdId": 15,
              "date": "2027-01-21",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-21T04:00:00+08:00",
              "home": {
                "id": 50149,
                "code": "SPO",
                "name": "Sporting CP"
              },
              "away": {
                "id": 50080,
                "code": "BAR",
                "name": "Barcelona"
              },
              "stadium": "Estádio José Alvalade",
              "venue": "Lisbon"
            },
            {
              "id": 2049672,
              "matchday": 7,
              "gdId": 15,
              "date": "2027-01-21",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-21T04:00:00+08:00",
              "home": {
                "id": 52265,
                "code": "BET",
                "name": "Real Betis"
              },
              "away": {
                "id": 52280,
                "code": "ARS",
                "name": "Arsenal"
              },
              "stadium": "LA CARTUJA DE SEVILLA",
              "venue": "Seville"
            }
          ]
        }
      ]
    },
    {
      "id": 8,
      "name": "Matchday 8",
      "dateRange": "01-28",
      "days": [
        {
          "day": 1,
          "name": "比赛日一",
          "date": "2027-01-28",
          "gdId": 16,
          "matches": [
            {
              "id": 2049694,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 52498,
                "code": "SLA",
                "name": "Slavia Praha"
              },
              "away": {
                "id": 52683,
                "code": "AVL",
                "name": "Aston Villa"
              },
              "stadium": "Eden Arena",
              "venue": "Prague"
            },
            {
              "id": 2049696,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 63405,
                "code": "LASK",
                "name": "LASK"
              },
              "away": {
                "id": 50064,
                "code": "POR",
                "name": "Porto"
              },
              "stadium": "Oberösterreich Arena",
              "venue": "Linz"
            },
            {
              "id": 2049680,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 50037,
                "code": "BAY",
                "name": "Bayern München"
              },
              "away": {
                "id": 52265,
                "code": "BET",
                "name": "Real Betis"
              },
              "stadium": "Fußball Arena München",
              "venue": "Munich"
            },
            {
              "id": 2049679,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 52747,
                "code": "PSG",
                "name": "Paris"
              },
              "away": {
                "id": 50067,
                "code": "GAL",
                "name": "Galatasaray"
              },
              "stadium": "Parc des Princes",
              "venue": "Paris"
            },
            {
              "id": 2049695,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 52797,
                "code": "SBR",
                "name": "S. Bratislava"
              },
              "away": {
                "id": 50138,
                "code": "INT",
                "name": "Inter"
              },
              "stadium": "Národný futbalový štadión ",
              "venue": "Bratislava"
            },
            {
              "id": 2049681,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 7889,
                "code": "LIV",
                "name": "Liverpool"
              },
              "away": {
                "id": 52277,
                "code": "LEN",
                "name": "Lens"
              },
              "stadium": "Anfield",
              "venue": "Liverpool"
            },
            {
              "id": 2049682,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 52919,
                "code": "MCI",
                "name": "Man City"
              },
              "away": {
                "id": 50149,
                "code": "SPO",
                "name": "Sporting CP"
              },
              "stadium": "City of Manchester Stadium",
              "venue": "Manchester"
            },
            {
              "id": 2049683,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 52280,
                "code": "ARS",
                "name": "Arsenal"
              },
              "away": {
                "id": 2609356,
                "code": "SAB",
                "name": "Sabah"
              },
              "stadium": "Arsenal Stadium",
              "venue": "London"
            },
            {
              "id": 2049684,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 50080,
                "code": "BAR",
                "name": "Barcelona"
              },
              "away": {
                "id": 79946,
                "code": "COM",
                "name": "Como"
              },
              "stadium": "Camp Nou",
              "venue": "Barcelona"
            },
            {
              "id": 2049685,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 50124,
                "code": "ATM",
                "name": "Atleti"
              },
              "away": {
                "id": 52692,
                "code": "FEN",
                "name": "Fenerbahçe"
              },
              "stadium": "Estadio Metropolitano",
              "venue": "Madrid"
            },
            {
              "id": 2049686,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 52758,
                "code": "BVB",
                "name": "B. Dortmund"
              },
              "away": {
                "id": 50129,
                "code": "AEK",
                "name": "AEK Athens"
              },
              "stadium": "BVB Stadion Dortmund",
              "venue": "Dortmund"
            },
            {
              "id": 2049687,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 50137,
                "code": "ROM",
                "name": "Roma"
              },
              "away": {
                "id": 75797,
                "code": "LIL",
                "name": "Lille"
              },
              "stadium": "Stadio Olimpico",
              "venue": "Rome"
            },
            {
              "id": 2049688,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 50043,
                "code": "BRU",
                "name": "Club Brugge"
              },
              "away": {
                "id": 59333,
                "code": "BOD",
                "name": "Bodø/Glimt"
              },
              "stadium": "Jan Breydelstadion",
              "venue": "Bruges"
            },
            {
              "id": 2049689,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 50062,
                "code": "PSV",
                "name": "PSV"
              },
              "away": {
                "id": 50107,
                "code": "STU",
                "name": "Stuttgart"
              },
              "stadium": "PSV Stadion",
              "venue": "Eindhoven"
            },
            {
              "id": 2049690,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 52749,
                "code": "FEY",
                "name": "Feyenoord"
              },
              "away": {
                "id": 2603790,
                "code": "RBL",
                "name": "Leipzig"
              },
              "stadium": "Stadion Feijenoord 'De Kuip'",
              "venue": "Rotterdam"
            },
            {
              "id": 2049691,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 50136,
                "code": "NAP",
                "name": "Napoli"
              },
              "away": {
                "id": 52319,
                "code": "VFK",
                "name": "Viking"
              },
              "stadium": "Stadio Diego Armando Maradona",
              "venue": "Naples"
            },
            {
              "id": 2049692,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 70691,
                "code": "VIL",
                "name": "Villarreal"
              },
              "away": {
                "id": 52682,
                "code": "MUN",
                "name": "Man Utd"
              },
              "stadium": "Estadio de la Cerámica",
              "venue": "Villarreal"
            },
            {
              "id": 2049693,
              "matchday": 8,
              "gdId": 16,
              "date": "2027-01-28",
              "weekday": "Thu",
              "time": "04:00",
              "datetime": "2027-01-28T04:00:00+08:00",
              "home": {
                "id": 52707,
                "code": "SHK",
                "name": "Shakhtar"
              },
              "away": {
                "id": 50051,
                "code": "RMA",
                "name": "Real Madrid"
              },
              "stadium": "Stamford Bridge",
              "venue": "London"
            }
          ]
        }
      ]
    }
  ],
  "fixtures": [
    {
      "id": 2049558,
      "matchday": 1,
      "gdId": 1,
      "date": "2026-09-09",
      "weekday": "Wed",
      "time": "00:45",
      "datetime": "2026-09-09T00:45:00+08:00",
      "home": {
        "id": 50129,
        "code": "AEK",
        "name": "AEK Athens"
      },
      "away": {
        "id": 63405,
        "code": "LASK",
        "name": "LASK"
      },
      "stadium": "AEK Arena",
      "venue": "Athens"
    },
    {
      "id": 2049556,
      "matchday": 1,
      "gdId": 1,
      "date": "2026-09-09",
      "weekday": "Wed",
      "time": "00:45",
      "datetime": "2026-09-09T00:45:00+08:00",
      "home": {
        "id": 50043,
        "code": "BRU",
        "name": "Club Brugge"
      },
      "away": {
        "id": 52683,
        "code": "AVL",
        "name": "Aston Villa"
      },
      "stadium": "Jan Breydelstadion",
      "venue": "Bruges"
    },
    {
      "id": 2049553,
      "matchday": 1,
      "gdId": 1,
      "date": "2026-09-09",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-09-09T03:00:00+08:00",
      "home": {
        "id": 50051,
        "code": "RMA",
        "name": "Real Madrid"
      },
      "away": {
        "id": 50138,
        "code": "INT",
        "name": "Inter"
      },
      "stadium": "Estadio Santiago Bernabéu",
      "venue": "Madrid"
    },
    {
      "id": 2049555,
      "matchday": 1,
      "gdId": 1,
      "date": "2026-09-09",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-09-09T03:00:00+08:00",
      "home": {
        "id": 50064,
        "code": "POR",
        "name": "Porto"
      },
      "away": {
        "id": 52919,
        "code": "MCI",
        "name": "Man City"
      },
      "stadium": "Estádio do Dragão",
      "venue": "Porto"
    },
    {
      "id": 2049557,
      "matchday": 1,
      "gdId": 1,
      "date": "2026-09-09",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-09-09T03:00:00+08:00",
      "home": {
        "id": 75797,
        "code": "LIL",
        "name": "Lille"
      },
      "away": {
        "id": 52265,
        "code": "BET",
        "name": "Real Betis"
      },
      "stadium": "Stade Pierre Mauroy",
      "venue": "Villeneuve d'Ascq"
    },
    {
      "id": 2049554,
      "matchday": 1,
      "gdId": 1,
      "date": "2026-09-09",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-09-09T03:00:00+08:00",
      "home": {
        "id": 52758,
        "code": "BVB",
        "name": "B. Dortmund"
      },
      "away": {
        "id": 70691,
        "code": "VIL",
        "name": "Villarreal"
      },
      "stadium": "BVB Stadion Dortmund",
      "venue": "Dortmund"
    },
    {
      "id": 2049564,
      "matchday": 1,
      "gdId": 2,
      "date": "2026-09-10",
      "weekday": "Thu",
      "time": "00:45",
      "datetime": "2026-09-10T00:45:00+08:00",
      "home": {
        "id": 50107,
        "code": "STU",
        "name": "Stuttgart"
      },
      "away": {
        "id": 52319,
        "code": "VFK",
        "name": "Viking"
      },
      "stadium": "Arena Stuttgart",
      "venue": "Stuttgart"
    },
    {
      "id": 2049561,
      "matchday": 1,
      "gdId": 2,
      "date": "2026-09-10",
      "weekday": "Thu",
      "time": "00:45",
      "datetime": "2026-09-10T00:45:00+08:00",
      "home": {
        "id": 50080,
        "code": "BAR",
        "name": "Barcelona"
      },
      "away": {
        "id": 52749,
        "code": "FEY",
        "name": "Feyenoord"
      },
      "stadium": "Camp Nou",
      "venue": "Barcelona"
    },
    {
      "id": 2049562,
      "matchday": 1,
      "gdId": 2,
      "date": "2026-09-10",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-09-10T03:00:00+08:00",
      "home": {
        "id": 50149,
        "code": "SPO",
        "name": "Sporting CP"
      },
      "away": {
        "id": 50067,
        "code": "GAL",
        "name": "Galatasaray"
      },
      "stadium": "Estádio José Alvalade",
      "venue": "Lisbon"
    },
    {
      "id": 2049563,
      "matchday": 1,
      "gdId": 2,
      "date": "2026-09-10",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-09-10T03:00:00+08:00",
      "home": {
        "id": 50136,
        "code": "NAP",
        "name": "Napoli"
      },
      "away": {
        "id": 52280,
        "code": "ARS",
        "name": "Arsenal"
      },
      "stadium": "Stadio Diego Armando Maradona",
      "venue": "Naples"
    },
    {
      "id": 2049560,
      "matchday": 1,
      "gdId": 2,
      "date": "2026-09-10",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-09-10T03:00:00+08:00",
      "home": {
        "id": 7889,
        "code": "LIV",
        "name": "Liverpool"
      },
      "away": {
        "id": 50124,
        "code": "ATM",
        "name": "Atleti"
      },
      "stadium": "Anfield",
      "venue": "Liverpool"
    },
    {
      "id": 2049559,
      "matchday": 1,
      "gdId": 2,
      "date": "2026-09-10",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-09-10T03:00:00+08:00",
      "home": {
        "id": 52747,
        "code": "PSG",
        "name": "Paris"
      },
      "away": {
        "id": 52797,
        "code": "SBR",
        "name": "S. Bratislava"
      },
      "stadium": "Parc des Princes",
      "venue": "Paris"
    },
    {
      "id": 2049567,
      "matchday": 1,
      "gdId": 3,
      "date": "2026-09-11",
      "weekday": "Fri",
      "time": "00:45",
      "datetime": "2026-09-11T00:45:00+08:00",
      "home": {
        "id": 50062,
        "code": "PSV",
        "name": "PSV"
      },
      "away": {
        "id": 52707,
        "code": "SHK",
        "name": "Shakhtar"
      },
      "stadium": "PSV Stadion",
      "venue": "Eindhoven"
    },
    {
      "id": 2049568,
      "matchday": 1,
      "gdId": 3,
      "date": "2026-09-11",
      "weekday": "Fri",
      "time": "00:45",
      "datetime": "2026-09-11T00:45:00+08:00",
      "home": {
        "id": 52692,
        "code": "FEN",
        "name": "Fenerbahçe"
      },
      "away": {
        "id": 50137,
        "code": "ROM",
        "name": "Roma"
      },
      "stadium": "Fenerbahçe Şükrü Saracoğlu Spor Kompleksi",
      "venue": "Istanbul"
    },
    {
      "id": 2049570,
      "matchday": 1,
      "gdId": 3,
      "date": "2026-09-11",
      "weekday": "Fri",
      "time": "03:00",
      "datetime": "2026-09-11T03:00:00+08:00",
      "home": {
        "id": 79946,
        "code": "COM",
        "name": "Como"
      },
      "away": {
        "id": 2603790,
        "code": "RBL",
        "name": "Leipzig"
      },
      "stadium": "Giuseppe Sinigaglia",
      "venue": "Como"
    },
    {
      "id": 2049566,
      "matchday": 1,
      "gdId": 3,
      "date": "2026-09-11",
      "weekday": "Fri",
      "time": "03:00",
      "datetime": "2026-09-11T03:00:00+08:00",
      "home": {
        "id": 52682,
        "code": "MUN",
        "name": "Man Utd"
      },
      "away": {
        "id": 2609356,
        "code": "SAB",
        "name": "Sabah"
      },
      "stadium": "Old Trafford",
      "venue": "Manchester"
    },
    {
      "id": 2049569,
      "matchday": 1,
      "gdId": 3,
      "date": "2026-09-11",
      "weekday": "Fri",
      "time": "03:00",
      "datetime": "2026-09-11T03:00:00+08:00",
      "home": {
        "id": 52498,
        "code": "SLA",
        "name": "Slavia Praha"
      },
      "away": {
        "id": 52277,
        "code": "LEN",
        "name": "Lens"
      },
      "stadium": "Eden Arena",
      "venue": "Prague"
    },
    {
      "id": 2049565,
      "matchday": 1,
      "gdId": 3,
      "date": "2026-09-11",
      "weekday": "Fri",
      "time": "03:00",
      "datetime": "2026-09-11T03:00:00+08:00",
      "home": {
        "id": 50037,
        "code": "BAY",
        "name": "Bayern München"
      },
      "away": {
        "id": 59333,
        "code": "BOD",
        "name": "Bodø/Glimt"
      },
      "stadium": "Fußball Arena München",
      "venue": "Munich"
    },
    {
      "id": 2049579,
      "matchday": 2,
      "gdId": 4,
      "date": "2026-10-14",
      "weekday": "Wed",
      "time": "00:45",
      "datetime": "2026-10-14T00:45:00+08:00",
      "home": {
        "id": 2609356,
        "code": "SAB",
        "name": "Sabah"
      },
      "away": {
        "id": 52498,
        "code": "SLA",
        "name": "Slavia Praha"
      },
      "stadium": "",
      "venue": ""
    },
    {
      "id": 2049577,
      "matchday": 2,
      "gdId": 4,
      "date": "2026-10-14",
      "weekday": "Wed",
      "time": "00:45",
      "datetime": "2026-10-14T00:45:00+08:00",
      "home": {
        "id": 52277,
        "code": "LEN",
        "name": "Lens"
      },
      "away": {
        "id": 50149,
        "code": "SPO",
        "name": "Sporting CP"
      },
      "stadium": "Stade Bollaert-Delelis",
      "venue": "Lens Agglo"
    },
    {
      "id": 2049576,
      "matchday": 2,
      "gdId": 4,
      "date": "2026-10-14",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-14T03:00:00+08:00",
      "home": {
        "id": 50067,
        "code": "GAL",
        "name": "Galatasaray"
      },
      "away": {
        "id": 50080,
        "code": "BAR",
        "name": "Barcelona"
      },
      "stadium": "Ali Sami Yen Spor Kompleksi",
      "venue": "Istanbul"
    },
    {
      "id": 2049571,
      "matchday": 2,
      "gdId": 4,
      "date": "2026-10-14",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-14T03:00:00+08:00",
      "home": {
        "id": 50138,
        "code": "INT",
        "name": "Inter"
      },
      "away": {
        "id": 50043,
        "code": "BRU",
        "name": "Club Brugge"
      },
      "stadium": "Stadio San Siro",
      "venue": "Milan"
    },
    {
      "id": 2049572,
      "matchday": 2,
      "gdId": 4,
      "date": "2026-10-14",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-14T03:00:00+08:00",
      "home": {
        "id": 52280,
        "code": "ARS",
        "name": "Arsenal"
      },
      "away": {
        "id": 75797,
        "code": "LIL",
        "name": "Lille"
      },
      "stadium": "Arsenal Stadium",
      "venue": "London"
    },
    {
      "id": 2049573,
      "matchday": 2,
      "gdId": 4,
      "date": "2026-10-14",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-14T03:00:00+08:00",
      "home": {
        "id": 50124,
        "code": "ATM",
        "name": "Atleti"
      },
      "away": {
        "id": 52682,
        "code": "MUN",
        "name": "Man Utd"
      },
      "stadium": "Estadio Metropolitano",
      "venue": "Madrid"
    },
    {
      "id": 2049574,
      "matchday": 2,
      "gdId": 4,
      "date": "2026-10-14",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-14T03:00:00+08:00",
      "home": {
        "id": 2603790,
        "code": "RBL",
        "name": "Leipzig"
      },
      "away": {
        "id": 50062,
        "code": "PSV",
        "name": "PSV"
      },
      "stadium": "RB Arena",
      "venue": "Leipzig"
    },
    {
      "id": 2049575,
      "matchday": 2,
      "gdId": 4,
      "date": "2026-10-14",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-14T03:00:00+08:00",
      "home": {
        "id": 70691,
        "code": "VIL",
        "name": "Villarreal"
      },
      "away": {
        "id": 50136,
        "code": "NAP",
        "name": "Napoli"
      },
      "stadium": "Estadio de la Cerámica",
      "venue": "Villarreal"
    },
    {
      "id": 2049578,
      "matchday": 2,
      "gdId": 4,
      "date": "2026-10-14",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-14T03:00:00+08:00",
      "home": {
        "id": 52319,
        "code": "VFK",
        "name": "Viking"
      },
      "away": {
        "id": 50037,
        "code": "BAY",
        "name": "Bayern München"
      },
      "stadium": "Viking stadion",
      "venue": "Stavanger"
    },
    {
      "id": 2049584,
      "matchday": 2,
      "gdId": 5,
      "date": "2026-10-15",
      "weekday": "Thu",
      "time": "00:45",
      "datetime": "2026-10-15T00:45:00+08:00",
      "home": {
        "id": 52749,
        "code": "FEY",
        "name": "Feyenoord"
      },
      "away": {
        "id": 79946,
        "code": "COM",
        "name": "Como"
      },
      "stadium": "Stadion Feijenoord 'De Kuip'",
      "venue": "Rotterdam"
    },
    {
      "id": 2049588,
      "matchday": 2,
      "gdId": 5,
      "date": "2026-10-15",
      "weekday": "Thu",
      "time": "00:45",
      "datetime": "2026-10-15T00:45:00+08:00",
      "home": {
        "id": 63405,
        "code": "LASK",
        "name": "LASK"
      },
      "away": {
        "id": 7889,
        "code": "LIV",
        "name": "Liverpool"
      },
      "stadium": "Oberösterreich Arena",
      "venue": "Linz"
    },
    {
      "id": 2049581,
      "matchday": 2,
      "gdId": 5,
      "date": "2026-10-15",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-15T03:00:00+08:00",
      "home": {
        "id": 50137,
        "code": "ROM",
        "name": "Roma"
      },
      "away": {
        "id": 50051,
        "code": "RMA",
        "name": "Real Madrid"
      },
      "stadium": "Stadio Olimpico",
      "venue": "Rome"
    },
    {
      "id": 2049582,
      "matchday": 2,
      "gdId": 5,
      "date": "2026-10-15",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-15T03:00:00+08:00",
      "home": {
        "id": 52683,
        "code": "AVL",
        "name": "Aston Villa"
      },
      "away": {
        "id": 52692,
        "code": "FEN",
        "name": "Fenerbahçe"
      },
      "stadium": "Villa Park",
      "venue": "Birmingham"
    },
    {
      "id": 2049583,
      "matchday": 2,
      "gdId": 5,
      "date": "2026-10-15",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-15T03:00:00+08:00",
      "home": {
        "id": 52265,
        "code": "BET",
        "name": "Real Betis"
      },
      "away": {
        "id": 50064,
        "code": "POR",
        "name": "Porto"
      },
      "stadium": "LA CARTUJA DE SEVILLA",
      "venue": "Seville"
    },
    {
      "id": 2049585,
      "matchday": 2,
      "gdId": 5,
      "date": "2026-10-15",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-15T03:00:00+08:00",
      "home": {
        "id": 59333,
        "code": "BOD",
        "name": "Bodø/Glimt"
      },
      "away": {
        "id": 52758,
        "code": "BVB",
        "name": "B. Dortmund"
      },
      "stadium": "Aspmyra",
      "venue": "Bodø"
    },
    {
      "id": 2049587,
      "matchday": 2,
      "gdId": 5,
      "date": "2026-10-15",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-15T03:00:00+08:00",
      "home": {
        "id": 52797,
        "code": "SBR",
        "name": "S. Bratislava"
      },
      "away": {
        "id": 50107,
        "code": "STU",
        "name": "Stuttgart"
      },
      "stadium": "Národný futbalový štadión ",
      "venue": "Bratislava"
    },
    {
      "id": 2049586,
      "matchday": 2,
      "gdId": 5,
      "date": "2026-10-15",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-15T03:00:00+08:00",
      "home": {
        "id": 52707,
        "code": "SHK",
        "name": "Shakhtar"
      },
      "away": {
        "id": 50129,
        "code": "AEK",
        "name": "AEK Athens"
      },
      "stadium": "Stamford Bridge",
      "venue": "London"
    },
    {
      "id": 2049580,
      "matchday": 2,
      "gdId": 5,
      "date": "2026-10-15",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-15T03:00:00+08:00",
      "home": {
        "id": 52919,
        "code": "MCI",
        "name": "Man City"
      },
      "away": {
        "id": 52747,
        "code": "PSG",
        "name": "Paris"
      },
      "stadium": "City of Manchester Stadium",
      "venue": "Manchester"
    },
    {
      "id": 2049595,
      "matchday": 3,
      "gdId": 6,
      "date": "2026-10-21",
      "weekday": "Wed",
      "time": "00:45",
      "datetime": "2026-10-21T00:45:00+08:00",
      "home": {
        "id": 52692,
        "code": "FEN",
        "name": "Fenerbahçe"
      },
      "away": {
        "id": 52498,
        "code": "SLA",
        "name": "Slavia Praha"
      },
      "stadium": "Fenerbahçe Şükrü Saracoğlu Spor Kompleksi",
      "venue": "Istanbul"
    },
    {
      "id": 2049597,
      "matchday": 3,
      "gdId": 6,
      "date": "2026-10-21",
      "weekday": "Wed",
      "time": "00:45",
      "datetime": "2026-10-21T00:45:00+08:00",
      "home": {
        "id": 2609356,
        "code": "SAB",
        "name": "Sabah"
      },
      "away": {
        "id": 52758,
        "code": "BVB",
        "name": "B. Dortmund"
      },
      "stadium": "",
      "venue": ""
    },
    {
      "id": 2049596,
      "matchday": 3,
      "gdId": 6,
      "date": "2026-10-21",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-21T03:00:00+08:00",
      "home": {
        "id": 50107,
        "code": "STU",
        "name": "Stuttgart"
      },
      "away": {
        "id": 50124,
        "code": "ATM",
        "name": "Atleti"
      },
      "stadium": "Arena Stuttgart",
      "venue": "Stuttgart"
    },
    {
      "id": 2049589,
      "matchday": 3,
      "gdId": 6,
      "date": "2026-10-21",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-21T03:00:00+08:00",
      "home": {
        "id": 52747,
        "code": "PSG",
        "name": "Paris"
      },
      "away": {
        "id": 50080,
        "code": "BAR",
        "name": "Barcelona"
      },
      "stadium": "Parc des Princes",
      "venue": "Paris"
    },
    {
      "id": 2049590,
      "matchday": 3,
      "gdId": 6,
      "date": "2026-10-21",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-21T03:00:00+08:00",
      "home": {
        "id": 7889,
        "code": "LIV",
        "name": "Liverpool"
      },
      "away": {
        "id": 70691,
        "code": "VIL",
        "name": "Villarreal"
      },
      "stadium": "Anfield",
      "venue": "Liverpool"
    },
    {
      "id": 2049591,
      "matchday": 3,
      "gdId": 6,
      "date": "2026-10-21",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-21T03:00:00+08:00",
      "home": {
        "id": 52919,
        "code": "MCI",
        "name": "Man City"
      },
      "away": {
        "id": 50129,
        "code": "AEK",
        "name": "AEK Athens"
      },
      "stadium": "City of Manchester Stadium",
      "venue": "Manchester"
    },
    {
      "id": 2049592,
      "matchday": 3,
      "gdId": 6,
      "date": "2026-10-21",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-21T03:00:00+08:00",
      "home": {
        "id": 50137,
        "code": "ROM",
        "name": "Roma"
      },
      "away": {
        "id": 52797,
        "code": "SBR",
        "name": "S. Bratislava"
      },
      "stadium": "Stadio Olimpico",
      "venue": "Rome"
    },
    {
      "id": 2049593,
      "matchday": 3,
      "gdId": 6,
      "date": "2026-10-21",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-21T03:00:00+08:00",
      "home": {
        "id": 50064,
        "code": "POR",
        "name": "Porto"
      },
      "away": {
        "id": 50062,
        "code": "PSV",
        "name": "PSV"
      },
      "stadium": "Estádio do Dragão",
      "venue": "Porto"
    },
    {
      "id": 2049594,
      "matchday": 3,
      "gdId": 6,
      "date": "2026-10-21",
      "weekday": "Wed",
      "time": "03:00",
      "datetime": "2026-10-21T03:00:00+08:00",
      "home": {
        "id": 50136,
        "code": "NAP",
        "name": "Napoli"
      },
      "away": {
        "id": 59333,
        "code": "BOD",
        "name": "Bodø/Glimt"
      },
      "stadium": "Stadio Diego Armando Maradona",
      "venue": "Naples"
    },
    {
      "id": 2049605,
      "matchday": 3,
      "gdId": 7,
      "date": "2026-10-22",
      "weekday": "Thu",
      "time": "00:45",
      "datetime": "2026-10-22T00:45:00+08:00",
      "home": {
        "id": 75797,
        "code": "LIL",
        "name": "Lille"
      },
      "away": {
        "id": 50067,
        "code": "GAL",
        "name": "Galatasaray"
      },
      "stadium": "Stade Pierre Mauroy",
      "venue": "Villeneuve d'Ascq"
    },
    {
      "id": 2049606,
      "matchday": 3,
      "gdId": 7,
      "date": "2026-10-22",
      "weekday": "Thu",
      "time": "00:45",
      "datetime": "2026-10-22T00:45:00+08:00",
      "home": {
        "id": 79946,
        "code": "COM",
        "name": "Como"
      },
      "away": {
        "id": 52682,
        "code": "MUN",
        "name": "Man Utd"
      },
      "stadium": "Giuseppe Sinigaglia",
      "venue": "Como"
    },
    {
      "id": 2049603,
      "matchday": 3,
      "gdId": 7,
      "date": "2026-10-22",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-22T03:00:00+08:00",
      "home": {
        "id": 50043,
        "code": "BRU",
        "name": "Club Brugge"
      },
      "away": {
        "id": 52277,
        "code": "LEN",
        "name": "Lens"
      },
      "stadium": "Jan Breydelstadion",
      "venue": "Bruges"
    },
    {
      "id": 2049598,
      "matchday": 3,
      "gdId": 7,
      "date": "2026-10-22",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-22T03:00:00+08:00",
      "home": {
        "id": 50037,
        "code": "BAY",
        "name": "Bayern München"
      },
      "away": {
        "id": 52280,
        "code": "ARS",
        "name": "Arsenal"
      },
      "stadium": "Fußball Arena München",
      "venue": "Munich"
    },
    {
      "id": 2049599,
      "matchday": 3,
      "gdId": 7,
      "date": "2026-10-22",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-22T03:00:00+08:00",
      "home": {
        "id": 50051,
        "code": "RMA",
        "name": "Real Madrid"
      },
      "away": {
        "id": 2603790,
        "code": "RBL",
        "name": "Leipzig"
      },
      "stadium": "Estadio Santiago Bernabéu",
      "venue": "Madrid"
    },
    {
      "id": 2049600,
      "matchday": 3,
      "gdId": 7,
      "date": "2026-10-22",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-22T03:00:00+08:00",
      "home": {
        "id": 50138,
        "code": "INT",
        "name": "Inter"
      },
      "away": {
        "id": 52707,
        "code": "SHK",
        "name": "Shakhtar"
      },
      "stadium": "Stadio San Siro",
      "venue": "Milan"
    },
    {
      "id": 2049601,
      "matchday": 3,
      "gdId": 7,
      "date": "2026-10-22",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-22T03:00:00+08:00",
      "home": {
        "id": 50149,
        "code": "SPO",
        "name": "Sporting CP"
      },
      "away": {
        "id": 63405,
        "code": "LASK",
        "name": "LASK"
      },
      "stadium": "Estádio José Alvalade",
      "venue": "Lisbon"
    },
    {
      "id": 2049602,
      "matchday": 3,
      "gdId": 7,
      "date": "2026-10-22",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-22T03:00:00+08:00",
      "home": {
        "id": 52683,
        "code": "AVL",
        "name": "Aston Villa"
      },
      "away": {
        "id": 52319,
        "code": "VFK",
        "name": "Viking"
      },
      "stadium": "Villa Park",
      "venue": "Birmingham"
    },
    {
      "id": 2049604,
      "matchday": 3,
      "gdId": 7,
      "date": "2026-10-22",
      "weekday": "Thu",
      "time": "03:00",
      "datetime": "2026-10-22T03:00:00+08:00",
      "home": {
        "id": 52265,
        "code": "BET",
        "name": "Real Betis"
      },
      "away": {
        "id": 52749,
        "code": "FEY",
        "name": "Feyenoord"
      },
      "stadium": "LA CARTUJA DE SEVILLA",
      "venue": "Seville"
    },
    {
      "id": 2049613,
      "matchday": 4,
      "gdId": 8,
      "date": "2026-11-04",
      "weekday": "Wed",
      "time": "01:45",
      "datetime": "2026-11-04T01:45:00+08:00",
      "home": {
        "id": 52707,
        "code": "SHK",
        "name": "Shakhtar"
      },
      "away": {
        "id": 50149,
        "code": "SPO",
        "name": "Sporting CP"
      },
      "stadium": "Stamford Bridge",
      "venue": "London"
    },
    {
      "id": 2049614,
      "matchday": 4,
      "gdId": 8,
      "date": "2026-11-04",
      "weekday": "Wed",
      "time": "01:45",
      "datetime": "2026-11-04T01:45:00+08:00",
      "home": {
        "id": 50067,
        "code": "GAL",
        "name": "Galatasaray"
      },
      "away": {
        "id": 50107,
        "code": "STU",
        "name": "Stuttgart"
      },
      "stadium": "Ali Sami Yen Spor Kompleksi",
      "venue": "Istanbul"
    },
    {
      "id": 2049608,
      "matchday": 4,
      "gdId": 8,
      "date": "2026-11-04",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-04T04:00:00+08:00",
      "home": {
        "id": 50124,
        "code": "ATM",
        "name": "Atleti"
      },
      "away": {
        "id": 50037,
        "code": "BAY",
        "name": "Bayern München"
      },
      "stadium": "Estadio Metropolitano",
      "venue": "Madrid"
    },
    {
      "id": 2049612,
      "matchday": 4,
      "gdId": 8,
      "date": "2026-11-04",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-04T04:00:00+08:00",
      "home": {
        "id": 70691,
        "code": "VIL",
        "name": "Villarreal"
      },
      "away": {
        "id": 52747,
        "code": "PSG",
        "name": "Paris"
      },
      "stadium": "Estadio de la Cerámica",
      "venue": "Villarreal"
    },
    {
      "id": 2049607,
      "matchday": 4,
      "gdId": 8,
      "date": "2026-11-04",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-04T04:00:00+08:00",
      "home": {
        "id": 50080,
        "code": "BAR",
        "name": "Barcelona"
      },
      "away": {
        "id": 52683,
        "code": "AVL",
        "name": "Aston Villa"
      },
      "stadium": "Camp Nou",
      "venue": "Barcelona"
    },
    {
      "id": 2049609,
      "matchday": 4,
      "gdId": 8,
      "date": "2026-11-04",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-04T04:00:00+08:00",
      "home": {
        "id": 52682,
        "code": "MUN",
        "name": "Man Utd"
      },
      "away": {
        "id": 50137,
        "code": "ROM",
        "name": "Roma"
      },
      "stadium": "Old Trafford",
      "venue": "Manchester"
    },
    {
      "id": 2049610,
      "matchday": 4,
      "gdId": 8,
      "date": "2026-11-04",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-04T04:00:00+08:00",
      "home": {
        "id": 52749,
        "code": "FEY",
        "name": "Feyenoord"
      },
      "away": {
        "id": 50138,
        "code": "INT",
        "name": "Inter"
      },
      "stadium": "Stadion Feijenoord 'De Kuip'",
      "venue": "Rotterdam"
    },
    {
      "id": 2049611,
      "matchday": 4,
      "gdId": 8,
      "date": "2026-11-04",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-04T04:00:00+08:00",
      "home": {
        "id": 59333,
        "code": "BOD",
        "name": "Bodø/Glimt"
      },
      "away": {
        "id": 75797,
        "code": "LIL",
        "name": "Lille"
      },
      "stadium": "Aspmyra",
      "venue": "Bodø"
    },
    {
      "id": 2049615,
      "matchday": 4,
      "gdId": 8,
      "date": "2026-11-04",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-04T04:00:00+08:00",
      "home": {
        "id": 63405,
        "code": "LASK",
        "name": "LASK"
      },
      "away": {
        "id": 52797,
        "code": "SBR",
        "name": "S. Bratislava"
      },
      "stadium": "Oberösterreich Arena",
      "venue": "Linz"
    },
    {
      "id": 2049622,
      "matchday": 4,
      "gdId": 9,
      "date": "2026-11-05",
      "weekday": "Thu",
      "time": "01:45",
      "datetime": "2026-11-05T01:45:00+08:00",
      "home": {
        "id": 50129,
        "code": "AEK",
        "name": "AEK Athens"
      },
      "away": {
        "id": 50051,
        "code": "RMA",
        "name": "Real Madrid"
      },
      "stadium": "AEK Arena",
      "venue": "Athens"
    },
    {
      "id": 2049620,
      "matchday": 4,
      "gdId": 9,
      "date": "2026-11-05",
      "weekday": "Thu",
      "time": "01:45",
      "datetime": "2026-11-05T01:45:00+08:00",
      "home": {
        "id": 52692,
        "code": "FEN",
        "name": "Fenerbahçe"
      },
      "away": {
        "id": 7889,
        "code": "LIV",
        "name": "Liverpool"
      },
      "stadium": "Fenerbahçe Şükrü Saracoğlu Spor Kompleksi",
      "venue": "Istanbul"
    },
    {
      "id": 2049617,
      "matchday": 4,
      "gdId": 9,
      "date": "2026-11-05",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-05T04:00:00+08:00",
      "home": {
        "id": 50064,
        "code": "POR",
        "name": "Porto"
      },
      "away": {
        "id": 50136,
        "code": "NAP",
        "name": "Napoli"
      },
      "stadium": "Estádio do Dragão",
      "venue": "Porto"
    },
    {
      "id": 2049624,
      "matchday": 4,
      "gdId": 9,
      "date": "2026-11-05",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-05T04:00:00+08:00",
      "home": {
        "id": 52319,
        "code": "VFK",
        "name": "Viking"
      },
      "away": {
        "id": 2609356,
        "code": "SAB",
        "name": "Sabah"
      },
      "stadium": "Viking stadion",
      "venue": "Stavanger"
    },
    {
      "id": 2049619,
      "matchday": 4,
      "gdId": 9,
      "date": "2026-11-05",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-05T04:00:00+08:00",
      "home": {
        "id": 2603790,
        "code": "RBL",
        "name": "Leipzig"
      },
      "away": {
        "id": 52919,
        "code": "MCI",
        "name": "Man City"
      },
      "stadium": "RB Arena",
      "venue": "Leipzig"
    },
    {
      "id": 2049621,
      "matchday": 4,
      "gdId": 9,
      "date": "2026-11-05",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-05T04:00:00+08:00",
      "home": {
        "id": 52498,
        "code": "SLA",
        "name": "Slavia Praha"
      },
      "away": {
        "id": 52280,
        "code": "ARS",
        "name": "Arsenal"
      },
      "stadium": "Eden Arena",
      "venue": "Prague"
    },
    {
      "id": 2049623,
      "matchday": 4,
      "gdId": 9,
      "date": "2026-11-05",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-05T04:00:00+08:00",
      "home": {
        "id": 52277,
        "code": "LEN",
        "name": "Lens"
      },
      "away": {
        "id": 79946,
        "code": "COM",
        "name": "Como"
      },
      "stadium": "Stade Bollaert-Delelis",
      "venue": "Lens Agglo"
    },
    {
      "id": 2049618,
      "matchday": 4,
      "gdId": 9,
      "date": "2026-11-05",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-05T04:00:00+08:00",
      "home": {
        "id": 50062,
        "code": "PSV",
        "name": "PSV"
      },
      "away": {
        "id": 50043,
        "code": "BRU",
        "name": "Club Brugge"
      },
      "stadium": "PSV Stadion",
      "venue": "Eindhoven"
    },
    {
      "id": 2049616,
      "matchday": 4,
      "gdId": 9,
      "date": "2026-11-05",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-05T04:00:00+08:00",
      "home": {
        "id": 52758,
        "code": "BVB",
        "name": "B. Dortmund"
      },
      "away": {
        "id": 52265,
        "code": "BET",
        "name": "Real Betis"
      },
      "stadium": "BVB Stadion Dortmund",
      "venue": "Dortmund"
    },
    {
      "id": 2049629,
      "matchday": 5,
      "gdId": 10,
      "date": "2026-11-25",
      "weekday": "Wed",
      "time": "01:45",
      "datetime": "2026-11-25T01:45:00+08:00",
      "home": {
        "id": 59333,
        "code": "BOD",
        "name": "Bodø/Glimt"
      },
      "away": {
        "id": 63405,
        "code": "LASK",
        "name": "LASK"
      },
      "stadium": "Aspmyra",
      "venue": "Bodø"
    },
    {
      "id": 2049631,
      "matchday": 5,
      "gdId": 10,
      "date": "2026-11-25",
      "weekday": "Wed",
      "time": "01:45",
      "datetime": "2026-11-25T01:45:00+08:00",
      "home": {
        "id": 50067,
        "code": "GAL",
        "name": "Galatasaray"
      },
      "away": {
        "id": 52683,
        "code": "AVL",
        "name": "Aston Villa"
      },
      "stadium": "Ali Sami Yen Spor Kompleksi",
      "venue": "Istanbul"
    },
    {
      "id": 2049632,
      "matchday": 5,
      "gdId": 10,
      "date": "2026-11-25",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-25T04:00:00+08:00",
      "home": {
        "id": 52797,
        "code": "SBR",
        "name": "S. Bratislava"
      },
      "away": {
        "id": 52265,
        "code": "BET",
        "name": "Real Betis"
      },
      "stadium": "Národný futbalový štadión ",
      "venue": "Bratislava"
    },
    {
      "id": 2049627,
      "matchday": 5,
      "gdId": 10,
      "date": "2026-11-25",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-25T04:00:00+08:00",
      "home": {
        "id": 52280,
        "code": "ARS",
        "name": "Arsenal"
      },
      "away": {
        "id": 52758,
        "code": "BVB",
        "name": "B. Dortmund"
      },
      "stadium": "Arsenal Stadium",
      "venue": "London"
    },
    {
      "id": 2049630,
      "matchday": 5,
      "gdId": 10,
      "date": "2026-11-25",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-25T04:00:00+08:00",
      "home": {
        "id": 2603790,
        "code": "RBL",
        "name": "Leipzig"
      },
      "away": {
        "id": 52277,
        "code": "LEN",
        "name": "Lens"
      },
      "stadium": "RB Arena",
      "venue": "Leipzig"
    },
    {
      "id": 2049628,
      "matchday": 5,
      "gdId": 10,
      "date": "2026-11-25",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-25T04:00:00+08:00",
      "home": {
        "id": 52749,
        "code": "FEY",
        "name": "Feyenoord"
      },
      "away": {
        "id": 50064,
        "code": "POR",
        "name": "Porto"
      },
      "stadium": "Stadion Feijenoord 'De Kuip'",
      "venue": "Rotterdam"
    },
    {
      "id": 2049626,
      "matchday": 5,
      "gdId": 10,
      "date": "2026-11-25",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-25T04:00:00+08:00",
      "home": {
        "id": 52919,
        "code": "MCI",
        "name": "Man City"
      },
      "away": {
        "id": 50136,
        "code": "NAP",
        "name": "Napoli"
      },
      "stadium": "City of Manchester Stadium",
      "venue": "Manchester"
    },
    {
      "id": 2049625,
      "matchday": 5,
      "gdId": 10,
      "date": "2026-11-25",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-25T04:00:00+08:00",
      "home": {
        "id": 50051,
        "code": "RMA",
        "name": "Real Madrid"
      },
      "away": {
        "id": 50062,
        "code": "PSV",
        "name": "PSV"
      },
      "stadium": "Estadio Santiago Bernabéu",
      "venue": "Madrid"
    },
    {
      "id": 2049633,
      "matchday": 5,
      "gdId": 10,
      "date": "2026-11-25",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-11-25T04:00:00+08:00",
      "home": {
        "id": 79946,
        "code": "COM",
        "name": "Como"
      },
      "away": {
        "id": 50129,
        "code": "AEK",
        "name": "AEK Athens"
      },
      "stadium": "Giuseppe Sinigaglia",
      "venue": "Como"
    },
    {
      "id": 2049642,
      "matchday": 5,
      "gdId": 11,
      "date": "2026-11-26",
      "weekday": "Thu",
      "time": "01:45",
      "datetime": "2026-11-26T01:45:00+08:00",
      "home": {
        "id": 2609356,
        "code": "SAB",
        "name": "Sabah"
      },
      "away": {
        "id": 50080,
        "code": "BAR",
        "name": "Barcelona"
      },
      "stadium": "",
      "venue": ""
    },
    {
      "id": 2049641,
      "matchday": 5,
      "gdId": 11,
      "date": "2026-11-26",
      "weekday": "Thu",
      "time": "01:45",
      "datetime": "2026-11-26T01:45:00+08:00",
      "home": {
        "id": 52498,
        "code": "SLA",
        "name": "Slavia Praha"
      },
      "away": {
        "id": 70691,
        "code": "VIL",
        "name": "Villarreal"
      },
      "stadium": "Eden Arena",
      "venue": "Prague"
    },
    {
      "id": 2049640,
      "matchday": 5,
      "gdId": 11,
      "date": "2026-11-26",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-26T04:00:00+08:00",
      "home": {
        "id": 52707,
        "code": "SHK",
        "name": "Shakhtar"
      },
      "away": {
        "id": 52692,
        "code": "FEN",
        "name": "Fenerbahçe"
      },
      "stadium": "Stamford Bridge",
      "venue": "London"
    },
    {
      "id": 2049634,
      "matchday": 5,
      "gdId": 11,
      "date": "2026-11-26",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-26T04:00:00+08:00",
      "home": {
        "id": 52747,
        "code": "PSG",
        "name": "Paris"
      },
      "away": {
        "id": 50137,
        "code": "ROM",
        "name": "Roma"
      },
      "stadium": "Parc des Princes",
      "venue": "Paris"
    },
    {
      "id": 2049635,
      "matchday": 5,
      "gdId": 11,
      "date": "2026-11-26",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-26T04:00:00+08:00",
      "home": {
        "id": 50138,
        "code": "INT",
        "name": "Inter"
      },
      "away": {
        "id": 50107,
        "code": "STU",
        "name": "Stuttgart"
      },
      "stadium": "Stadio San Siro",
      "venue": "Milan"
    },
    {
      "id": 2049636,
      "matchday": 5,
      "gdId": 11,
      "date": "2026-11-26",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-26T04:00:00+08:00",
      "home": {
        "id": 50124,
        "code": "ATM",
        "name": "Atleti"
      },
      "away": {
        "id": 52319,
        "code": "VFK",
        "name": "Viking"
      },
      "stadium": "Estadio Metropolitano",
      "venue": "Madrid"
    },
    {
      "id": 2049637,
      "matchday": 5,
      "gdId": 11,
      "date": "2026-11-26",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-26T04:00:00+08:00",
      "home": {
        "id": 50149,
        "code": "SPO",
        "name": "Sporting CP"
      },
      "away": {
        "id": 52682,
        "code": "MUN",
        "name": "Man Utd"
      },
      "stadium": "Estádio José Alvalade",
      "venue": "Lisbon"
    },
    {
      "id": 2049638,
      "matchday": 5,
      "gdId": 11,
      "date": "2026-11-26",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-26T04:00:00+08:00",
      "home": {
        "id": 50043,
        "code": "BRU",
        "name": "Club Brugge"
      },
      "away": {
        "id": 7889,
        "code": "LIV",
        "name": "Liverpool"
      },
      "stadium": "Jan Breydelstadion",
      "venue": "Bruges"
    },
    {
      "id": 2049639,
      "matchday": 5,
      "gdId": 11,
      "date": "2026-11-26",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-11-26T04:00:00+08:00",
      "home": {
        "id": 75797,
        "code": "LIL",
        "name": "Lille"
      },
      "away": {
        "id": 50037,
        "code": "BAY",
        "name": "Bayern München"
      },
      "stadium": "Stade Pierre Mauroy",
      "venue": "Villeneuve d'Ascq"
    },
    {
      "id": 2049651,
      "matchday": 6,
      "gdId": 12,
      "date": "2026-12-09",
      "weekday": "Wed",
      "time": "01:45",
      "datetime": "2026-12-09T01:45:00+08:00",
      "home": {
        "id": 52319,
        "code": "VFK",
        "name": "Viking"
      },
      "away": {
        "id": 52749,
        "code": "FEY",
        "name": "Feyenoord"
      },
      "stadium": "Viking stadion",
      "venue": "Stavanger"
    },
    {
      "id": 2049649,
      "matchday": 6,
      "gdId": 12,
      "date": "2026-12-09",
      "weekday": "Wed",
      "time": "01:45",
      "datetime": "2026-12-09T01:45:00+08:00",
      "home": {
        "id": 70691,
        "code": "VIL",
        "name": "Villarreal"
      },
      "away": {
        "id": 2609356,
        "code": "SAB",
        "name": "Sabah"
      },
      "stadium": "Estadio de la Cerámica",
      "venue": "Villarreal"
    },
    {
      "id": 2049643,
      "matchday": 6,
      "gdId": 12,
      "date": "2026-12-09",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-12-09T04:00:00+08:00",
      "home": {
        "id": 50037,
        "code": "BAY",
        "name": "Bayern München"
      },
      "away": {
        "id": 52498,
        "code": "SLA",
        "name": "Slavia Praha"
      },
      "stadium": "Fußball Arena München",
      "venue": "Munich"
    },
    {
      "id": 2049644,
      "matchday": 6,
      "gdId": 12,
      "date": "2026-12-09",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-12-09T04:00:00+08:00",
      "home": {
        "id": 50080,
        "code": "BAR",
        "name": "Barcelona"
      },
      "away": {
        "id": 52919,
        "code": "MCI",
        "name": "Man City"
      },
      "stadium": "Camp Nou",
      "venue": "Barcelona"
    },
    {
      "id": 2049645,
      "matchday": 6,
      "gdId": 12,
      "date": "2026-12-09",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-12-09T04:00:00+08:00",
      "home": {
        "id": 50137,
        "code": "ROM",
        "name": "Roma"
      },
      "away": {
        "id": 50149,
        "code": "SPO",
        "name": "Sporting CP"
      },
      "stadium": "Stadio Olimpico",
      "venue": "Rome"
    },
    {
      "id": 2049646,
      "matchday": 6,
      "gdId": 12,
      "date": "2026-12-09",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-12-09T04:00:00+08:00",
      "home": {
        "id": 52683,
        "code": "AVL",
        "name": "Aston Villa"
      },
      "away": {
        "id": 52747,
        "code": "PSG",
        "name": "Paris"
      },
      "stadium": "Villa Park",
      "venue": "Birmingham"
    },
    {
      "id": 2049647,
      "matchday": 6,
      "gdId": 12,
      "date": "2026-12-09",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-12-09T04:00:00+08:00",
      "home": {
        "id": 52682,
        "code": "MUN",
        "name": "Man Utd"
      },
      "away": {
        "id": 2603790,
        "code": "RBL",
        "name": "Leipzig"
      },
      "stadium": "Old Trafford",
      "venue": "Manchester"
    },
    {
      "id": 2049648,
      "matchday": 6,
      "gdId": 12,
      "date": "2026-12-09",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-12-09T04:00:00+08:00",
      "home": {
        "id": 50136,
        "code": "NAP",
        "name": "Napoli"
      },
      "away": {
        "id": 50043,
        "code": "BRU",
        "name": "Club Brugge"
      },
      "stadium": "Stadio Diego Armando Maradona",
      "venue": "Naples"
    },
    {
      "id": 2049650,
      "matchday": 6,
      "gdId": 12,
      "date": "2026-12-09",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2026-12-09T04:00:00+08:00",
      "home": {
        "id": 50129,
        "code": "AEK",
        "name": "AEK Athens"
      },
      "away": {
        "id": 50067,
        "code": "GAL",
        "name": "Galatasaray"
      },
      "stadium": "AEK Arena",
      "venue": "Athens"
    },
    {
      "id": 2049655,
      "matchday": 6,
      "gdId": 13,
      "date": "2026-12-10",
      "weekday": "Thu",
      "time": "01:45",
      "datetime": "2026-12-10T01:45:00+08:00",
      "home": {
        "id": 52265,
        "code": "BET",
        "name": "Real Betis"
      },
      "away": {
        "id": 79946,
        "code": "COM",
        "name": "Como"
      },
      "stadium": "LA CARTUJA DE SEVILLA",
      "venue": "Seville"
    },
    {
      "id": 2049657,
      "matchday": 6,
      "gdId": 13,
      "date": "2026-12-10",
      "weekday": "Thu",
      "time": "01:45",
      "datetime": "2026-12-10T01:45:00+08:00",
      "home": {
        "id": 52797,
        "code": "SBR",
        "name": "S. Bratislava"
      },
      "away": {
        "id": 52707,
        "code": "SHK",
        "name": "Shakhtar"
      },
      "stadium": "Národný futbalový štadión ",
      "venue": "Bratislava"
    },
    {
      "id": 2049652,
      "matchday": 6,
      "gdId": 13,
      "date": "2026-12-10",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-12-10T04:00:00+08:00",
      "home": {
        "id": 7889,
        "code": "LIV",
        "name": "Liverpool"
      },
      "away": {
        "id": 50064,
        "code": "POR",
        "name": "Porto"
      },
      "stadium": "Anfield",
      "venue": "Liverpool"
    },
    {
      "id": 2049653,
      "matchday": 6,
      "gdId": 13,
      "date": "2026-12-10",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-12-10T04:00:00+08:00",
      "home": {
        "id": 52280,
        "code": "ARS",
        "name": "Arsenal"
      },
      "away": {
        "id": 50051,
        "code": "RMA",
        "name": "Real Madrid"
      },
      "stadium": "Arsenal Stadium",
      "venue": "London"
    },
    {
      "id": 2049654,
      "matchday": 6,
      "gdId": 13,
      "date": "2026-12-10",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-12-10T04:00:00+08:00",
      "home": {
        "id": 52758,
        "code": "BVB",
        "name": "B. Dortmund"
      },
      "away": {
        "id": 50138,
        "code": "INT",
        "name": "Inter"
      },
      "stadium": "BVB Stadion Dortmund",
      "venue": "Dortmund"
    },
    {
      "id": 2049656,
      "matchday": 6,
      "gdId": 13,
      "date": "2026-12-10",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-12-10T04:00:00+08:00",
      "home": {
        "id": 50062,
        "code": "PSV",
        "name": "PSV"
      },
      "away": {
        "id": 50124,
        "code": "ATM",
        "name": "Atleti"
      },
      "stadium": "PSV Stadion",
      "venue": "Eindhoven"
    },
    {
      "id": 2049658,
      "matchday": 6,
      "gdId": 13,
      "date": "2026-12-10",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-12-10T04:00:00+08:00",
      "home": {
        "id": 50107,
        "code": "STU",
        "name": "Stuttgart"
      },
      "away": {
        "id": 75797,
        "code": "LIL",
        "name": "Lille"
      },
      "stadium": "Arena Stuttgart",
      "venue": "Stuttgart"
    },
    {
      "id": 2049659,
      "matchday": 6,
      "gdId": 13,
      "date": "2026-12-10",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-12-10T04:00:00+08:00",
      "home": {
        "id": 63405,
        "code": "LASK",
        "name": "LASK"
      },
      "away": {
        "id": 52692,
        "code": "FEN",
        "name": "Fenerbahçe"
      },
      "stadium": "Oberösterreich Arena",
      "venue": "Linz"
    },
    {
      "id": 2049660,
      "matchday": 6,
      "gdId": 13,
      "date": "2026-12-10",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2026-12-10T04:00:00+08:00",
      "home": {
        "id": 52277,
        "code": "LEN",
        "name": "Lens"
      },
      "away": {
        "id": 59333,
        "code": "BOD",
        "name": "Bodø/Glimt"
      },
      "stadium": "Stade Bollaert-Delelis",
      "venue": "Lens Agglo"
    },
    {
      "id": 2049666,
      "matchday": 7,
      "gdId": 14,
      "date": "2027-01-20",
      "weekday": "Wed",
      "time": "01:45",
      "datetime": "2027-01-20T01:45:00+08:00",
      "home": {
        "id": 59333,
        "code": "BOD",
        "name": "Bodø/Glimt"
      },
      "away": {
        "id": 50124,
        "code": "ATM",
        "name": "Atleti"
      },
      "stadium": "Aspmyra",
      "venue": "Bodø"
    },
    {
      "id": 2049667,
      "matchday": 7,
      "gdId": 14,
      "date": "2027-01-20",
      "weekday": "Wed",
      "time": "01:45",
      "datetime": "2027-01-20T01:45:00+08:00",
      "home": {
        "id": 50067,
        "code": "GAL",
        "name": "Galatasaray"
      },
      "away": {
        "id": 52749,
        "code": "FEY",
        "name": "Feyenoord"
      },
      "stadium": "Ali Sami Yen Spor Kompleksi",
      "venue": "Istanbul"
    },
    {
      "id": 2049664,
      "matchday": 7,
      "gdId": 14,
      "date": "2027-01-20",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2027-01-20T04:00:00+08:00",
      "home": {
        "id": 50064,
        "code": "POR",
        "name": "Porto"
      },
      "away": {
        "id": 52498,
        "code": "SLA",
        "name": "Slavia Praha"
      },
      "stadium": "Estádio do Dragão",
      "venue": "Porto"
    },
    {
      "id": 2049665,
      "matchday": 7,
      "gdId": 14,
      "date": "2027-01-20",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2027-01-20T04:00:00+08:00",
      "home": {
        "id": 75797,
        "code": "LIL",
        "name": "Lille"
      },
      "away": {
        "id": 52797,
        "code": "SBR",
        "name": "S. Bratislava"
      },
      "stadium": "Stade Pierre Mauroy",
      "venue": "Villeneuve d'Ascq"
    },
    {
      "id": 2049668,
      "matchday": 7,
      "gdId": 14,
      "date": "2027-01-20",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2027-01-20T04:00:00+08:00",
      "home": {
        "id": 50107,
        "code": "STU",
        "name": "Stuttgart"
      },
      "away": {
        "id": 50043,
        "code": "BRU",
        "name": "Club Brugge"
      },
      "stadium": "Arena Stuttgart",
      "venue": "Stuttgart"
    },
    {
      "id": 2049669,
      "matchday": 7,
      "gdId": 14,
      "date": "2027-01-20",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2027-01-20T04:00:00+08:00",
      "home": {
        "id": 50129,
        "code": "AEK",
        "name": "AEK Athens"
      },
      "away": {
        "id": 50137,
        "code": "ROM",
        "name": "Roma"
      },
      "stadium": "AEK Arena",
      "venue": "Athens"
    },
    {
      "id": 2049661,
      "matchday": 7,
      "gdId": 14,
      "date": "2027-01-20",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2027-01-20T04:00:00+08:00",
      "home": {
        "id": 50051,
        "code": "RMA",
        "name": "Real Madrid"
      },
      "away": {
        "id": 63405,
        "code": "LASK",
        "name": "LASK"
      },
      "stadium": "Estadio Santiago Bernabéu",
      "venue": "Madrid"
    },
    {
      "id": 2049662,
      "matchday": 7,
      "gdId": 14,
      "date": "2027-01-20",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2027-01-20T04:00:00+08:00",
      "home": {
        "id": 50138,
        "code": "INT",
        "name": "Inter"
      },
      "away": {
        "id": 7889,
        "code": "LIV",
        "name": "Liverpool"
      },
      "stadium": "Stadio San Siro",
      "venue": "Milan"
    },
    {
      "id": 2049663,
      "matchday": 7,
      "gdId": 14,
      "date": "2027-01-20",
      "weekday": "Wed",
      "time": "04:00",
      "datetime": "2027-01-20T04:00:00+08:00",
      "home": {
        "id": 52683,
        "code": "AVL",
        "name": "Aston Villa"
      },
      "away": {
        "id": 52758,
        "code": "BVB",
        "name": "B. Dortmund"
      },
      "stadium": "Villa Park",
      "venue": "Birmingham"
    },
    {
      "id": 2049678,
      "matchday": 7,
      "gdId": 15,
      "date": "2027-01-21",
      "weekday": "Thu",
      "time": "01:45",
      "datetime": "2027-01-21T01:45:00+08:00",
      "home": {
        "id": 2609356,
        "code": "SAB",
        "name": "Sabah"
      },
      "away": {
        "id": 50136,
        "code": "NAP",
        "name": "Napoli"
      },
      "stadium": "",
      "venue": ""
    },
    {
      "id": 2049674,
      "matchday": 7,
      "gdId": 15,
      "date": "2027-01-21",
      "weekday": "Thu",
      "time": "01:45",
      "datetime": "2027-01-21T01:45:00+08:00",
      "home": {
        "id": 52692,
        "code": "FEN",
        "name": "Fenerbahçe"
      },
      "away": {
        "id": 70691,
        "code": "VIL",
        "name": "Villarreal"
      },
      "stadium": "Fenerbahçe Şükrü Saracoğlu Spor Kompleksi",
      "venue": "Istanbul"
    },
    {
      "id": 2049673,
      "matchday": 7,
      "gdId": 15,
      "date": "2027-01-21",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-21T04:00:00+08:00",
      "home": {
        "id": 2603790,
        "code": "RBL",
        "name": "Leipzig"
      },
      "away": {
        "id": 52707,
        "code": "SHK",
        "name": "Shakhtar"
      },
      "stadium": "RB Arena",
      "venue": "Leipzig"
    },
    {
      "id": 2049675,
      "matchday": 7,
      "gdId": 15,
      "date": "2027-01-21",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-21T04:00:00+08:00",
      "home": {
        "id": 79946,
        "code": "COM",
        "name": "Como"
      },
      "away": {
        "id": 52747,
        "code": "PSG",
        "name": "Paris"
      },
      "stadium": "Giuseppe Sinigaglia",
      "venue": "Como"
    },
    {
      "id": 2049676,
      "matchday": 7,
      "gdId": 15,
      "date": "2027-01-21",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-21T04:00:00+08:00",
      "home": {
        "id": 52277,
        "code": "LEN",
        "name": "Lens"
      },
      "away": {
        "id": 52919,
        "code": "MCI",
        "name": "Man City"
      },
      "stadium": "Stade Bollaert-Delelis",
      "venue": "Lens Agglo"
    },
    {
      "id": 2049677,
      "matchday": 7,
      "gdId": 15,
      "date": "2027-01-21",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-21T04:00:00+08:00",
      "home": {
        "id": 52319,
        "code": "VFK",
        "name": "Viking"
      },
      "away": {
        "id": 50062,
        "code": "PSV",
        "name": "PSV"
      },
      "stadium": "Viking stadion",
      "venue": "Stavanger"
    },
    {
      "id": 2049671,
      "matchday": 7,
      "gdId": 15,
      "date": "2027-01-21",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-21T04:00:00+08:00",
      "home": {
        "id": 52682,
        "code": "MUN",
        "name": "Man Utd"
      },
      "away": {
        "id": 50037,
        "code": "BAY",
        "name": "Bayern München"
      },
      "stadium": "Old Trafford",
      "venue": "Manchester"
    },
    {
      "id": 2049670,
      "matchday": 7,
      "gdId": 15,
      "date": "2027-01-21",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-21T04:00:00+08:00",
      "home": {
        "id": 50149,
        "code": "SPO",
        "name": "Sporting CP"
      },
      "away": {
        "id": 50080,
        "code": "BAR",
        "name": "Barcelona"
      },
      "stadium": "Estádio José Alvalade",
      "venue": "Lisbon"
    },
    {
      "id": 2049672,
      "matchday": 7,
      "gdId": 15,
      "date": "2027-01-21",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-21T04:00:00+08:00",
      "home": {
        "id": 52265,
        "code": "BET",
        "name": "Real Betis"
      },
      "away": {
        "id": 52280,
        "code": "ARS",
        "name": "Arsenal"
      },
      "stadium": "LA CARTUJA DE SEVILLA",
      "venue": "Seville"
    },
    {
      "id": 2049694,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 52498,
        "code": "SLA",
        "name": "Slavia Praha"
      },
      "away": {
        "id": 52683,
        "code": "AVL",
        "name": "Aston Villa"
      },
      "stadium": "Eden Arena",
      "venue": "Prague"
    },
    {
      "id": 2049696,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 63405,
        "code": "LASK",
        "name": "LASK"
      },
      "away": {
        "id": 50064,
        "code": "POR",
        "name": "Porto"
      },
      "stadium": "Oberösterreich Arena",
      "venue": "Linz"
    },
    {
      "id": 2049680,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 50037,
        "code": "BAY",
        "name": "Bayern München"
      },
      "away": {
        "id": 52265,
        "code": "BET",
        "name": "Real Betis"
      },
      "stadium": "Fußball Arena München",
      "venue": "Munich"
    },
    {
      "id": 2049679,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 52747,
        "code": "PSG",
        "name": "Paris"
      },
      "away": {
        "id": 50067,
        "code": "GAL",
        "name": "Galatasaray"
      },
      "stadium": "Parc des Princes",
      "venue": "Paris"
    },
    {
      "id": 2049695,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 52797,
        "code": "SBR",
        "name": "S. Bratislava"
      },
      "away": {
        "id": 50138,
        "code": "INT",
        "name": "Inter"
      },
      "stadium": "Národný futbalový štadión ",
      "venue": "Bratislava"
    },
    {
      "id": 2049681,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 7889,
        "code": "LIV",
        "name": "Liverpool"
      },
      "away": {
        "id": 52277,
        "code": "LEN",
        "name": "Lens"
      },
      "stadium": "Anfield",
      "venue": "Liverpool"
    },
    {
      "id": 2049682,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 52919,
        "code": "MCI",
        "name": "Man City"
      },
      "away": {
        "id": 50149,
        "code": "SPO",
        "name": "Sporting CP"
      },
      "stadium": "City of Manchester Stadium",
      "venue": "Manchester"
    },
    {
      "id": 2049683,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 52280,
        "code": "ARS",
        "name": "Arsenal"
      },
      "away": {
        "id": 2609356,
        "code": "SAB",
        "name": "Sabah"
      },
      "stadium": "Arsenal Stadium",
      "venue": "London"
    },
    {
      "id": 2049684,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 50080,
        "code": "BAR",
        "name": "Barcelona"
      },
      "away": {
        "id": 79946,
        "code": "COM",
        "name": "Como"
      },
      "stadium": "Camp Nou",
      "venue": "Barcelona"
    },
    {
      "id": 2049685,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 50124,
        "code": "ATM",
        "name": "Atleti"
      },
      "away": {
        "id": 52692,
        "code": "FEN",
        "name": "Fenerbahçe"
      },
      "stadium": "Estadio Metropolitano",
      "venue": "Madrid"
    },
    {
      "id": 2049686,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 52758,
        "code": "BVB",
        "name": "B. Dortmund"
      },
      "away": {
        "id": 50129,
        "code": "AEK",
        "name": "AEK Athens"
      },
      "stadium": "BVB Stadion Dortmund",
      "venue": "Dortmund"
    },
    {
      "id": 2049687,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 50137,
        "code": "ROM",
        "name": "Roma"
      },
      "away": {
        "id": 75797,
        "code": "LIL",
        "name": "Lille"
      },
      "stadium": "Stadio Olimpico",
      "venue": "Rome"
    },
    {
      "id": 2049688,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 50043,
        "code": "BRU",
        "name": "Club Brugge"
      },
      "away": {
        "id": 59333,
        "code": "BOD",
        "name": "Bodø/Glimt"
      },
      "stadium": "Jan Breydelstadion",
      "venue": "Bruges"
    },
    {
      "id": 2049689,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 50062,
        "code": "PSV",
        "name": "PSV"
      },
      "away": {
        "id": 50107,
        "code": "STU",
        "name": "Stuttgart"
      },
      "stadium": "PSV Stadion",
      "venue": "Eindhoven"
    },
    {
      "id": 2049690,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 52749,
        "code": "FEY",
        "name": "Feyenoord"
      },
      "away": {
        "id": 2603790,
        "code": "RBL",
        "name": "Leipzig"
      },
      "stadium": "Stadion Feijenoord 'De Kuip'",
      "venue": "Rotterdam"
    },
    {
      "id": 2049691,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 50136,
        "code": "NAP",
        "name": "Napoli"
      },
      "away": {
        "id": 52319,
        "code": "VFK",
        "name": "Viking"
      },
      "stadium": "Stadio Diego Armando Maradona",
      "venue": "Naples"
    },
    {
      "id": 2049692,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 70691,
        "code": "VIL",
        "name": "Villarreal"
      },
      "away": {
        "id": 52682,
        "code": "MUN",
        "name": "Man Utd"
      },
      "stadium": "Estadio de la Cerámica",
      "venue": "Villarreal"
    },
    {
      "id": 2049693,
      "matchday": 8,
      "gdId": 16,
      "date": "2027-01-28",
      "weekday": "Thu",
      "time": "04:00",
      "datetime": "2027-01-28T04:00:00+08:00",
      "home": {
        "id": 52707,
        "code": "SHK",
        "name": "Shakhtar"
      },
      "away": {
        "id": 50051,
        "code": "RMA",
        "name": "Real Madrid"
      },
      "stadium": "Stamford Bridge",
      "venue": "London"
    }
  ],
  "teams": {
    "AEK": {
      "id": 50129,
      "code": "AEK",
      "name": "AEK Athens",
      "pot": "Pot 4",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049558,
          "day": 1,
          "date": "2026-09-09",
          "time": "00:45",
          "datetime": "2026-09-09T00:45:00+08:00",
          "opponent": "LASK",
          "opponentName": "LASK",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049586,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "SHK",
          "opponentName": "Shakhtar",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049591,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "MCI",
          "opponentName": "Man City",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049622,
          "day": 2,
          "date": "2026-11-05",
          "time": "01:45",
          "datetime": "2026-11-05T01:45:00+08:00",
          "opponent": "RMA",
          "opponentName": "Real Madrid",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049633,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "COM",
          "opponentName": "Como",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049650,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "GAL",
          "opponentName": "Galatasaray",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049669,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "ROM",
          "opponentName": "Roma",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049686,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "BVB",
          "opponentName": "B. Dortmund",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "LASK": {
      "id": 63405,
      "code": "LASK",
      "name": "LASK",
      "pot": "Pot 4",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049558,
          "day": 1,
          "date": "2026-09-09",
          "time": "00:45",
          "datetime": "2026-09-09T00:45:00+08:00",
          "opponent": "AEK",
          "opponentName": "AEK Athens",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049588,
          "day": 2,
          "date": "2026-10-15",
          "time": "00:45",
          "datetime": "2026-10-15T00:45:00+08:00",
          "opponent": "LIV",
          "opponentName": "Liverpool",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049601,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "SPO",
          "opponentName": "Sporting CP",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049615,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "SBR",
          "opponentName": "S. Bratislava",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049629,
          "day": 1,
          "date": "2026-11-25",
          "time": "01:45",
          "datetime": "2026-11-25T01:45:00+08:00",
          "opponent": "BOD",
          "opponentName": "Bodø/Glimt",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049659,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "FEN",
          "opponentName": "Fenerbahçe",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049661,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "RMA",
          "opponentName": "Real Madrid",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049696,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "POR",
          "opponentName": "Porto",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "BRU": {
      "id": 50043,
      "code": "BRU",
      "name": "Club Brugge",
      "pot": "Pot 2",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049556,
          "day": 1,
          "date": "2026-09-09",
          "time": "00:45",
          "datetime": "2026-09-09T00:45:00+08:00",
          "opponent": "AVL",
          "opponentName": "Aston Villa",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049571,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "INT",
          "opponentName": "Inter",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049603,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "LEN",
          "opponentName": "Lens",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049618,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "PSV",
          "opponentName": "PSV",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049638,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "LIV",
          "opponentName": "Liverpool",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049648,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "NAP",
          "opponentName": "Napoli",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049668,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "STU",
          "opponentName": "Stuttgart",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049688,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "BOD",
          "opponentName": "Bodø/Glimt",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "AVL": {
      "id": 52683,
      "code": "AVL",
      "name": "Aston Villa",
      "pot": "Pot 2",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049556,
          "day": 1,
          "date": "2026-09-09",
          "time": "00:45",
          "datetime": "2026-09-09T00:45:00+08:00",
          "opponent": "BRU",
          "opponentName": "Club Brugge",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049582,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "FEN",
          "opponentName": "Fenerbahçe",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049602,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "VFK",
          "opponentName": "Viking",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049607,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "BAR",
          "opponentName": "Barcelona",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049631,
          "day": 1,
          "date": "2026-11-25",
          "time": "01:45",
          "datetime": "2026-11-25T01:45:00+08:00",
          "opponent": "GAL",
          "opponentName": "Galatasaray",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049646,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "PSG",
          "opponentName": "Paris",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049663,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "BVB",
          "opponentName": "B. Dortmund",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049694,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "SLA",
          "opponentName": "Slavia Praha",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "RMA": {
      "id": 50051,
      "code": "RMA",
      "name": "Real Madrid",
      "pot": "Pot 1",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049553,
          "day": 1,
          "date": "2026-09-09",
          "time": "03:00",
          "datetime": "2026-09-09T03:00:00+08:00",
          "opponent": "INT",
          "opponentName": "Inter",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049581,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "ROM",
          "opponentName": "Roma",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049599,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "RBL",
          "opponentName": "Leipzig",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049622,
          "day": 2,
          "date": "2026-11-05",
          "time": "01:45",
          "datetime": "2026-11-05T01:45:00+08:00",
          "opponent": "AEK",
          "opponentName": "AEK Athens",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049625,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "PSV",
          "opponentName": "PSV",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049653,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "ARS",
          "opponentName": "Arsenal",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049661,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "LASK",
          "opponentName": "LASK",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049693,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "SHK",
          "opponentName": "Shakhtar",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "INT": {
      "id": 50138,
      "code": "INT",
      "name": "Inter",
      "pot": "Pot 1",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049553,
          "day": 1,
          "date": "2026-09-09",
          "time": "03:00",
          "datetime": "2026-09-09T03:00:00+08:00",
          "opponent": "RMA",
          "opponentName": "Real Madrid",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049571,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "BRU",
          "opponentName": "Club Brugge",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049600,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "SHK",
          "opponentName": "Shakhtar",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049610,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "FEY",
          "opponentName": "Feyenoord",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049635,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "STU",
          "opponentName": "Stuttgart",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049654,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "BVB",
          "opponentName": "B. Dortmund",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049662,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "LIV",
          "opponentName": "Liverpool",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049695,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "SBR",
          "opponentName": "S. Bratislava",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "POR": {
      "id": 50064,
      "code": "POR",
      "name": "Porto",
      "pot": "Pot 2",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049555,
          "day": 1,
          "date": "2026-09-09",
          "time": "03:00",
          "datetime": "2026-09-09T03:00:00+08:00",
          "opponent": "MCI",
          "opponentName": "Man City",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049583,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "BET",
          "opponentName": "Real Betis",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049593,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "PSV",
          "opponentName": "PSV",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049617,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "NAP",
          "opponentName": "Napoli",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049628,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "FEY",
          "opponentName": "Feyenoord",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049652,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "LIV",
          "opponentName": "Liverpool",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049664,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "SLA",
          "opponentName": "Slavia Praha",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049696,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "LASK",
          "opponentName": "LASK",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "MCI": {
      "id": 52919,
      "code": "MCI",
      "name": "Man City",
      "pot": "Pot 1",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049555,
          "day": 1,
          "date": "2026-09-09",
          "time": "03:00",
          "datetime": "2026-09-09T03:00:00+08:00",
          "opponent": "POR",
          "opponentName": "Porto",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049580,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "PSG",
          "opponentName": "Paris",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049591,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "AEK",
          "opponentName": "AEK Athens",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049619,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "RBL",
          "opponentName": "Leipzig",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049626,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "NAP",
          "opponentName": "Napoli",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049644,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "BAR",
          "opponentName": "Barcelona",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049676,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "LEN",
          "opponentName": "Lens",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049682,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "SPO",
          "opponentName": "Sporting CP",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "LIL": {
      "id": 75797,
      "code": "LIL",
      "name": "Lille",
      "pot": "Pot 3",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049557,
          "day": 1,
          "date": "2026-09-09",
          "time": "03:00",
          "datetime": "2026-09-09T03:00:00+08:00",
          "opponent": "BET",
          "opponentName": "Real Betis",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049572,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "ARS",
          "opponentName": "Arsenal",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049605,
          "day": 2,
          "date": "2026-10-22",
          "time": "00:45",
          "datetime": "2026-10-22T00:45:00+08:00",
          "opponent": "GAL",
          "opponentName": "Galatasaray",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049611,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "BOD",
          "opponentName": "Bodø/Glimt",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049639,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "BAY",
          "opponentName": "Bayern München",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049658,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "STU",
          "opponentName": "Stuttgart",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049665,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "SBR",
          "opponentName": "S. Bratislava",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049687,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "ROM",
          "opponentName": "Roma",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "BET": {
      "id": 52265,
      "code": "BET",
      "name": "Real Betis",
      "pot": "Pot 2",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049557,
          "day": 1,
          "date": "2026-09-09",
          "time": "03:00",
          "datetime": "2026-09-09T03:00:00+08:00",
          "opponent": "LIL",
          "opponentName": "Lille",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049583,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "POR",
          "opponentName": "Porto",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049604,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "FEY",
          "opponentName": "Feyenoord",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049616,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "BVB",
          "opponentName": "B. Dortmund",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049632,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "SBR",
          "opponentName": "S. Bratislava",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049655,
          "day": 2,
          "date": "2026-12-10",
          "time": "01:45",
          "datetime": "2026-12-10T01:45:00+08:00",
          "opponent": "COM",
          "opponentName": "Como",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049672,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "ARS",
          "opponentName": "Arsenal",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049680,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "BAY",
          "opponentName": "Bayern München",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "BVB": {
      "id": 52758,
      "code": "BVB",
      "name": "B. Dortmund",
      "pot": "Pot 2",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049554,
          "day": 1,
          "date": "2026-09-09",
          "time": "03:00",
          "datetime": "2026-09-09T03:00:00+08:00",
          "opponent": "VIL",
          "opponentName": "Villarreal",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049585,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "BOD",
          "opponentName": "Bodø/Glimt",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049597,
          "day": 1,
          "date": "2026-10-21",
          "time": "00:45",
          "datetime": "2026-10-21T00:45:00+08:00",
          "opponent": "SAB",
          "opponentName": "Sabah",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049616,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "BET",
          "opponentName": "Real Betis",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049627,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "ARS",
          "opponentName": "Arsenal",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049654,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "INT",
          "opponentName": "Inter",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049663,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "AVL",
          "opponentName": "Aston Villa",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049686,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "AEK",
          "opponentName": "AEK Athens",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "VIL": {
      "id": 70691,
      "code": "VIL",
      "name": "Villarreal",
      "pot": "Pot 3",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049554,
          "day": 1,
          "date": "2026-09-09",
          "time": "03:00",
          "datetime": "2026-09-09T03:00:00+08:00",
          "opponent": "BVB",
          "opponentName": "B. Dortmund",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049575,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "NAP",
          "opponentName": "Napoli",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049590,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "LIV",
          "opponentName": "Liverpool",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049612,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "PSG",
          "opponentName": "Paris",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049641,
          "day": 2,
          "date": "2026-11-26",
          "time": "01:45",
          "datetime": "2026-11-26T01:45:00+08:00",
          "opponent": "SLA",
          "opponentName": "Slavia Praha",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049649,
          "day": 1,
          "date": "2026-12-09",
          "time": "01:45",
          "datetime": "2026-12-09T01:45:00+08:00",
          "opponent": "SAB",
          "opponentName": "Sabah",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049674,
          "day": 2,
          "date": "2027-01-21",
          "time": "01:45",
          "datetime": "2027-01-21T01:45:00+08:00",
          "opponent": "FEN",
          "opponentName": "Fenerbahçe",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049692,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "MUN",
          "opponentName": "Man Utd",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "STU": {
      "id": 50107,
      "code": "STU",
      "name": "Stuttgart",
      "pot": "Pot 4",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049564,
          "day": 2,
          "date": "2026-09-10",
          "time": "00:45",
          "datetime": "2026-09-10T00:45:00+08:00",
          "opponent": "VFK",
          "opponentName": "Viking",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049587,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "SBR",
          "opponentName": "S. Bratislava",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049596,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "ATM",
          "opponentName": "Atleti",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049614,
          "day": 1,
          "date": "2026-11-04",
          "time": "01:45",
          "datetime": "2026-11-04T01:45:00+08:00",
          "opponent": "GAL",
          "opponentName": "Galatasaray",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049635,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "INT",
          "opponentName": "Inter",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049658,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "LIL",
          "opponentName": "Lille",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049668,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "BRU",
          "opponentName": "Club Brugge",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049689,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "PSV",
          "opponentName": "PSV",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "VFK": {
      "id": 52319,
      "code": "VFK",
      "name": "Viking",
      "pot": "Pot 4",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049564,
          "day": 2,
          "date": "2026-09-10",
          "time": "00:45",
          "datetime": "2026-09-10T00:45:00+08:00",
          "opponent": "STU",
          "opponentName": "Stuttgart",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049578,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "BAY",
          "opponentName": "Bayern München",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049602,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "AVL",
          "opponentName": "Aston Villa",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049624,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "SAB",
          "opponentName": "Sabah",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049636,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "ATM",
          "opponentName": "Atleti",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049651,
          "day": 1,
          "date": "2026-12-09",
          "time": "01:45",
          "datetime": "2026-12-09T01:45:00+08:00",
          "opponent": "FEY",
          "opponentName": "Feyenoord",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049677,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "PSV",
          "opponentName": "PSV",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049691,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "NAP",
          "opponentName": "Napoli",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "BAR": {
      "id": 50080,
      "code": "BAR",
      "name": "Barcelona",
      "pot": "Pot 1",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049561,
          "day": 2,
          "date": "2026-09-10",
          "time": "00:45",
          "datetime": "2026-09-10T00:45:00+08:00",
          "opponent": "FEY",
          "opponentName": "Feyenoord",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049576,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "GAL",
          "opponentName": "Galatasaray",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049589,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "PSG",
          "opponentName": "Paris",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049607,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "AVL",
          "opponentName": "Aston Villa",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049642,
          "day": 2,
          "date": "2026-11-26",
          "time": "01:45",
          "datetime": "2026-11-26T01:45:00+08:00",
          "opponent": "SAB",
          "opponentName": "Sabah",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049644,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "MCI",
          "opponentName": "Man City",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049670,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "SPO",
          "opponentName": "Sporting CP",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049684,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "COM",
          "opponentName": "Como",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "FEY": {
      "id": 52749,
      "code": "FEY",
      "name": "Feyenoord",
      "pot": "Pot 3",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049561,
          "day": 2,
          "date": "2026-09-10",
          "time": "00:45",
          "datetime": "2026-09-10T00:45:00+08:00",
          "opponent": "BAR",
          "opponentName": "Barcelona",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049584,
          "day": 2,
          "date": "2026-10-15",
          "time": "00:45",
          "datetime": "2026-10-15T00:45:00+08:00",
          "opponent": "COM",
          "opponentName": "Como",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049604,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "BET",
          "opponentName": "Real Betis",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049610,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "INT",
          "opponentName": "Inter",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049628,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "POR",
          "opponentName": "Porto",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049651,
          "day": 1,
          "date": "2026-12-09",
          "time": "01:45",
          "datetime": "2026-12-09T01:45:00+08:00",
          "opponent": "VFK",
          "opponentName": "Viking",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049667,
          "day": 1,
          "date": "2027-01-20",
          "time": "01:45",
          "datetime": "2027-01-20T01:45:00+08:00",
          "opponent": "GAL",
          "opponentName": "Galatasaray",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049690,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "RBL",
          "opponentName": "Leipzig",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "SPO": {
      "id": 50149,
      "code": "SPO",
      "name": "Sporting CP",
      "pot": "Pot 2",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049562,
          "day": 2,
          "date": "2026-09-10",
          "time": "03:00",
          "datetime": "2026-09-10T03:00:00+08:00",
          "opponent": "GAL",
          "opponentName": "Galatasaray",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049577,
          "day": 1,
          "date": "2026-10-14",
          "time": "00:45",
          "datetime": "2026-10-14T00:45:00+08:00",
          "opponent": "LEN",
          "opponentName": "Lens",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049601,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "LASK",
          "opponentName": "LASK",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049613,
          "day": 1,
          "date": "2026-11-04",
          "time": "01:45",
          "datetime": "2026-11-04T01:45:00+08:00",
          "opponent": "SHK",
          "opponentName": "Shakhtar",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049637,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "MUN",
          "opponentName": "Man Utd",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049645,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "ROM",
          "opponentName": "Roma",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049670,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "BAR",
          "opponentName": "Barcelona",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049682,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "MCI",
          "opponentName": "Man City",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "GAL": {
      "id": 50067,
      "code": "GAL",
      "name": "Galatasaray",
      "pot": "Pot 3",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049562,
          "day": 2,
          "date": "2026-09-10",
          "time": "03:00",
          "datetime": "2026-09-10T03:00:00+08:00",
          "opponent": "SPO",
          "opponentName": "Sporting CP",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049576,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "BAR",
          "opponentName": "Barcelona",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049605,
          "day": 2,
          "date": "2026-10-22",
          "time": "00:45",
          "datetime": "2026-10-22T00:45:00+08:00",
          "opponent": "LIL",
          "opponentName": "Lille",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049614,
          "day": 1,
          "date": "2026-11-04",
          "time": "01:45",
          "datetime": "2026-11-04T01:45:00+08:00",
          "opponent": "STU",
          "opponentName": "Stuttgart",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049631,
          "day": 1,
          "date": "2026-11-25",
          "time": "01:45",
          "datetime": "2026-11-25T01:45:00+08:00",
          "opponent": "AVL",
          "opponentName": "Aston Villa",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049650,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "AEK",
          "opponentName": "AEK Athens",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049667,
          "day": 1,
          "date": "2027-01-20",
          "time": "01:45",
          "datetime": "2027-01-20T01:45:00+08:00",
          "opponent": "FEY",
          "opponentName": "Feyenoord",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049679,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "PSG",
          "opponentName": "Paris",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "NAP": {
      "id": 50136,
      "code": "NAP",
      "name": "Napoli",
      "pot": "Pot 3",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049563,
          "day": 2,
          "date": "2026-09-10",
          "time": "03:00",
          "datetime": "2026-09-10T03:00:00+08:00",
          "opponent": "ARS",
          "opponentName": "Arsenal",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049575,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "VIL",
          "opponentName": "Villarreal",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049594,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "BOD",
          "opponentName": "Bodø/Glimt",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049617,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "POR",
          "opponentName": "Porto",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049626,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "MCI",
          "opponentName": "Man City",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049648,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "BRU",
          "opponentName": "Club Brugge",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049678,
          "day": 2,
          "date": "2027-01-21",
          "time": "01:45",
          "datetime": "2027-01-21T01:45:00+08:00",
          "opponent": "SAB",
          "opponentName": "Sabah",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049691,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "VFK",
          "opponentName": "Viking",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "ARS": {
      "id": 52280,
      "code": "ARS",
      "name": "Arsenal",
      "pot": "Pot 1",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049563,
          "day": 2,
          "date": "2026-09-10",
          "time": "03:00",
          "datetime": "2026-09-10T03:00:00+08:00",
          "opponent": "NAP",
          "opponentName": "Napoli",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049572,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "LIL",
          "opponentName": "Lille",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049598,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "BAY",
          "opponentName": "Bayern München",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049621,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "SLA",
          "opponentName": "Slavia Praha",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049627,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "BVB",
          "opponentName": "B. Dortmund",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049653,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "RMA",
          "opponentName": "Real Madrid",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049672,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "BET",
          "opponentName": "Real Betis",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049683,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "SAB",
          "opponentName": "Sabah",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "LIV": {
      "id": 7889,
      "code": "LIV",
      "name": "Liverpool",
      "pot": "Pot 1",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049560,
          "day": 2,
          "date": "2026-09-10",
          "time": "03:00",
          "datetime": "2026-09-10T03:00:00+08:00",
          "opponent": "ATM",
          "opponentName": "Atleti",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049588,
          "day": 2,
          "date": "2026-10-15",
          "time": "00:45",
          "datetime": "2026-10-15T00:45:00+08:00",
          "opponent": "LASK",
          "opponentName": "LASK",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049590,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "VIL",
          "opponentName": "Villarreal",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049620,
          "day": 2,
          "date": "2026-11-05",
          "time": "01:45",
          "datetime": "2026-11-05T01:45:00+08:00",
          "opponent": "FEN",
          "opponentName": "Fenerbahçe",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049638,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "BRU",
          "opponentName": "Club Brugge",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049652,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "POR",
          "opponentName": "Porto",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049662,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "INT",
          "opponentName": "Inter",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049681,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "LEN",
          "opponentName": "Lens",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "ATM": {
      "id": 50124,
      "code": "ATM",
      "name": "Atleti",
      "pot": "Pot 1",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049560,
          "day": 2,
          "date": "2026-09-10",
          "time": "03:00",
          "datetime": "2026-09-10T03:00:00+08:00",
          "opponent": "LIV",
          "opponentName": "Liverpool",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049573,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "MUN",
          "opponentName": "Man Utd",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049596,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "STU",
          "opponentName": "Stuttgart",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049608,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "BAY",
          "opponentName": "Bayern München",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049636,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "VFK",
          "opponentName": "Viking",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049656,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "PSV",
          "opponentName": "PSV",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049666,
          "day": 1,
          "date": "2027-01-20",
          "time": "01:45",
          "datetime": "2027-01-20T01:45:00+08:00",
          "opponent": "BOD",
          "opponentName": "Bodø/Glimt",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049685,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "FEN",
          "opponentName": "Fenerbahçe",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "PSG": {
      "id": 52747,
      "code": "PSG",
      "name": "Paris",
      "pot": "Pot 1",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049559,
          "day": 2,
          "date": "2026-09-10",
          "time": "03:00",
          "datetime": "2026-09-10T03:00:00+08:00",
          "opponent": "SBR",
          "opponentName": "S. Bratislava",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049580,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "MCI",
          "opponentName": "Man City",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049589,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "BAR",
          "opponentName": "Barcelona",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049612,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "VIL",
          "opponentName": "Villarreal",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049634,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "ROM",
          "opponentName": "Roma",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049646,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "AVL",
          "opponentName": "Aston Villa",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049675,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "COM",
          "opponentName": "Como",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049679,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "GAL",
          "opponentName": "Galatasaray",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "SBR": {
      "id": 52797,
      "code": "SBR",
      "name": "S. Bratislava",
      "pot": "Pot 4",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049559,
          "day": 2,
          "date": "2026-09-10",
          "time": "03:00",
          "datetime": "2026-09-10T03:00:00+08:00",
          "opponent": "PSG",
          "opponentName": "Paris",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049587,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "STU",
          "opponentName": "Stuttgart",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049592,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "ROM",
          "opponentName": "Roma",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049615,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "LASK",
          "opponentName": "LASK",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049632,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "BET",
          "opponentName": "Real Betis",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049657,
          "day": 2,
          "date": "2026-12-10",
          "time": "01:45",
          "datetime": "2026-12-10T01:45:00+08:00",
          "opponent": "SHK",
          "opponentName": "Shakhtar",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049665,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "LIL",
          "opponentName": "Lille",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049695,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "INT",
          "opponentName": "Inter",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "PSV": {
      "id": 50062,
      "code": "PSV",
      "name": "PSV",
      "pot": "Pot 2",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049567,
          "day": 3,
          "date": "2026-09-11",
          "time": "00:45",
          "datetime": "2026-09-11T00:45:00+08:00",
          "opponent": "SHK",
          "opponentName": "Shakhtar",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049574,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "RBL",
          "opponentName": "Leipzig",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049593,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "POR",
          "opponentName": "Porto",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049618,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "BRU",
          "opponentName": "Club Brugge",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049625,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "RMA",
          "opponentName": "Real Madrid",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049656,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "ATM",
          "opponentName": "Atleti",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049677,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "VFK",
          "opponentName": "Viking",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049689,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "STU",
          "opponentName": "Stuttgart",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "SHK": {
      "id": 52707,
      "code": "SHK",
      "name": "Shakhtar",
      "pot": "Pot 3",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049567,
          "day": 3,
          "date": "2026-09-11",
          "time": "00:45",
          "datetime": "2026-09-11T00:45:00+08:00",
          "opponent": "PSV",
          "opponentName": "PSV",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049586,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "AEK",
          "opponentName": "AEK Athens",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049600,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "INT",
          "opponentName": "Inter",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049613,
          "day": 1,
          "date": "2026-11-04",
          "time": "01:45",
          "datetime": "2026-11-04T01:45:00+08:00",
          "opponent": "SPO",
          "opponentName": "Sporting CP",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049640,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "FEN",
          "opponentName": "Fenerbahçe",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049657,
          "day": 2,
          "date": "2026-12-10",
          "time": "01:45",
          "datetime": "2026-12-10T01:45:00+08:00",
          "opponent": "SBR",
          "opponentName": "S. Bratislava",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049673,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "RBL",
          "opponentName": "Leipzig",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049693,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "RMA",
          "opponentName": "Real Madrid",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "FEN": {
      "id": 52692,
      "code": "FEN",
      "name": "Fenerbahçe",
      "pot": "Pot 3",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049568,
          "day": 3,
          "date": "2026-09-11",
          "time": "00:45",
          "datetime": "2026-09-11T00:45:00+08:00",
          "opponent": "ROM",
          "opponentName": "Roma",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049582,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "AVL",
          "opponentName": "Aston Villa",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049595,
          "day": 1,
          "date": "2026-10-21",
          "time": "00:45",
          "datetime": "2026-10-21T00:45:00+08:00",
          "opponent": "SLA",
          "opponentName": "Slavia Praha",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049620,
          "day": 2,
          "date": "2026-11-05",
          "time": "01:45",
          "datetime": "2026-11-05T01:45:00+08:00",
          "opponent": "LIV",
          "opponentName": "Liverpool",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049640,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "SHK",
          "opponentName": "Shakhtar",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049659,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "LASK",
          "opponentName": "LASK",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049674,
          "day": 2,
          "date": "2027-01-21",
          "time": "01:45",
          "datetime": "2027-01-21T01:45:00+08:00",
          "opponent": "VIL",
          "opponentName": "Villarreal",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049685,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "ATM",
          "opponentName": "Atleti",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "ROM": {
      "id": 50137,
      "code": "ROM",
      "name": "Roma",
      "pot": "Pot 2",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049568,
          "day": 3,
          "date": "2026-09-11",
          "time": "00:45",
          "datetime": "2026-09-11T00:45:00+08:00",
          "opponent": "FEN",
          "opponentName": "Fenerbahçe",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049581,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "RMA",
          "opponentName": "Real Madrid",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049592,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "SBR",
          "opponentName": "S. Bratislava",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049609,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "MUN",
          "opponentName": "Man Utd",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049634,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "PSG",
          "opponentName": "Paris",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049645,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "SPO",
          "opponentName": "Sporting CP",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049669,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "AEK",
          "opponentName": "AEK Athens",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049687,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "LIL",
          "opponentName": "Lille",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "COM": {
      "id": 79946,
      "code": "COM",
      "name": "Como",
      "pot": "Pot 4",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049570,
          "day": 3,
          "date": "2026-09-11",
          "time": "03:00",
          "datetime": "2026-09-11T03:00:00+08:00",
          "opponent": "RBL",
          "opponentName": "Leipzig",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049584,
          "day": 2,
          "date": "2026-10-15",
          "time": "00:45",
          "datetime": "2026-10-15T00:45:00+08:00",
          "opponent": "FEY",
          "opponentName": "Feyenoord",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049606,
          "day": 2,
          "date": "2026-10-22",
          "time": "00:45",
          "datetime": "2026-10-22T00:45:00+08:00",
          "opponent": "MUN",
          "opponentName": "Man Utd",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049623,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "LEN",
          "opponentName": "Lens",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049633,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "AEK",
          "opponentName": "AEK Athens",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049655,
          "day": 2,
          "date": "2026-12-10",
          "time": "01:45",
          "datetime": "2026-12-10T01:45:00+08:00",
          "opponent": "BET",
          "opponentName": "Real Betis",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049675,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "PSG",
          "opponentName": "Paris",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049684,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "BAR",
          "opponentName": "Barcelona",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "RBL": {
      "id": 2603790,
      "code": "RBL",
      "name": "Leipzig",
      "pot": "Pot 3",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049570,
          "day": 3,
          "date": "2026-09-11",
          "time": "03:00",
          "datetime": "2026-09-11T03:00:00+08:00",
          "opponent": "COM",
          "opponentName": "Como",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049574,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "PSV",
          "opponentName": "PSV",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049599,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "RMA",
          "opponentName": "Real Madrid",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049619,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "MCI",
          "opponentName": "Man City",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049630,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "LEN",
          "opponentName": "Lens",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049647,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "MUN",
          "opponentName": "Man Utd",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049673,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "SHK",
          "opponentName": "Shakhtar",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049690,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "FEY",
          "opponentName": "Feyenoord",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "MUN": {
      "id": 52682,
      "code": "MUN",
      "name": "Man Utd",
      "pot": "Pot 2",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049566,
          "day": 3,
          "date": "2026-09-11",
          "time": "03:00",
          "datetime": "2026-09-11T03:00:00+08:00",
          "opponent": "SAB",
          "opponentName": "Sabah",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049573,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "ATM",
          "opponentName": "Atleti",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049606,
          "day": 2,
          "date": "2026-10-22",
          "time": "00:45",
          "datetime": "2026-10-22T00:45:00+08:00",
          "opponent": "COM",
          "opponentName": "Como",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049609,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "ROM",
          "opponentName": "Roma",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049637,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "SPO",
          "opponentName": "Sporting CP",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049647,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "RBL",
          "opponentName": "Leipzig",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049671,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "BAY",
          "opponentName": "Bayern München",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049692,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "VIL",
          "opponentName": "Villarreal",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "SAB": {
      "id": 2609356,
      "code": "SAB",
      "name": "Sabah",
      "pot": "Pot 4",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049566,
          "day": 3,
          "date": "2026-09-11",
          "time": "03:00",
          "datetime": "2026-09-11T03:00:00+08:00",
          "opponent": "MUN",
          "opponentName": "Man Utd",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049579,
          "day": 1,
          "date": "2026-10-14",
          "time": "00:45",
          "datetime": "2026-10-14T00:45:00+08:00",
          "opponent": "SLA",
          "opponentName": "Slavia Praha",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049597,
          "day": 1,
          "date": "2026-10-21",
          "time": "00:45",
          "datetime": "2026-10-21T00:45:00+08:00",
          "opponent": "BVB",
          "opponentName": "B. Dortmund",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049624,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "VFK",
          "opponentName": "Viking",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049642,
          "day": 2,
          "date": "2026-11-26",
          "time": "01:45",
          "datetime": "2026-11-26T01:45:00+08:00",
          "opponent": "BAR",
          "opponentName": "Barcelona",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049649,
          "day": 1,
          "date": "2026-12-09",
          "time": "01:45",
          "datetime": "2026-12-09T01:45:00+08:00",
          "opponent": "VIL",
          "opponentName": "Villarreal",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049678,
          "day": 2,
          "date": "2027-01-21",
          "time": "01:45",
          "datetime": "2027-01-21T01:45:00+08:00",
          "opponent": "NAP",
          "opponentName": "Napoli",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049683,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "ARS",
          "opponentName": "Arsenal",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "SLA": {
      "id": 52498,
      "code": "SLA",
      "name": "Slavia Praha",
      "pot": "Pot 4",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049569,
          "day": 3,
          "date": "2026-09-11",
          "time": "03:00",
          "datetime": "2026-09-11T03:00:00+08:00",
          "opponent": "LEN",
          "opponentName": "Lens",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049579,
          "day": 1,
          "date": "2026-10-14",
          "time": "00:45",
          "datetime": "2026-10-14T00:45:00+08:00",
          "opponent": "SAB",
          "opponentName": "Sabah",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049595,
          "day": 1,
          "date": "2026-10-21",
          "time": "00:45",
          "datetime": "2026-10-21T00:45:00+08:00",
          "opponent": "FEN",
          "opponentName": "Fenerbahçe",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049621,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "ARS",
          "opponentName": "Arsenal",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049641,
          "day": 2,
          "date": "2026-11-26",
          "time": "01:45",
          "datetime": "2026-11-26T01:45:00+08:00",
          "opponent": "VIL",
          "opponentName": "Villarreal",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049643,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "BAY",
          "opponentName": "Bayern München",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049664,
          "day": 1,
          "date": "2027-01-20",
          "time": "04:00",
          "datetime": "2027-01-20T04:00:00+08:00",
          "opponent": "POR",
          "opponentName": "Porto",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049694,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "AVL",
          "opponentName": "Aston Villa",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "LEN": {
      "id": 52277,
      "code": "LEN",
      "name": "Lens",
      "pot": "Pot 4",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049569,
          "day": 3,
          "date": "2026-09-11",
          "time": "03:00",
          "datetime": "2026-09-11T03:00:00+08:00",
          "opponent": "SLA",
          "opponentName": "Slavia Praha",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049577,
          "day": 1,
          "date": "2026-10-14",
          "time": "00:45",
          "datetime": "2026-10-14T00:45:00+08:00",
          "opponent": "SPO",
          "opponentName": "Sporting CP",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049603,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "BRU",
          "opponentName": "Club Brugge",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049623,
          "day": 2,
          "date": "2026-11-05",
          "time": "04:00",
          "datetime": "2026-11-05T04:00:00+08:00",
          "opponent": "COM",
          "opponentName": "Como",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049630,
          "day": 1,
          "date": "2026-11-25",
          "time": "04:00",
          "datetime": "2026-11-25T04:00:00+08:00",
          "opponent": "RBL",
          "opponentName": "Leipzig",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049660,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "BOD",
          "opponentName": "Bodø/Glimt",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049676,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "MCI",
          "opponentName": "Man City",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049681,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "LIV",
          "opponentName": "Liverpool",
          "homeAway": "A",
          "fdr": null
        }
      }
    },
    "BAY": {
      "id": 50037,
      "code": "BAY",
      "name": "Bayern München",
      "pot": "Pot 1",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049565,
          "day": 3,
          "date": "2026-09-11",
          "time": "03:00",
          "datetime": "2026-09-11T03:00:00+08:00",
          "opponent": "BOD",
          "opponentName": "Bodø/Glimt",
          "homeAway": "H",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049578,
          "day": 1,
          "date": "2026-10-14",
          "time": "03:00",
          "datetime": "2026-10-14T03:00:00+08:00",
          "opponent": "VFK",
          "opponentName": "Viking",
          "homeAway": "A",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049598,
          "day": 2,
          "date": "2026-10-22",
          "time": "03:00",
          "datetime": "2026-10-22T03:00:00+08:00",
          "opponent": "ARS",
          "opponentName": "Arsenal",
          "homeAway": "H",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049608,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "ATM",
          "opponentName": "Atleti",
          "homeAway": "A",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049639,
          "day": 2,
          "date": "2026-11-26",
          "time": "04:00",
          "datetime": "2026-11-26T04:00:00+08:00",
          "opponent": "LIL",
          "opponentName": "Lille",
          "homeAway": "A",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049643,
          "day": 1,
          "date": "2026-12-09",
          "time": "04:00",
          "datetime": "2026-12-09T04:00:00+08:00",
          "opponent": "SLA",
          "opponentName": "Slavia Praha",
          "homeAway": "H",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049671,
          "day": 2,
          "date": "2027-01-21",
          "time": "04:00",
          "datetime": "2027-01-21T04:00:00+08:00",
          "opponent": "MUN",
          "opponentName": "Man Utd",
          "homeAway": "A",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049680,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "BET",
          "opponentName": "Real Betis",
          "homeAway": "H",
          "fdr": null
        }
      }
    },
    "BOD": {
      "id": 59333,
      "code": "BOD",
      "name": "Bodø/Glimt",
      "pot": "Pot 3",
      "fixtures": {
        "MD1": {
          "matchday": 1,
          "matchId": 2049565,
          "day": 3,
          "date": "2026-09-11",
          "time": "03:00",
          "datetime": "2026-09-11T03:00:00+08:00",
          "opponent": "BAY",
          "opponentName": "Bayern München",
          "homeAway": "A",
          "fdr": null
        },
        "MD2": {
          "matchday": 2,
          "matchId": 2049585,
          "day": 2,
          "date": "2026-10-15",
          "time": "03:00",
          "datetime": "2026-10-15T03:00:00+08:00",
          "opponent": "BVB",
          "opponentName": "B. Dortmund",
          "homeAway": "H",
          "fdr": null
        },
        "MD3": {
          "matchday": 3,
          "matchId": 2049594,
          "day": 1,
          "date": "2026-10-21",
          "time": "03:00",
          "datetime": "2026-10-21T03:00:00+08:00",
          "opponent": "NAP",
          "opponentName": "Napoli",
          "homeAway": "A",
          "fdr": null
        },
        "MD4": {
          "matchday": 4,
          "matchId": 2049611,
          "day": 1,
          "date": "2026-11-04",
          "time": "04:00",
          "datetime": "2026-11-04T04:00:00+08:00",
          "opponent": "LIL",
          "opponentName": "Lille",
          "homeAway": "H",
          "fdr": null
        },
        "MD5": {
          "matchday": 5,
          "matchId": 2049629,
          "day": 1,
          "date": "2026-11-25",
          "time": "01:45",
          "datetime": "2026-11-25T01:45:00+08:00",
          "opponent": "LASK",
          "opponentName": "LASK",
          "homeAway": "H",
          "fdr": null
        },
        "MD6": {
          "matchday": 6,
          "matchId": 2049660,
          "day": 2,
          "date": "2026-12-10",
          "time": "04:00",
          "datetime": "2026-12-10T04:00:00+08:00",
          "opponent": "LEN",
          "opponentName": "Lens",
          "homeAway": "A",
          "fdr": null
        },
        "MD7": {
          "matchday": 7,
          "matchId": 2049666,
          "day": 1,
          "date": "2027-01-20",
          "time": "01:45",
          "datetime": "2027-01-20T01:45:00+08:00",
          "opponent": "ATM",
          "opponentName": "Atleti",
          "homeAway": "H",
          "fdr": null
        },
        "MD8": {
          "matchday": 8,
          "matchId": 2049688,
          "day": 1,
          "date": "2027-01-28",
          "time": "04:00",
          "datetime": "2027-01-28T04:00:00+08:00",
          "opponent": "BRU",
          "opponentName": "Club Brugge",
          "homeAway": "A",
          "fdr": null
        }
      }
    }
  },
  "coverage": {
    "AEK": {
      "MD1": 1,
      "MD2": 2,
      "MD3": 1,
      "MD4": 2,
      "MD5": 1,
      "MD6": 1,
      "MD7": 1,
      "MD8": 1
    },
    "LASK": {
      "MD1": 1,
      "MD2": 2,
      "MD3": 2,
      "MD4": 1,
      "MD5": 1,
      "MD6": 2,
      "MD7": 1,
      "MD8": 1
    },
    "BRU": {
      "MD1": 1,
      "MD2": 1,
      "MD3": 2,
      "MD4": 2,
      "MD5": 2,
      "MD6": 1,
      "MD7": 1,
      "MD8": 1
    },
    "AVL": {
      "MD1": 1,
      "MD2": 2,
      "MD3": 2,
      "MD4": 1,
      "MD5": 1,
      "MD6": 1,
      "MD7": 1,
      "MD8": 1
    },
    "RMA": {
      "MD1": 1,
      "MD2": 2,
      "MD3": 2,
      "MD4": 2,
      "MD5": 1,
      "MD6": 2,
      "MD7": 1,
      "MD8": 1
    },
    "INT": {
      "MD1": 1,
      "MD2": 1,
      "MD3": 2,
      "MD4": 1,
      "MD5": 2,
      "MD6": 2,
      "MD7": 1,
      "MD8": 1
    },
    "POR": {
      "MD1": 1,
      "MD2": 2,
      "MD3": 1,
      "MD4": 2,
      "MD5": 1,
      "MD6": 2,
      "MD7": 1,
      "MD8": 1
    },
    "MCI": {
      "MD1": 1,
      "MD2": 2,
      "MD3": 1,
      "MD4": 2,
      "MD5": 1,
      "MD6": 1,
      "MD7": 2,
      "MD8": 1
    },
    "LIL": {
      "MD1": 1,
      "MD2": 1,
      "MD3": 2,
      "MD4": 1,
      "MD5": 2,
      "MD6": 2,
      "MD7": 1,
      "MD8": 1
    },
    "BET": {
      "MD1": 1,
      "MD2": 2,
      "MD3": 2,
      "MD4": 2,
      "MD5": 1,
      "MD6": 2,
      "MD7": 2,
      "MD8": 1
    },
    "BVB": {
      "MD1": 1,
      "MD2": 2,
      "MD3": 1,
      "MD4": 2,
      "MD5": 1,
      "MD6": 2,
      "MD7": 1,
      "MD8": 1
    },
    "VIL": {
      "MD1": 1,
      "MD2": 1,
      "MD3": 1,
      "MD4": 1,
      "MD5": 2,
      "MD6": 1,
      "MD7": 2,
      "MD8": 1
    },
    "STU": {
      "MD1": 2,
      "MD2": 2,
      "MD3": 1,
      "MD4": 1,
      "MD5": 2,
      "MD6": 2,
      "MD7": 1,
      "MD8": 1
    },
    "VFK": {
      "MD1": 2,
      "MD2": 1,
      "MD3": 2,
      "MD4": 2,
      "MD5": 2,
      "MD6": 1,
      "MD7": 2,
      "MD8": 1
    },
    "BAR": {
      "MD1": 2,
      "MD2": 1,
      "MD3": 1,
      "MD4": 1,
      "MD5": 2,
      "MD6": 1,
      "MD7": 2,
      "MD8": 1
    },
    "FEY": {
      "MD1": 2,
      "MD2": 2,
      "MD3": 2,
      "MD4": 1,
      "MD5": 1,
      "MD6": 1,
      "MD7": 1,
      "MD8": 1
    },
    "SPO": {
      "MD1": 2,
      "MD2": 1,
      "MD3": 2,
      "MD4": 1,
      "MD5": 2,
      "MD6": 1,
      "MD7": 2,
      "MD8": 1
    },
    "GAL": {
      "MD1": 2,
      "MD2": 1,
      "MD3": 2,
      "MD4": 1,
      "MD5": 1,
      "MD6": 1,
      "MD7": 1,
      "MD8": 1
    },
    "NAP": {
      "MD1": 2,
      "MD2": 1,
      "MD3": 1,
      "MD4": 2,
      "MD5": 1,
      "MD6": 1,
      "MD7": 2,
      "MD8": 1
    },
    "ARS": {
      "MD1": 2,
      "MD2": 1,
      "MD3": 2,
      "MD4": 2,
      "MD5": 1,
      "MD6": 2,
      "MD7": 2,
      "MD8": 1
    },
    "LIV": {
      "MD1": 2,
      "MD2": 2,
      "MD3": 1,
      "MD4": 2,
      "MD5": 2,
      "MD6": 2,
      "MD7": 1,
      "MD8": 1
    },
    "ATM": {
      "MD1": 2,
      "MD2": 1,
      "MD3": 1,
      "MD4": 1,
      "MD5": 2,
      "MD6": 2,
      "MD7": 1,
      "MD8": 1
    },
    "PSG": {
      "MD1": 2,
      "MD2": 2,
      "MD3": 1,
      "MD4": 1,
      "MD5": 2,
      "MD6": 1,
      "MD7": 2,
      "MD8": 1
    },
    "SBR": {
      "MD1": 2,
      "MD2": 2,
      "MD3": 1,
      "MD4": 1,
      "MD5": 1,
      "MD6": 2,
      "MD7": 1,
      "MD8": 1
    },
    "PSV": {
      "MD1": 3,
      "MD2": 1,
      "MD3": 1,
      "MD4": 2,
      "MD5": 1,
      "MD6": 2,
      "MD7": 2,
      "MD8": 1
    },
    "SHK": {
      "MD1": 3,
      "MD2": 2,
      "MD3": 2,
      "MD4": 1,
      "MD5": 2,
      "MD6": 2,
      "MD7": 2,
      "MD8": 1
    },
    "FEN": {
      "MD1": 3,
      "MD2": 2,
      "MD3": 1,
      "MD4": 2,
      "MD5": 2,
      "MD6": 2,
      "MD7": 2,
      "MD8": 1
    },
    "ROM": {
      "MD1": 3,
      "MD2": 2,
      "MD3": 1,
      "MD4": 1,
      "MD5": 2,
      "MD6": 1,
      "MD7": 1,
      "MD8": 1
    },
    "COM": {
      "MD1": 3,
      "MD2": 2,
      "MD3": 2,
      "MD4": 2,
      "MD5": 1,
      "MD6": 2,
      "MD7": 2,
      "MD8": 1
    },
    "RBL": {
      "MD1": 3,
      "MD2": 1,
      "MD3": 2,
      "MD4": 2,
      "MD5": 1,
      "MD6": 1,
      "MD7": 2,
      "MD8": 1
    },
    "MUN": {
      "MD1": 3,
      "MD2": 1,
      "MD3": 2,
      "MD4": 1,
      "MD5": 2,
      "MD6": 1,
      "MD7": 2,
      "MD8": 1
    },
    "SAB": {
      "MD1": 3,
      "MD2": 1,
      "MD3": 1,
      "MD4": 2,
      "MD5": 2,
      "MD6": 1,
      "MD7": 2,
      "MD8": 1
    },
    "SLA": {
      "MD1": 3,
      "MD2": 1,
      "MD3": 1,
      "MD4": 2,
      "MD5": 2,
      "MD6": 1,
      "MD7": 1,
      "MD8": 1
    },
    "LEN": {
      "MD1": 3,
      "MD2": 1,
      "MD3": 2,
      "MD4": 2,
      "MD5": 1,
      "MD6": 2,
      "MD7": 2,
      "MD8": 1
    },
    "BAY": {
      "MD1": 3,
      "MD2": 1,
      "MD3": 2,
      "MD4": 1,
      "MD5": 2,
      "MD6": 1,
      "MD7": 2,
      "MD8": 1
    },
    "BOD": {
      "MD1": 3,
      "MD2": 2,
      "MD3": 1,
      "MD4": 1,
      "MD5": 1,
      "MD6": 2,
      "MD7": 1,
      "MD8": 1
    }
  }
}
`),qs=(()=>{const n=new Map;for(const e of p0.matchdays){const t=e.days.map(a=>a.day).sort((a,d)=>a-d);n.set(e.id,t)}return n})();function um(n){const e=p0.coverage[n],t=new Set;if(!e)return t;for(const[a,d]of Object.entries(e))t.add(`${a}-D${d}`);return t}function n2(n,e,t){var u,y;const a=new Set;for(const f of n)for(const p of um(f))a.add(p);const d=new Set;for(let f=e;f<=t;f++){const p=(u=qs.get(f))!=null?u:[];for(const g of p)d.add(`MD${f}-D${g}`)}const o=Array.from(d).filter(f=>!a.has(f)).sort();if(o.length===0)return{missingSlots:[],rankings:[],top:null,tiedRemaining:null};const i=[];for(const[f,p]of Object.entries(p0.teams)){if(n.includes(f))continue;const g=um(f);let N=0;for(const w of o)g.has(w)&&N++;i.push({code:f,name:p.name,pot:p.pot,filledHoles:N})}i.sort((f,p)=>p.filledHoles-f.filledHoles||f.code.localeCompare(p.code));const r=(y=i[0])!=null?y:null,l=r?sm(i,0):null;return{missingSlots:o,rankings:i,top:r,tiedRemaining:l}}function sm(n,e){const t=n[e];if(!t)return null;const a=n.filter(i=>i.filledHoles===t.filledHoles),d=a.findIndex(i=>i.code===t.code),o=a.length-d-1;return o>0?{count:o,score:t.filledHoles}:null}function e2(n,e,t){const a=p0.teams[n];if(!a)return[];const d=[];for(let o=e;o<=t;o++){const i=a.fixtures[`MD${o}`];i&&d.push({matchday:o,day:i.day,date:i.date,time:i.time,opponent:i.opponentName||i.opponent,homeAway:i.homeAway})}return d}function t2({selectedCodes:n,rangeStart:e,rangeEnd:t,onAddToCompare:a}){var m;const d=n.length,[o,i]=U.useState(!1),[r,l]=U.useState(0),[u,y]=U.useState(!1),f=U.useMemo(()=>n2(n,e,t),[n,e,t]);if(U.useEffect(()=>{l(0),y(!1)},[n,e,t]),d<1||d>=10)return null;const p=f.top!==null,g=f.rankings.length>0?Math.min(r,f.rankings.length-1):0,N=(m=f.rankings[g])!=null?m:null,w=N?sm(f.rankings,g):null,D=()=>{f.rankings.length!==0&&(l(c=>(c+1)%f.rankings.length),y(!1))},h=N&&u?e2(N.code,e,t):[];return s.jsxs("section",{className:"recommend","aria-label":"赛程推荐",children:[s.jsxs("div",{className:"recommend__card",children:[s.jsxs("p",{className:"recommend__hint",children:[s.jsx("span",{className:"recommend__bulb","aria-hidden":!0,children:"💡"}),"已经选了几支球队，不知道下一支该选谁？试试赛程推荐。"]}),s.jsxs("div",{className:"recommend__foot",children:[s.jsxs("span",{className:"recommend__count",children:["已选择 ",d," 支球队"]}),s.jsx("button",{className:"recommend__cta",onClick:()=>i(c=>!c),children:o?"收起推荐":`推荐第${d+1}支`})]})]}),o&&s.jsx("div",{className:"recommend__result",children:!p||!N?s.jsx("p",{className:"recommend__empty",children:"当前范围内没有明显的赛程空缺。"}):s.jsxs(s.Fragment,{children:[s.jsx("p",{className:"recommend__subtitle",children:"建议下一支选择："}),s.jsxs("div",{className:"recommend__candidate",children:[s.jsx("span",{className:"recommend__no",children:_o(g+1)}),s.jsxs("span",{className:"recommend__team",children:[s.jsx("span",{className:"recommend__code",children:N.code}),s.jsx("span",{className:"recommend__name",children:N.name})]}),s.jsxs("span",{className:"recommend__holes",children:["填补 ",N.filledHoles," 个赛程空缺"]})]}),s.jsxs("div",{className:"recommend__actions",children:[s.jsx("button",{className:"recommend__btn",onClick:()=>y(c=>!c),children:u?"收起赛程":"查看赛程"}),s.jsx("button",{className:"recommend__btn",onClick:D,children:"换一个推荐"}),a&&s.jsx("button",{className:"recommend__btn recommend__btn--ghost",onClick:()=>a(N.code),children:"加入选择"})]}),u&&h.length>0&&s.jsx("ul",{className:"recommend__schedule",children:h.map(c=>s.jsxs("li",{className:"recommend__line",children:[s.jsxs("span",{className:"recommend__line-md",children:["MD",c.matchday]}),s.jsxs("span",{className:"recommend__line-meta",children:[c.homeAway==="H"?"主":"客"," vs ",c.opponent," · ",c.date.slice(5)," ",c.time]})]},c.matchday))}),w&&s.jsxs("p",{className:"recommend__tied",children:["另有 ",w.count," 支球队同样可以填补 ",w.score," 个赛程空缺"]})]})})]})}function a2({activeTab:n,selectedCount:e,maxTeams:t,onChange:a}){return s.jsxs("nav",{className:"mobile-tabbar","aria-label":"移动端主导航",children:[s.jsxs("button",{type:"button",className:`mobile-tabbar__tab ${n==="select"?"mobile-tabbar__tab--active":""}`,onClick:()=>a("select"),"aria-current":n==="select",children:[s.jsx("span",{className:"mobile-tabbar__icon","aria-hidden":"true",children:"⚽"}),s.jsx("span",{className:"mobile-tabbar__label",children:"选队"}),e>0&&s.jsxs("span",{className:"mobile-tabbar__badge",children:[e,"/",t]})]}),s.jsxs("button",{type:"button",className:`mobile-tabbar__tab ${n==="fixtures"?"mobile-tabbar__tab--active":""}`,onClick:()=>a("fixtures"),"aria-current":n==="fixtures",children:[s.jsx("span",{className:"mobile-tabbar__icon","aria-hidden":"true",children:"📅"}),s.jsx("span",{className:"mobile-tabbar__label",children:"赛程"})]})]})}const Do=10;function d2(){const n=U.useMemo(()=>Ws(),[]),[e,t]=U.useState([]),[a,d]=U.useState(!1),[o,i]=U.useState(1),[r,l]=U.useState(n.matchdays.length),[u,y]=U.useState("select"),[f,p]=U.useState(!1),g=U.useMemo(()=>e.map(m=>n.teamByCode[m]).filter(Boolean),[e,n]),N=U.useMemo(()=>n.matchdays.filter(m=>m.number>=o&&m.number<=r),[n,o,r]),w=m=>{t(c=>c.includes(m)?c.filter(v=>v!==m):c.length>=Do?c:[...c,m])},D=()=>{t([]),y("select")},h=e.length>0;return s.jsxs("div",{className:"app",children:[s.jsxs("div",{className:"bg-aura","aria-hidden":"true",children:[s.jsx("div",{className:"bg-aura__orb bg-aura__orb--1"}),s.jsx("div",{className:"bg-aura__orb bg-aura__orb--2"}),s.jsx("div",{className:"bg-aura__orb bg-aura__orb--3"}),s.jsx("div",{className:"bg-aura__ring bg-aura__ring--1"}),s.jsx("div",{className:"bg-aura__ring bg-aura__ring--2"}),s.jsx("div",{className:"bg-aura__ring bg-aura__ring--3"}),s.jsx("div",{className:"bg-aura__stars"})]}),s.jsx(Gs,{captainRoute:a,hasSelection:h,onToggleCaptainRoute:()=>d(m=>!m),onClear:D}),s.jsxs("div",{className:"workspace","data-tab":u,children:[s.jsx("main",{className:"workspace__main",children:h?s.jsxs(s.Fragment,{children:[!f&&s.jsxs("div",{className:"landscape-hint",role:"status",children:[s.jsx("span",{className:"landscape-hint__icon","aria-hidden":"true",children:"⟳"}),s.jsx("span",{className:"landscape-hint__text",children:"建议旋转手机，横屏查看赛程更完整"}),s.jsx("button",{type:"button",className:"landscape-hint__close",onClick:()=>p(!0),"aria-label":"关闭提示",children:"×"})]}),s.jsx(Xs,{start:o,end:r,total:n.matchdays.length,onChange:(m,c)=>{i(m),l(c)}}),s.jsx(t2,{selectedCodes:e,rangeStart:o,rangeEnd:r,onAddToCompare:w}),s.jsx(Js,{matchdays:N,selectedTeams:g,captainRoute:a}),s.jsx(Ys,{})]}):s.jsxs("div",{className:"empty",children:[s.jsx("div",{className:"empty__icon",children:"⚽"}),s.jsxs("div",{className:"empty__title",children:[s.jsx("span",{className:"empty--desktop",children:"先在右侧选择球队"}),s.jsx("span",{className:"empty--mobile",children:"先选你关注的球队"})]}),s.jsxs("div",{className:"empty__sub",children:[s.jsx("span",{className:"empty--desktop",children:"勾选右侧的球队，赛程矩阵横向铺开 8 个 Matchday，3 秒看清谁先踢、谁后踢、谁撞车"}),s.jsx("span",{className:"empty--mobile",children:"最多 10 支，勾选后切到「赛程」看对阵安排"})]})]})}),s.jsxs("aside",{className:"workspace__side",children:[s.jsx($s,{teams:n.teams,selectedCodes:e,maxTeams:Do,onToggle:w}),h&&s.jsx("button",{type:"button",className:"mobile-view-fixtures",onClick:()=>y("fixtures"),children:"查看赛程 →"})]})]}),a&&h&&s.jsx(Zs,{matchdays:N,selectedTeams:g,onClose:()=>d(!1)}),s.jsx(a2,{activeTab:u,selectedCount:e.length,maxTeams:Do,onChange:y}),s.jsxs("footer",{className:"footer",children:["数据来源：UEFA 欧冠联赛阶段赛程 · 开球时间为北京时间（UTC+8，已由欧洲时间 CET/CEST 转换）· 非官方工具，仅供 Fantasy 参考",s.jsx("br",{}),"B站 微博 小红书 公众号 请关注FPL 紫葱酱"]})]})}function o2(){if(!document.body)return;const n=document.createElement("div");n.style.position="absolute",n.style.visibility="hidden",n.style.display="flex",n.style.flexDirection="column",n.style.rowGap="1px",n.appendChild(document.createElement("div")),n.appendChild(document.createElement("div")),document.body.appendChild(n);const e=n.scrollHeight===1;n.parentNode&&n.parentNode.removeChild(n),e&&document.documentElement.classList.add("supports-flex-gap")}o2();function Lo(n,e){var d;const t=document.getElementById("root");if(!t)return;const a=e instanceof Error?`${e.message}

${(d=e.stack)!=null?d:""}`:String(e);t.innerHTML=`<pre style="color:#d9534f;background:#fff5f5;padding:20px;margin:0;white-space:pre-wrap;font:13px/1.5 monospace;border:2px solid #d9534f;">[${n}] ${a}</pre>`}window.addEventListener("error",n=>{var e;return Lo("window.error",(e=n.error)!=null?e:n.message)}),window.addEventListener("unhandledrejection",n=>Lo("unhandledrejection",n.reason));try{dm(document.getElementById("root")).render(s.jsx(U.StrictMode,{children:s.jsx(d2,{})}))}catch(n){Lo("render",n)}})();
